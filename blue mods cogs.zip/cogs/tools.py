import discord
from discord import app_commands
from discord.ext import commands

import datetime
import typing
import requests

import io
import re

import bot_functions as bot
import format_time


class TimestampCopyView(discord.ui.View):
    def __init__(self, timestamp, original_time):
        super().__init__(timeout=300)
        self.timestamp = timestamp
        self.original_time = original_time

    @discord.ui.button(label="Unix Timestamp", style=discord.ButtonStyle.primary, emoji="🔢")
    async def copy_unix(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"```\n{self.timestamp}\n```", ephemeral=True)

    @discord.ui.button(label="Short Time", style=discord.ButtonStyle.secondary, emoji="⏰")
    async def copy_short_time(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"```\n<t:{self.timestamp}:t>\n```", ephemeral=True)

    @discord.ui.button(label="Long Time", style=discord.ButtonStyle.secondary, emoji="🕐")
    async def copy_long_time(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"```\n<t:{self.timestamp}:T>\n```", ephemeral=True)

    @discord.ui.button(label="Short Date", style=discord.ButtonStyle.secondary, emoji="📅")
    async def copy_short_date(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"```\n<t:{self.timestamp}:d>\n```", ephemeral=True)

    @discord.ui.button(label="Long Date", style=discord.ButtonStyle.secondary, emoji="📆")
    async def copy_long_date(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"```\n<t:{self.timestamp}:D>\n```", ephemeral=True)

    @discord.ui.button(label="Relative", style=discord.ButtonStyle.success, emoji="🔄", row=1)
    async def copy_relative(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"```\n<t:{self.timestamp}:R>\n```", ephemeral=True)

    @discord.ui.button(label="Full Date", style=discord.ButtonStyle.success, emoji="🌍", row=1)
    async def copy_full_date(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"```\n<t:{self.timestamp}:F>\n```", ephemeral=True)

    @discord.ui.button(label="All Formats", style=discord.ButtonStyle.danger, emoji="📋", row=1)
    async def copy_all_formats(self, interaction: discord.Interaction, button: discord.ui.Button):
        all_formats = f"""**Unix Timestamp:** {self.timestamp}
**Short Time:** <t:{self.timestamp}:t>
**Long Time:** <t:{self.timestamp}:T>
**Short Date:** <t:{self.timestamp}:d>
**Long Date:** <t:{self.timestamp}:D>
**Full Date:** <t:{self.timestamp}:F>
**Relative:** <t:{self.timestamp}:R>"""
        await interaction.response.send_message(all_formats, ephemeral=True)

    async def on_timeout(self):
        # Disable all buttons when view times out
        for item in self.children:
            item.disabled = True

class Tools(commands.Cog):
  def __init__(self, client):
    self.client = client

  @commands.hybrid_command(name="embed", description="Send a customizable embed to a selected channel.", usage="embed <channel/id> <description> <title> <thumbnail> <image> <footer> <non embed text>")
  @commands.has_permissions(manage_messages=True)
  @commands.guild_only()
  @app_commands.describe(
    channel="Channel where you want to send the embed.",
    description="Main content of your embed.",
    title="Title of your embed message.",
    thumbnail="URL of the thumbnail image.",
    image="URL of the main image.",
    footer="Footer text of your embed message.",
    text="Additional text to include above the embed.")
  async def embed(self, ctx, channel: discord.TextChannel, *, description, title=None, thumbnail=None, image=None, footer=None, text=None):
    await ctx.defer()
    em = discord.Embed(
        title=title,
        description=description,
        color=discord.Colour.brand_green(),
        timestamp=datetime.datetime.utcnow()
    )
    em.set_author(name=ctx.author.name, icon_url=ctx.author.display_avatar.url)
    if thumbnail:
      em.set_thumbnail(url=thumbnail)
    if image:
      em.set_image(url=image)
    if footer:
      em.set_footer(text=footer)
    await channel.send(text, embed=em)
    await ctx.send(f'<:tick:1130455762867601469> Embed sent to **{channel.mention}**.')

  @commands.hybrid_command(name="channelname", description="Change the name of the current channel.", aliases=["cn"], usage="channelname <new name>")
  @commands.has_permissions(manage_channels=True)
  @commands.guild_only()
  @app_commands.describe(name="New name for the current channel.")
  async def channelname(self, ctx, *, name):
    channel = ctx.channel
    em = discord.Embed(title="Success", description="I changed the channel name.", color=discord.Colour.blue())
    em.add_field(name="Before", value=channel.name, inline = False)
    em.add_field(name="After", value=name, inline = False)
    em.add_field(name="Moderator", value=ctx.author.mention, inline = False)
    await channel.edit(name=name, reason=f"{ctx.author} used channelname.")
    await ctx.send(embed=em)


  @commands.hybrid_command(name="slowmode", description="Set slowmode for current channel.", usage="slowmode <time/off>")
  @commands.has_permissions(manage_channels=True)
  @commands.guild_only()
  @app_commands.describe(duration="Time for slowmode eg. 1hr30m15s or None.")
  async def slowmode(self, ctx, duration):
    await ctx.defer()
    if duration.lower() in ["0", "off", "disable", "none"]:
      await ctx.channel.edit(slowmode_delay=0)
      em = discord.Embed(title="Success", description="I turned off slowmode.", color=discord.Colour.blue())
      em.add_field(name="Channel", value=ctx.channel.mention, inline = False)
      em.add_field(name="Moderator", value=ctx.author.mention, inline = False)
      await ctx.send(embed=em)
      return
    duration = format_time.format_time(duration)

    if duration.total_seconds() == 0:
      em = discord.Embed(title="Error!", description="Invalid time format.", color=discord.Colour.red())
      em.add_field(name="Syntax", value=f"`{ctx.prefix}slowmode 1h30m15s | None`.", inline = False)
      await ctx.send(embed=em)
      return

    if duration.total_seconds() > 21600 :
      em = discord.Embed(title="Error!", description="Slowmode can't be more than 6hrs.", color = discord.Colour.red())
      await ctx.send(embed=em)
      return

    await ctx.channel.edit(slowmode_delay=duration.total_seconds(), reason=f"{ctx.author} used slowmode.")
    em = discord.Embed(title="Success", description="I turned on slowmode.", color=discord.Colour.blue())
    em.add_field(name="Channel", value=ctx.channel.mention, inline = False)
    em.add_field(name="Duration", value=duration, inline = False)
    em.add_field(name="Moderator", value=ctx.author.mention, inline = False)

    await ctx.send(embed=em)

  @commands.hybrid_command(name="lockdown", description="Locks a channel.", aliases=["lock"], usage="lockdown <channel/id>")
  @commands.has_permissions(manage_channels=True)
  @commands.guild_only()
  @app_commands.describe(channel="Channel you want to lock.")
  async def lockdown(self, ctx, channel: discord.TextChannel=None):
    if not channel:
      channel = ctx.channel
    overwrite = channel.overwrites_for(ctx.guild.default_role)

    if overwrite.send_messages is False:
      em = discord.Embed(title="Failed", description=f"{channel.mention} is already locked. \n\nIf members are still able to send messages, you may check `role/user` overwrites.", color = discord.Colour.red())
      await ctx.send(embed=em)
      return

    overwrite.send_messages = False
    await channel.set_permissions(ctx.guild.default_role, overwrite = overwrite, reason=f"{ctx.author} used lockdown.")

    em = discord.Embed(title="Success", description=f"I successfully locked {channel.mention}.", color = discord.Colour.blue())
    await ctx.send(embed=em)


  @commands.hybrid_command(name="unlockdown", description="Unlocks a channel.", aliases=["unlock"], usage="unlockdown <channel/id>")
  @commands.has_permissions(manage_channels=True)
  @commands.guild_only()
  @app_commands.describe(channel="Channel you want to unlock.")
  async def unlockdown(self, ctx, channel: discord.TextChannel=None):
    if not channel:
      channel = ctx.channel
    overwrite = channel.overwrites_for(ctx.guild.default_role)

    if overwrite.send_messages is not False:
      em = discord.Embed(title="Failed", description=f"{channel.mention} is already unlocked. \n\nIf members are still not able to send messages, you may check `role/user` overwrites.", color = discord.Colour.red())
      await ctx.send(embed=em)
      return

    overwrite.send_messages = None
    await channel.set_permissions(ctx.guild.default_role, overwrite = overwrite, reason=f"{ctx.author} used unlock.")

    em = discord.Embed(title="Success", description=f"I successfully unlocked {channel.mention}.", color = discord.Colour.blue())
    await ctx.send(embed=em)

  @commands.hybrid_command(name="hide", description="Hides a channel.", usage="hide <channel/id>")
  @commands.has_permissions(manage_channels=True)
  @commands.guild_only()
  @app_commands.describe(channel="Channel you want to hide.")
  async def hide(self, ctx, channel: discord.TextChannel=None):
    if not channel:
      channel = ctx.channel
    overwrite = channel.overwrites_for(ctx.guild.default_role)

    if overwrite.view_channel is False:
      em = discord.Embed(title="Failed", description=f"{channel.mention} is already hidden. \n\nIf members are still able to see it, you may check `role/user` overwrites.", color = discord.Colour.red())
      await ctx.send(embed=em)
      return

    overwrite.view_channel = False
    await channel.set_permissions(ctx.guild.default_role, overwrite = overwrite, reason=f"{ctx.author} used hide.")

    em = discord.Embed(title="Success", description=f"I successfully hided {channel.mention}.", color = discord.Colour.blue())
    await ctx.send(embed=em)

  @commands.hybrid_command(name="unhide", description="Unhides a channel.", usage="unhide <channel/id>")
  @commands.has_permissions(manage_channels=True)
  @commands.guild_only()
  @app_commands.describe(channel="Channel you want to unhide.")
  async def unhide(self, ctx, channel: discord.TextChannel=None):
    if not channel:
      channel = ctx.channel
    overwrite = channel.overwrites_for(ctx.guild.default_role)

    if overwrite.view_channel is not False:
      em = discord.Embed(title="Failed", description=f"{channel.mention} is not hidden. \n\nIf members are still not able to see it, you may check `role/user` overwrites.", color = discord.Colour.red())
      await ctx.send(embed=em)
      return

    overwrite.view_channel = None
    await channel.set_permissions(ctx.guild.default_role, overwrite = overwrite, reason=f"{ctx.author} used unhide.")

    em = discord.Embed(title="Success", description=f"I successfully unhided {channel.mention}.", color = discord.Colour.blue())
    await ctx.send(embed=em)



  @commands.hybrid_command(name="nickname", description="Changes nickname of a member.", aliases=["nick", "setnick", "name"], usage="nickname <user/id> <new name>")
  @commands.has_permissions(manage_nicknames=True)
  @commands.guild_only()
  @app_commands.describe(member="Select a member whose nickname you want to change.", name="Name you want to set.")
  async def nickname(self, ctx, member: discord.Member,*, name=None):
    try :
      em = discord.Embed(title="Success", description="I changed the nickname.", color=discord.Colour.blue())
      em.add_field(name="Member", value=member.mention)
      em.add_field(name="Before", value=member.nick, inline = False)
      em.add_field(name="After", value=name, inline = False)
      em.add_field(name="Moderator", value=ctx.author.mention, inline = False)
      await member.edit(nick=name, reason=f"{ctx.author} used nickname.")

    except :
      em = discord.Embed(title="Error!", description=f"I am unable to change the nickname of {member.mention}.", color = discord.Colour.red())
    await ctx.send(embed=em)



  @commands.hybrid_command(name="steal", description="Add emojis from a link or emoji itself.", usage="steal [emoji|link|reply]", aliases=["emoji"])
  @commands.has_permissions(manage_emojis=True)
  @commands.guild_only()
  @app_commands.describe(input="Emoji or link.")
  async def steal(self, ctx, input: commands.Greedy[typing.Union[discord.PartialEmoji, str]] = None):
    if input:
      input = [element for element in input if str(element).startswith("https://") or isinstance(element, discord.PartialEmoji)]
    if not input:
      if ctx.message.reference:
        message = await ctx.fetch_message(ctx.message.reference.message_id)
        raw_input = message.content.split(" ")
        urls = [element for element in raw_input if element.startswith("https://")]
        emotes = [discord.PartialEmoji.from_str(element) for element in raw_input if re.match(r'<(a?):([a-zA-Z0-9\_]+):([0-9]+)>$', element)]
        input = urls + emotes
    if not input:
      await ctx.send("<:cross:1130455801740406874> Failed, no `emoji/link` was found.")
      return
    for element in input:
      if isinstance(element, discord.PartialEmoji):
        element._state = self.client._connection
        image = await element.read()
        try:
          emoji = await ctx.guild.create_custom_emoji(name=element.name, image=image, reason=f"{ctx.author} used steal command.")
          await ctx.send(f"<:tick:1130455762867601469> Successfully added a emoji {emoji}.")
        except: await ctx.send("<:cross:1130455801740406874> Failed, You may check asset size or server emoji slots.")

      elif str(element).startswith("https://"):
        name = f"emoji_{len(ctx.guild.emojis)+1}"
        image = requests.get(element).content
        try:
          emoji = await ctx.guild.create_custom_emoji(name=name, image=image, reason=f"{ctx.author} used steal command.")
          await ctx.send(f"<:tick:1130455762867601469> Successfully added a emoji {emoji}.")
        except: await ctx.send("<:cross:1130455801740406874> Failed, You may check asset size or server emoji slots.")


  @commands.hybrid_command(name="sticker", description="Adds a sticker from a url, emoji or a sticker.", aliases=["ss", "steals", "stealsticker"], usage="sticker <input>")
  @commands.has_permissions(manage_emojis=True)
  @commands.guild_only()
  @app_commands.describe(input="Emoji, url or sticker you want to add as sticker.")
  async def sticker(self, ctx, input: commands.Greedy[typing.Union[discord.PartialEmoji, str]] = None):
    if input: input = input[0]
    if input and not (str(input).startswith("https://") or isinstance(input, discord.PartialEmoji)): input = None
    if not input and ctx.message.stickers: input = ctx.message.stickers[0]
    elif ctx.message.reference:
      message = await ctx.fetch_message(ctx.message.reference.message_id)
      if message.stickers: input = message.stickers[0]
      else:
        urls = [element for element in message.content.split(" ") if element.startswith("https://")]
        emotes = [discord.PartialEmoji.from_str(element) for element in message.content.split(" ") if re.match(r'<(a?):([a-zA-Z0-9\_]+):([0-9]+)>$', element)]
        if not (urls + emotes): input = None
        else: input = (urls + emotes)[0]
    if not input:
      await ctx.send("<:cross:1130455801740406874> Failed, no `emoji/link/sticker` was found.")
      return

    if str(input).startswith("https://"):
      name = f"sticker_{len(ctx.guild.stickers)+1}"
      image = io.BytesIO(requests.get(input).content)
      file = discord.File(fp=image)
      try:
        sticker = await ctx.guild.create_sticker(name=name, file=file, emoji="🤖", description=f"Added by {ctx.author}.", reason=f"{ctx.author} used sticker command.")
        await ctx.send("<:tick:1130455762867601469> Successfully added a sticker.", stickers=[sticker])
      except: await ctx.send("<:cross:1130455801740406874> Failed, You may check asset size/type or server sticker slots.")
    elif isinstance(input, discord.PartialEmoji):
      input._state = self.client._connection
      file = await input.to_file()
      try:
        sticker = await ctx.guild.create_sticker(name=input.name, file=file, description=f"Added by {ctx.author}.", emoji="🤖", reason=f"{ctx.author} used sticker command.")
        await ctx.send("<:tick:1130455762867601469> Successfully added a sticker.", stickers=[sticker])
      except: await ctx.send("<:cross:1130455801740406874> Failed, You may check asset size/type or server sticker slots.")
    elif isinstance(input, discord.StickerItem):
      data = await input.fetch()
      image = io.BytesIO(requests.get(input.url).content)
      file = discord.File(fp=image)
      try:
        sticker = await ctx.guild.create_sticker(name=data.name, file=file, description=data.description, emoji=data.emoji, reason=f"{ctx.author} used sticker command.")
        await ctx.send("<:tick:1130455762867601469> Successfully added a sticker.", stickers=[sticker])
      except: await ctx.send("<:cross:1130455801740406874> Failed, You may check asset size/type or server sticker slots.")


  @commands.hybrid_command(name="afk", description="Set afk for you.", usage="afk [message]")
  @commands.guild_only()
  @app_commands.describe(message="Your afk message.")
  async def afk(self, ctx ,*, message:str = "No message provided."):
    await ctx.defer(ephemeral=True)
    bot.setup_afk(ctx.author)
    bot.add_afk(ctx.author, message)
    await ctx.send(f"**{ctx.author.mention}, Alright I'll manage it, Enjoy yourself {ctx.author}.**", delete_after=3)

  @commands.hybrid_command(name="ltcbalance", description="Check Litecoin address balance.", aliases=["ltc", "bal"], usage="ltcbalance <address>")
  @commands.guild_only()
  @app_commands.describe(address="Litecoin address to check")
  async def ltcbalance(self, ctx, address: str):
    await ctx.defer()

    # Auto-delete the command message
    try:
      await ctx.message.delete()
    except:
      pass

    # No validation for address format anymore
    if not address:
      em = discord.Embed(
        title="Error",
        description="Please provide an address to check.",
        color=discord.Color.red()
      )
      await ctx.send(embed=em)
      return

    try:
      # Get current LTC price in USD from CoinGecko
      price_url = "https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd"
      price_response = requests.get(price_url, timeout=10)
      if price_response.status_code != 200:
        raise Exception("CoinGecko API is unavailable")
      price_data = price_response.json()
      ltc_price_usd = price_data['litecoin']['usd']

      # Using BlockCypher API to fetch address data
      api_url = f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}"
      response = requests.get(api_url, timeout=10)
      if response.status_code != 200:
        raise Exception("BlockCypher API is unavailable")
      data = response.json()

      # Calculate LTC amounts (from satoshis to LTC)
      balance_ltc = data.get('balance', 0) / 100000000
      unconfirmed_balance_ltc = data.get('unconfirmed_balance', 0) / 100000000
      total_received_ltc = data.get('total_received', 0) / 100000000

      # Calculate value in USD
      balance_usd = balance_ltc * ltc_price_usd
      unconfirmed_usd = unconfirmed_balance_ltc * ltc_price_usd
      total_received_usd = total_received_ltc * ltc_price_usd

      # Create embed matching the reference image style with dark background
      em = discord.Embed(title="LiteCoin Balance", color=0x56A9FF)

      # Add wallet address section
      em.add_field(
        name="Wallet Address",
        value=f"{address}",
        inline=False
      )

      # Add current balance section with arrow emoji
      em.add_field(
        name="<:online:1130473071552245801> Current Balance",
        value=f"• LTC - {balance_ltc:.8f}\n• USD - {balance_usd:.2f}",
        inline=False
      )

      # Add unconfirmed balance section with arrow emoji
      em.add_field(
        name="<:idle:1130473039017017355> Unconfirmed Balance",
        value=f"• LTC - {unconfirmed_balance_ltc:.8f}\n• USD - {unconfirmed_usd:.2f}",
        inline=False
      )

      # Add total received section with arrow emoji
      em.add_field(
        name="<:invisible:1130474032840577094> Total Received",
        value=f"• LTC - {total_received_ltc:.8f}\n• USD - {total_received_usd:.2f}",
        inline=False
      )

      # Create a button to view on explorer
      view = discord.ui.View()
      view.add_item(discord.ui.Button(
        label="View on Explorer", 
        url=f"https://live.blockcypher.com/ltc/address/{address}/",
        style=discord.ButtonStyle.url
      ))

      await ctx.send(embed=em, view=view)

    except Exception as e:
      em = discord.Embed(
        title="Error",
        description=f"Failed to fetch Litecoin address data: {str(e)}",
        color=discord.Color.red()
      )
      await ctx.send(embed=em)

  @commands.hybrid_command(name="timezone", description="Convert time between different timezones", usage="timezone <time> <from_timezone> <to_timezone>", aliases=["tz"])
  @commands.guild_only()
  @app_commands.describe(
    time="Time in 24-hour format (HH:MM)",
    from_timezone="Source timezone (e.g. UTC, GMT, IST, PST)",
    to_timezone="Target timezone (e.g. UTC, GMT, IST, PST)")
  async def timezone(self, ctx, time: str, from_timezone: str, to_timezone: str):
    await ctx.defer()
    await ctx.message.delete()

    try:
      # Parse input time
      try:
        hour, minute = map(int, time.split(':'))
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
          raise ValueError
      except ValueError:
        await ctx.send("<:cross:1130455801740406874> Invalid time format. Please use HH:MM (24-hour format)")
        return

      # Helper function to parse timezone with offset
      def parse_timezone(tz_str):
        tz_str = tz_str.upper()
        # Check if it's a standard timezone
        timezone_offsets = {
            'UTC': 0, 'GMT': 0,
            'EST': -5, 'EDT': -4,
            'CST': -6, 'CDT': -5,
            'MST': -7, 'MDT': -6,
            'PST': -8, 'PDT': -7,
            'IST': 5.5,
            'JST': 9,
            'AEST': 10, 'AEDT': 11,
            'AWST': 8,
            'CET': 1, 'CEST': 2,
            'BST': 1
        }

        if tz_str in timezone_offsets:
          return timezone_offsets[tz_str]

        # Parse UTC/GMT±X format
        if tz_str.startswith(('UTC+', 'UTC-', 'GMT+', 'GMT-')):
          try:
            offset = float(tz_str[4:])
            return offset if tz_str[3] == '+' else -offset
          except ValueError:
            return None

        return None

      # Parse and validate timezones
      from_offset = parse_timezone(from_timezone)
      to_offset = parse_timezone(to_timezone)

      if from_offset is None:
        await ctx.send(f"<:cross:1130455801740406874> Invalid source timezone: `{from_timezone}`")
        return

      if to_offset is None:
        await ctx.send(f"<:cross:1130455801740406874> Invalid target timezone: `{to_timezone}`")
        return
      diff_hours = to_offset - from_offset

      # Convert time
      total_minutes = hour * 60 + minute
      converted_minutes = total_minutes + (diff_hours * 60)

      # Handle day overflow/underflow
      days_diff = 0
      while converted_minutes >= 1440:  # 24 * 60
        converted_minutes -= 1440
        days_diff += 1
      while converted_minutes < 0:
        converted_minutes += 1440
        days_diff -= 1

      converted_hour = int(converted_minutes // 60)
      converted_minute = int(converted_minutes % 60)

      # Create embed
      em = discord.Embed(
        title="⌗   Timezone Conversion",
        color=discord.Color.blue()
      )

      result_time = f"{converted_hour:02d}:{converted_minute:02d}"
      day_text = ""
      if days_diff > 0:
        day_text = " (next day)"
      elif days_diff < 0:
        day_text = " (previous day)"

      em.description = f" **FROM {from_timezone.upper()}**```py\n {time} {from_timezone.upper()}```\n**TO {to_timezone.upper()}**```py\n{result_time} {to_timezone.upper()}{day_text}```"

      await ctx.send(embed=em)

    except Exception as e:
      await ctx.send(f"<:cross:1130455801740406874> An error occurred: {str(e)}")

  @commands.hybrid_command(name="exchange", description="Convert one currency to another.", aliases=["exch"], usage="exchange <amount> <from_currency> <to_currency>")
  @commands.guild_only()
  @app_commands.describe(amount="Amount of money you want to convert.", from_currency="The currency code you are converting from.", to_currency="The currency code you are converting to.")
  async def exchange(self, ctx, amount: float, from_currency: str, to_currency: str):
    await ctx.defer()

    # Auto-delete the command message if in guild
    try:
      if ctx.guild:
        await ctx.message.delete()
    except:
      pass

    try:
      # Fetching real-time exchange rates from an API
      response = requests.get("https://api.exchangerate-api.com/v4/latest/" + from_currency.upper())
      data = response.json()

      if response.status_code != 200:
        raise Exception("Failed to fetch data from the currency API")

      # Calculate the exchanged amount
      rates = data.get('rates')
      if to_currency.upper() not in rates:
        await ctx.send(f"❌ Currency `{to_currency}` is not supported.")
        return

      # Get converted amount
      converted_amount = amount * data['rates'][to_currency.upper()]

      # Format currencies to uppercase
      from_currency = from_currency.upper()
      to_currency = to_currency.upper()

      # Create a simple message with basic emojis
      message = f"# 💱 __{from_currency} ➔ {to_currency}__\n\n"
      message += f"## - `{amount:.2f} {from_currency}` ➔ `{converted_amount:.2f} {to_currency}`"

      # Create a dark embed with the code block
      em = discord.Embed(
        description=f"\n{message}\n", 
        color=0x439FFF
      )

      await ctx.send(embed=em)

    except Exception as e:
      em = discord.Embed(title="Error", description=str(e), color=discord.Colour.red())
      await ctx.send(embed=em)

  @commands.hybrid_command(name="nuke", description="Duplicates and deletes the current channel (preserving permissions).", usage="nuke")
  @commands.has_permissions(manage_channels=True, administrator=True)
  @commands.guild_only()
  async def nuke(self, ctx):
    """Duplicates the current channel and deletes the original one."""
    await ctx.defer()

    # Create confirmation message with buttons
    class NukeView(discord.ui.View):
        def __init__(self, ctx):
            super().__init__(timeout=60)  # 60 seconds timeout
            self.ctx = ctx
            self.value = None

        @discord.ui.button(label="Confirm Nuke", style=discord.ButtonStyle.danger)
        async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
            if interaction.user != self.ctx.author:
                await interaction.response.send_message("You cannot use this button!", ephemeral=True)
                return

            await interaction.response.defer()
            self.value = True
            self.stop()

        @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
        async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
            if interaction.user != self.ctx.author:
                await interaction.response.send_message("You cannot use this button!", ephemeral=True)
                return

            await interaction.response.defer()
            self.value = False
            self.stop()

    # Send the confirmation message
    embed = discord.Embed(
        title="⚠️ Channel Nuke Confirmation",
        description="Are you sure you want to nuke this channel? This will **delete** the current channel and create a new one with the same permissions.",
        color=discord.Colour.red()
    )

    view = NukeView(ctx)
    message = await ctx.send(embed=embed, view=view)

    # Wait for interaction
    await view.wait()

    # Delete the confirmation message
    try:
        await message.delete()
    except:
        pass

    # If confirmed, proceed with nuke
    if view.value:
        # Get the current channel
        channel = ctx.channel

        # Get channel position
        position = channel.position

        try:
            # Create a new channel with the same settings and permissions
            new_channel = await channel.clone(reason=f"Channel nuked by {ctx.author}")

            # Set the position to match the original
            await new_channel.edit(position=position)

            # Send confirmation message in the new channel
            embed = discord.Embed(
                title="Channel Nuked",
                description=f"This channel has been nuked by {ctx.author.mention}.",
                color=discord.Colour.blue()
            )

            # Add the nuclear explosion gif or message
            embed.set_image(url="https://media.tenor.com/C8cFen0G5B0AAAAC/explosion-explode.gif")

            # Delete the original channel
            await channel.delete(reason=f"Channel nuked by {ctx.author}")

            # Send the confirmation in the new channel
            await new_channel.send(embed=embed)

        except discord.Forbidden:
            await ctx.send("<:cross:1130455801740406874> I don't have permission to manage this channel.")
        except discord.HTTPException as e:
            await ctx.send(f"<:cross:1130455801740406874> An error occurred: {e}")
    else:
        await ctx.send("Channel nuke cancelled.")

  @commands.hybrid_command(name="exchange_simple", description="Convert one currency to another (user command version).", aliases=["exs"], usage="exchange_simple <amount> <from_currency> <to_currency>")
  @app_commands.describe(amount="Amount of money you want to convert.", from_currency="The currency code you are converting from.", to_currency="The currency code you are converting to.")
  @app_commands.allowed_installs(guilds=True, users=True)
  @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
  async def exchange_simple(self, ctx, amount: float, from_currency: str, to_currency: str):
    await ctx.defer()

    # Auto-delete the command message if in guild
    try:
      if ctx.guild:
        await ctx.message.delete()
    except:
      pass

    try:
      # Fetching real-time exchange rates from an API
      response = requests.get("https://api.exchangerate-api.com/v4/latest/" + from_currency.upper())
      data = response.json()

      if response.status_code != 200:
        raise Exception("Failed to fetch data from the currency API")

      # Calculate the exchanged amount
      rates = data.get('rates')
      if to_currency.upper() not in rates:
        await ctx.send(f"❌ Currency `{to_currency}` is not supported.")
        return

      # Get converted amount
      converted_amount = amount * data['rates'][to_currency.upper()]

      # Format currencies to uppercase
      from_currency = from_currency.upper()
      to_currency = to_currency.upper()

      # Create a simple message with basic emojis
      message = f"# 💱 __{from_currency} ➔ {to_currency}__\n\n"
      message += f"## - `{amount:.2f} {from_currency}` ➔ `{converted_amount:.2f} {to_currency}`"

      # Create a dark embed with the code block
      em = discord.Embed(
        description=f"\n{message}\n", 
        color=0x439FFF
      )

      await ctx.send(embed=em)

    except Exception as e:
      em = discord.Embed(title="Error", description=str(e), color=discord.Colour.red())
      await ctx.send(embed=em)

  @commands.hybrid_command(name="define", description="Get the definition of a word", usage="define <word>")
  @app_commands.allowed_installs(guilds=True, users=True)
  @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
  @app_commands.describe(word="The word you want to define")
  async def define(self, ctx, *, word: str):
    await ctx.defer()

    # Auto-delete the command message if in guild
    try:
      if ctx.guild:
        await ctx.message.delete()
    except:
      pass

    try:
      # Use a free dictionary API
      url = f"https://api.dictionaryapi.dev/api/v2/entries/en/{word.lower()}"
      response = requests.get(url, timeout=10)

      if response.status_code == 404:
        embed = discord.Embed(
          title="❌ Word Not Found",
          description=f"No definition found for **{word}**",
          color=0xff4757,
          timestamp=datetime.datetime.utcnow()
        )
        await ctx.send(embed=embed)
        return

      if response.status_code != 200:
        raise Exception("Dictionary API is unavailable")

      data = response.json()
      word_data = data[0]

      # Create embed
      embed = discord.Embed(
        title=f"📚 Definition: {word_data['word'].title()}",
        color=0x3498db,
        timestamp=datetime.datetime.utcnow()
      )

      # Add phonetic pronunciation if available
      if 'phonetic' in word_data and word_data['phonetic']:
        embed.add_field(
          name="🔊 Pronunciation",
          value=f"`{word_data['phonetic']}`",
          inline=False
        )

      # Add meanings
      meanings_text = ""
      for i, meaning in enumerate(word_data['meanings'][:3]):  # Limit to 3 meanings
        part_of_speech = meaning['partOfSpeech']
        definitions = meaning['definitions'][:2]  # Limit to 2 definitions per part of speech

        meanings_text += f"**{part_of_speech.title()}**\n"
        for j, definition in enumerate(definitions):
          meanings_text += f"• {definition['definition']}\n"
          if 'example' in definition:
            meanings_text += f"  *Example: {definition['example']}*\n"
        meanings_text += "\n"

      embed.add_field(
        name="📖 Meanings",
        value=meanings_text.strip(),
        inline=False
      )

      # Add synonyms if available
      synonyms = []
      for meaning in word_data['meanings']:
        for definition in meaning['definitions']:
          if 'synonyms' in definition:
            synonyms.extend(definition['synonyms'])

      if synonyms:
        embed.add_field(
          name="🔄 Synonyms",
          value=", ".join(synonyms[:5]),  # Limit to 5 synonyms
          inline=False
        )

      embed.set_footer(text="Dictionary API • Free Dictionary")
      await ctx.send(embed=embed)

    except Exception as e:
      embed = discord.Embed(
        title="❌ Error",
        description=f"Failed to fetch definition: {str(e)}",
        color=0xff4757,
        timestamp=datetime.datetime.utcnow()
      )
      await ctx.send(embed=embed)

  @commands.hybrid_command(name="qrcode", description="Generate a QR code for text or URL", usage="qrcode <text>")
  @app_commands.allowed_installs(guilds=True, users=True)
  @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
  @app_commands.describe(text="The text or URL to generate QR code for")
  async def qrcode(self, ctx, *, text: str):
    await ctx.defer()

    # Auto-delete the command message if in guild
    try:
      if ctx.guild:
        await ctx.message.delete()
    except:
      pass

    try:
      # Use a free QR code API
      import urllib.parse
      encoded_text = urllib.parse.quote(text)
      qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=400x400&data={encoded_text}"

      # Create embed
      embed = discord.Embed(
        title="📱 QR Code Generated",
        description=f"QR code for: **{text[:100]}{'...' if len(text) > 100 else ''}**",
        color=0x2ecc71,
        timestamp=datetime.datetime.utcnow()
      )

      embed.set_image(url=qr_url)

      embed.add_field(
        name="📋 Instructions",
        value="• Scan with your phone's camera\n• Use any QR code reader app\n• Click the image to view full size",
        inline=False
      )

      embed.set_footer(text="QR Code Generator • Free Service")

      # Create view with download button
      view = discord.ui.View()
      download_btn = discord.ui.Button(
        label="Download QR Code",
        url=qr_url,
        style=discord.ButtonStyle.url,
        emoji="⬇️"
      )
      view.add_item(download_btn)

      await ctx.send(embed=embed, view=view)

    except Exception as e:
      embed = discord.Embed(
        title="❌ Error",
        description=f"Failed to generate QR code: {str(e)}",
        color=0xff4757,
        timestamp=datetime.datetime.utcnow()
      )
      await ctx.send(embed=embed)

  @commands.hybrid_command(name="timestamp", description="Get current timestamp or convert time to timestamp", usage="timestamp [time_string]")
  @app_commands.allowed_installs(guilds=True, users=True)
  @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
  @app_commands.describe(time_string="Optional: Time string to convert (e.g., '2024-01-01 12:00:00')")
  async def timestamp(self, ctx, *, time_string: str = None):
    await ctx.defer()

    # Auto-delete the command message if in guild
    try:
      if ctx.guild:
        await ctx.message.delete()
    except:
      pass

    try:
      if time_string:
        # Try to parse the provided time string
        try:
          # Common formats to try
          formats = [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
            "%d/%m/%Y %H:%M:%S",
            "%d/%m/%Y %H:%M",
            "%d/%m/%Y",
            "%m/%d/%Y %H:%M:%S",
            "%m/%d/%Y %H:%M",
            "%m/%d/%Y"
          ]

          parsed_time = None
          for fmt in formats:
            try:
              parsed_time = datetime.datetime.strptime(time_string, fmt)
              break
            except ValueError:
              continue

          if not parsed_time:
            raise ValueError("Invalid time format")

          timestamp = int(parsed_time.timestamp())

          embed = discord.Embed(
            title="⏰ Time to Timestamp Converter",
            description="```yaml\nSuccessfully converted your time to various timestamp formats```",
            color=0x00d4ff,
            timestamp=datetime.datetime.utcnow()
          )

          embed.add_field(
            name="📅 Input Time",
            value=f"```fix\n{time_string}```",
            inline=False
          )

          embed.add_field(
            name="🔢 Unix Timestamp",
            value=f"```py\n{timestamp}```",
            inline=False
          )

          embed.add_field(
            name="📱 Discord Timestamp Formats",
            value=f"**Short Time:** `<t:{timestamp}:t>` → <t:{timestamp}:t>\n"
                  f"**Long Time:** `<t:{timestamp}:T>` → <t:{timestamp}:T>\n"
                  f"**Short Date:** `<t:{timestamp}:d>` → <t:{timestamp}:d>\n"
                  f"**Long Date:** `<t:{timestamp}:D>` → <t:{timestamp}:D>\n"
                  f"**Relative:** `<t:{timestamp}:R>` → <t:{timestamp}:R>",
            inline=False
          )

          embed.set_footer(text="🕐 Click buttons below to copy formats", icon_url=ctx.author.display_avatar.url)

          # Create view with copy buttons
          view = TimestampCopyView(timestamp, time_string)
          await ctx.send(embed=embed, view=view)
          return

        except ValueError:
          embed = discord.Embed(
            title="❌ Invalid Time Format",
            description="```diff\n- Please use one of the supported formats below```",
            color=0xff4757,
            timestamp=datetime.datetime.utcnow()
          )

          embed.add_field(
            name="📋 Supported Formats",
            value="```yaml\n• YYYY-MM-DD HH:MM:SS  # 2024-01-01 12:30:45\n• YYYY-MM-DD HH:MM     # 2024-01-01 12:30\n• YYYY-MM-DD           # 2024-01-01\n• DD/MM/YYYY HH:MM:SS  # 01/01/2024 12:30:45\n• MM/DD/YYYY HH:MM:SS  # 01/01/2024 12:30:45```",
            inline=False
          )

          embed.add_field(
            name="💡 Example Usage",
            value="```\n/timestamp 2024-12-25 15:30:00\n/timestamp 2024-12-25\n/timestamp 25/12/2024 15:30:00```",
            inline=False
          )

          embed.set_footer(text="❌ Time Conversion Failed")
          await ctx.send(embed=embed)
          return

      else:
        # Get current timestamp
        now = datetime.datetime.utcnow()
        timestamp = int(now.timestamp())

        embed = discord.Embed(
          title="⏰ Current Timestamp",
          description="```yaml\nCurrent time converted to various timestamp formats```",
          color=0x00ff88,
          timestamp=datetime.datetime.utcnow()
        )

        embed.add_field(
          name="🔢 Unix Timestamp",
          value=f"```py\n{timestamp}```",
          inline=True
        )

        embed.add_field(
          name="📅 Current Time (UTC)",
          value=f"```fix\n{now.strftime('%Y-%m-%d %H:%M:%S')}```",
          inline=True
        )

        embed.add_field(
          name="🌍 Local Time",
          value=f"<t:{timestamp}:F>",
          inline=True
        )

        embed.add_field(
          name="📱 Discord Timestamp Formats",
          value=f"**Short Time:** `<t:{timestamp}:t>` → <t:{timestamp}:t>\n"
                f"**Long Time:** `<t:{timestamp}:T>` → <t:{timestamp}:T>\n"
                f"**Short Date:** `<t:{timestamp}:d>` → <t:{timestamp}:d>\n"
                f"**Long Date:** `<t:{timestamp}:D>` → <t:{timestamp}:D>\n"
                f"**Relative:** `<t:{timestamp}:R>` → <t:{timestamp}:R>",
          inline=False
        )

        embed.add_field(
          name="💡 Pro Tip",
          value="```diff\n+ Use /timestamp YYYY-MM-DD HH:MM:SS to convert specific times\n+ All timestamps are in UTC timezone\n+ Click buttons below to copy formats```",
          inline=False
        )

        embed.set_footer(text="🕐 Click buttons below to copy formats", icon_url=ctx.author.display_avatar.url)

        # Create view with copy buttons
        view = TimestampCopyView(timestamp, now.strftime('%Y-%m-%d %H:%M:%S'))
        await ctx.send(embed=embed, view=view)

    except Exception as e:
      embed = discord.Embed(
        title="❌ Unexpected Error",
        description=f"```diff\n- An error occurred while processing timestamp\n- Error: {str(e)[:100]}```",
        color=0xff4757,
        timestamp=datetime.datetime.utcnow()
      )
      embed.add_field(
        name="🔧 What to do",
        value="• Try again with a different time format\n• Report this issue if it persists\n• Use `/timestamp` without arguments for current time",
        inline=False
      )
      embed.set_footer(text="❌ Timestamp Processing Failed")
      await ctx.send(embed=embed)

async def setup(client):
  await client.add_cog(Tools(client))
import discord
from discord import app_commands
from discord.ext import commands
import re

class Tools(commands.Cog):
    def __init__(self, client):
        self.client = client

    @app_commands.command(name="calc", description="Calculate a mathematical expression")
    @app_commands.describe(expression="The mathematical expression to calculate")
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    async def calc(self, interaction: discord.Interaction, expression: str):
        """Calculator command that can be used anywhere on Discord"""
        try:
            # Remove any potentially dangerous characters
            expression = expression.replace(" ", "")
            
            # Only allow specific characters for safety
            if not re.match(r'^[\d+\-*/().%^]+$', expression):
                await interaction.response.send_message(
                    "<:cross:1130455801740406874> Invalid expression! Only use numbers and operators: +, -, *, /, %, ^, ()",
                    ephemeral=True
                )
                return
            
            # Replace ^ with ** for exponentiation
            expression = expression.replace('^', '**')
            
            # Evaluate the expression
            result = eval(expression, {"__builtins__": {}})
            
            # Create embed with original theme
            em = discord.Embed(
                title="⌗   Calculator",
                color=0x439FFF
            )
            em.description = f"**EXPRESSION**```py\n{expression.replace('**', '^')}```\n**RESULT**```py\n{result}```"
            
            await interaction.response.send_message(embed=em)
            
        except ZeroDivisionError:
            await interaction.response.send_message(
                "<:cross:1130455801740406874> Error: Cannot divide by zero!",
                ephemeral=True
            )
        except Exception as e:
            await interaction.response.send_message(
                f"<:cross:1130455801740406874> Error calculating expression: Invalid syntax",
                ephemeral=True
            )

async def setup(client):
    await client.add_cog(Tools(client))
