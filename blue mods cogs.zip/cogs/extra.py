import discord
from discord.ext import commands
import requests
import json
from bot_functions import log_error

class Extra(commands.Cog):
  def __init__(self, client):
    self.client = client
  
  @commands.command(name="cricket", description="Shows current cricket scores", aliases=["cric", "cricinfo"], usage="cricket [live/upcoming/recent]")
  @commands.guild_only()
  async def cricket(self, ctx, match_type: str = "live"):
    """Shows cricket match scores - live, upcoming, or recent."""
    await ctx.message.delete()

    match_type = match_type.lower()
    if match_type not in ["live", "upcoming", "recent"]:
      em = discord.Embed(
        title="Invalid Option",
        description="Please use 'live', 'upcoming', or 'recent' as the option.",
        color=discord.Colour.red()
      )
      await ctx.send(embed=em)
      return

    try:
      # Send a typing indicator while making the request
      async with ctx.typing():
        # Using CricBuzz API which is more reliable
        if match_type == "live":
          url = "https://cricbuzz-cricket.p.rapidapi.com/mcenter/v1/41881/comm"
          title = "🏏 Live Cricket Matches"
        elif match_type == "upcoming":
          url = "https://cricbuzz-cricket.p.rapidapi.com/matches/v1/upcoming"
          title = "🏏 Upcoming Cricket Matches"
        else:  # recent
          url = "https://cricbuzz-cricket.p.rapidapi.com/matches/v1/recent"
          title = "🏏 Recent Cricket Matches"
        
        # Setup headers for RapidAPI
        headers = {
          "X-RapidAPI-Key": "a456f6cd28msh09253db51e6d067p1ce729jsn6494e1a3e3fa",
          "X-RapidAPI-Host": "cricbuzz-cricket.p.rapidapi.com"
        }
        
        try:
          response = requests.get(url, headers=headers, timeout=15)
          
          # Check if the request was successful
          if response.status_code != 200:
            raise Exception(f"API returned status code {response.status_code}")
          
          data = response.json()
        except requests.exceptions.RequestException as e:
          raise Exception(f"Request failed: {str(e)}")
        except json.JSONDecodeError:
          raise Exception("Failed to parse API response as JSON")

        # Process the data from CricBuzz API
        matches = []
        
        # Extract the match types we want to show
        match_types = ["Test", "ODI", "T20", "IPL"]
        
        if "typeMatches" in data:
          for type_match in data["typeMatches"]:
            if type_match.get("matchType", "") in match_types:
              if "seriesMatches" in type_match:
                for series_match in type_match["seriesMatches"]:
                  if "seriesAdWrapper" in series_match:
                    series_name = series_match["seriesAdWrapper"].get("seriesName", "Unknown Series")
                    if "matches" in series_match["seriesAdWrapper"]:
                      for match in series_match["seriesAdWrapper"]["matches"]:
                        matches.append({
                          "series_name": series_name,
                          "match_data": match
                        })
        
        # Sort matches by status - put live matches first
        matches.sort(key=lambda x: 0 if x["match_data"].get("status", "").lower().startswith("live") else 1)
        
        if not matches:
          em = discord.Embed(
            title=title,
            description="No matches found at the moment.",
            color=discord.Colour.blue()
          )
          await ctx.send(embed=em)
          return

        # Create embeds for matches
        embeds = []
        for match_info in matches[:5]:  # Limit to 5 matches to avoid spamming
          match = match_info["match_data"]
          series_name = match_info["series_name"]
          
          # Extract match details
          match_format = match.get("matchFormat", "Unknown Format")
          match_status = match.get("status", "Unknown Status")
          venue_name = match.get("venueInfo", {}).get("ground", "Unknown Venue")
          venue_location = match.get("venueInfo", {}).get("city", "")
          venue = f"{venue_name}, {venue_location}" if venue_location else venue_name
          
          # Get team details
          team1_name = match.get("team1", {}).get("teamName", "Team 1")
          team2_name = match.get("team2", {}).get("teamName", "Team 2")
          
          # Get team scores if available
          team1_score = "No score available"
          team2_score = "No score available"
          
          if "team1Score" in match:
            score_data = match["team1Score"]
            if score_data:
              innings = score_data.get("inngs1", {})
              runs = innings.get("runs", 0)
              wickets = innings.get("wickets", 0)
              overs = innings.get("overs", 0)
              team1_score = f"{runs}/{wickets} ({overs} overs)"
          
          if "team2Score" in match:
            score_data = match["team2Score"]
            if score_data:
              innings = score_data.get("inngs1", {})
              runs = innings.get("runs", 0)
              wickets = innings.get("wickets", 0)
              overs = innings.get("overs", 0)
              team2_score = f"{runs}/{wickets} ({overs} overs)"
          
          # Create match title
          match_title = f"{team1_name} vs {team2_name}"
          
          # Create embed for this match
          em = discord.Embed(
            title=match_title,
            description=f"**{series_name}** ({match_format})",
            color=discord.Colour.blue()
          )
          
          # Add team scores
          em.add_field(name=team1_name, value=f"```{team1_score}```", inline=False)
          em.add_field(name=team2_name, value=f"```{team2_score}```", inline=False)
          
          # Add match status
          em.add_field(name="Status", value=f"```{match_status}```", inline=False)
          
          # Add venue info if available
          if venue and venue != "Unknown Venue":
            em.add_field(name="Venue", value=venue, inline=True)
          
          # Add match start time if available
          if "startDate" in match:
            start_date = match.get("startDate", "")
            em.add_field(name="Start Date", value=start_date, inline=True)
          
          # Add match ID as footer
          em.set_footer(text=f"Match ID: {match.get('matchId', 'Unknown')}")
          
          embeds.append(em)
        
        # If we have embeds, send them
        if embeds:
          for embed in embeds:
            await ctx.send(embed=embed)
        else:
          em = discord.Embed(
            title=title,
            description="No match details available at the moment.",
            color=discord.Colour.blue()
          )
          await ctx.send(embed=em)
          
    except Exception as e:
      # Log the error
      log_error(e, "cricket command")
      
      em = discord.Embed(
        title="Error",
        description=f"An error occurred while fetching cricket scores: {str(e)}",
        color=discord.Colour.red()
      )
      await ctx.send(embed=em)

async def setup(client):
  await client.add_cog(Extra(client))
