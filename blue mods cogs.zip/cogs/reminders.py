
import discord
from discord.ext import commands
from discord import app_commands
import datetime
import asyncio
import json
import os

class Reminders(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.reminders = {}
        # Load existing reminders
        if os.path.exists('reminders.json'):
            with open('reminders.json', 'r') as f:
                self.reminders = json.load(f)
        self.bg_task = self.client.loop.create_task(self.check_reminders())

    async def check_reminders(self):
        await self.client.wait_until_ready()
        while not self.client.is_closed():
            current_time = datetime.datetime.now().timestamp()
            to_remove = []

            for user_id, user_reminders in self.reminders.items():
                for reminder in user_reminders[:]:  # Create a copy to iterate
                    if current_time >= reminder['time']:
                        try:
                            user = await self.client.fetch_user(int(user_id))
                            embed = discord.Embed(
                                title="Reminder!",
                                description=reminder['message'],
                                color=discord.Color.blue()
                            )
                            embed.add_field(name="Set at", value=f"<t:{int(reminder['created_at'])}:F>")
                            await user.send(embed=embed)
                            user_reminders.remove(reminder)

                            # Remove user from reminders if they have no more reminders
                            if not user_reminders:
                                to_remove.append(user_id)

                        except Exception as e:
                            print(f"Error sending reminder: {e}")

            # Remove users with no reminders
            for user_id in to_remove:
                del self.reminders[user_id]

            # Save updated reminders
            with open('reminders.json', 'w') as f:
                json.dump(self.reminders, f)

            await asyncio.sleep(60)  # Check every minute

    @commands.hybrid_command(name="remind", description="Set a reminder that will DM you.", usage="remind <time> <message>")
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    async def remind(self, ctx, time: str, *, message: str):
        """Sets a reminder. Time format: 1h30m, 2d, 30m, etc. (d=days, h=hours, m=minutes)"""

        # Convert time string to seconds
        total_seconds = 0
        current = ""
        for char in time:
            if char.isdigit():
                current += char
            else:
                if not current:
                    continue
                num = int(current)
                if char == 'd':
                    total_seconds += num * 86400
                elif char == 'h':
                    total_seconds += num * 3600
                elif char == 'm':
                    total_seconds += num * 60
                current = ""

        if total_seconds == 0:
            await ctx.send("Invalid time format! Use combinations of d (days), h (hours), m (minutes)")
            return

        if total_seconds > 365 * 24 * 3600:  # 1 year max
            await ctx.send("Reminder time too long! Maximum is 1 year.")
            return

        # Calculate reminder time
        reminder_time = datetime.datetime.now().timestamp() + total_seconds

        # Store reminder
        user_id = str(ctx.author.id)
        if user_id not in self.reminders:
            self.reminders[user_id] = []

        self.reminders[user_id].append({
            'message': message,
            'time': reminder_time,
            'created_at': datetime.datetime.now().timestamp()
        })

        # Save to file
        with open('reminders.json', 'w') as f:
            json.dump(self.reminders, f)

        # Send confirmation
        embed = discord.Embed(
            title="Reminder Set!",
            description=f"I will remind you in <t:{int(reminder_time)}:R>",
            color=discord.Color.blue()
        )
        embed.add_field(name="Message", value=message)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="reminders", description="Lists all your active reminders")
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    async def list_reminders(self, ctx):
        """Lists all your active reminders"""
        user_id = str(ctx.author.id)

        if user_id not in self.reminders or not self.reminders[user_id]:
            await ctx.send("You have no active reminders!")
            return

        embed = discord.Embed(
            title="Your Active Reminders",
            color=discord.Color.blue()
        )

        for i, reminder in enumerate(self.reminders[user_id], 1):
            embed.add_field(
                name=f"Reminder #{i}",
                value=f"Message: {reminder['message']}\nTime: <t:{int(reminder['time'])}:R>",
                inline=False
            )

        await ctx.send(embed=embed)

    @commands.hybrid_command(name="delreminder", description="Removes a specific reminder by its number", usage="delreminder <number>")
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    async def remove_reminder(self, ctx, number: int):
        """Removes a specific reminder. Use the reminder number from the reminders list."""
        user_id = str(ctx.author.id)

        if user_id not in self.reminders or not self.reminders[user_id]:
            await ctx.send("You have no active reminders!")
            return

        if number < 1 or number > len(self.reminders[user_id]):
            await ctx.send("Invalid reminder number! Use the `reminders` command to see your reminders.")
            return

        # Remove the reminder
        removed_reminder = self.reminders[user_id].pop(number - 1)

        # Remove the user from reminders if they have no more reminders
        if not self.reminders[user_id]:
            del self.reminders[user_id]

        # Save updated reminders
        with open('reminders.json', 'w') as f:
            json.dump(self.reminders, f)

        embed = discord.Embed(
            title="Reminder Removed!",
            description=f"Successfully removed reminder: {removed_reminder['message']}",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

async def setup(client):
    await client.add_cog(Reminders(client))
