import discord
from discord.ui import Button, View
from discord.ext import commands

import time

import bot_functions as bot


class Events(commands.Cog):
	def __init__(self, client):
		self.client = client
	
	@commands.Cog.listener("on_message")
	async def manage_afk(self, message):
		if message.author.bot:
			return
		if message.channel == message.author.dm_channel:
			return
			
		if str(message.author.id) in bot.get_afk() and bot.get_afk()[str(message.author.id)]["message"]:
			if time.time() - bot.get_afk()[str(message.author.id)]["time"] > 10:
				bot.remove_afk(message.author)
				await message.reply(f"**Welcome back {message.author}, i changed your status to online!**", delete_after=5)
		
		for member in message.mentions:
			if member is message.author:
				continue
			if str(member.id) in bot.get_afk() and bot.get_afk()[str(member.id)]["message"]:
				msg = bot.get_afk()[str(member.id)]["message"]
				await message.reply(f"{member} is afk <t:{int(bot.get_afk()[str(member.id)]['time'])}:R>: {msg}")
	
	
	@commands.Cog.listener("on_message")
	async def return_prefix(self, message):
		invite = Button(label="Invite Me", url="https://discord.com/api/oauth2/authorize?client_id=1130447733493350411&permissions=8&scope=bot")
		server = Button(label="Support server", url="https://discord.gg/VGSY8FfgGU")
		view = View()
		view.add_item(invite)
		view.add_item(server)
		if message.author.bot :
			return
		if message.content.startswith(self.client.user.mention) :
			prefix = bot.get_prefix(self.client, message)
			if prefix:
				embed = discord.Embed(title = f'› My prefix is `{prefix}`\n› To get started type `{prefix}help`', color = discord.Colour.blue())
			else:
				embed = discord.Embed(title = '› No prefix is enabled in this server!\n› To get started type `help`', color = discord.Colour.blue())
			await message.reply(embed=embed, view=view, mention_author=False)
	
	
	@commands.Cog.listener()
	async def on_command_error(self, ctx, error):
		server = Button(label="Support server", url="https://discord.gg/VGSY8FfgGU")
		view = View()
		view.add_item(server)
		if isinstance(error, commands.CommandNotFound):
			return
		if isinstance(error, commands.MissingPermissions):
			await ctx.message.reply("<:cross:1130455801740406874> You don't have enough permissions to run this command!", view=view, mention_author=False)
			return
		if isinstance(error, commands.BotMissingPermissions):
			await ctx.message.reply("<:cross:1130455801740406874> I don't have enough permissions to execute this command!", view=view, mention_author=False)
			return
		em = discord.Embed(title="Error!", description=error, color=discord.Colour.red())
		await ctx.send(embed=em, view=view, mention_author=False)

async def setup(client):
	await client.add_cog(Events(client))