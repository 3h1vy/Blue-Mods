
import discord
from discord.ext import commands
from discord import app_commands
import requests
import datetime

class TokenInfo(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.hybrid_command(name="tokeninfo", description="Check details of Discord user tokens", aliases=["checktoken", "tokencheck"])
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    @app_commands.describe(tokens="Discord user tokens to analyze (supports mail:pass:token format, separate multiple with spaces or newlines)")
    async def tokeninfo(self, ctx, *, tokens: str):
        """Check information about Discord user tokens - Private command"""
        await ctx.defer(ephemeral=True)

        # Auto-delete the command message if possible
        try:
            await ctx.message.delete()
        except:
            pass

        # Parse tokens from various formats
        def parse_tokens(input_text):
            parsed_tokens = []
            # Split by both spaces and newlines
            lines = input_text.replace(' ', '\n').split('\n')

            for line in lines:
                line = line.strip()
                if not line:
                    continue

                # Check if it's in mail:pass:token format
                if ':' in line and line.count(':') >= 2:
                    parts = line.split(':')
                    # Take the last part as token (in case email has multiple colons)
                    token = parts[-1].strip()
                    if token:
                        parsed_tokens.append(token)
                else:
                    # Treat as direct token
                    if line:
                        parsed_tokens.append(line)

            return parsed_tokens

        token_list = parse_tokens(tokens)

        if not token_list:
            embed = discord.Embed(
                title="❌ No Tokens Provided",
                description="```Please provide at least one token to analyze.```",
                color=0xff4757,
                timestamp=datetime.datetime.utcnow()
            )
            embed.set_footer(text="Token Info • Private Command", icon_url=self.client.user.avatar.url if self.client.user.avatar else None)
            await ctx.send(embed=embed, ephemeral=True)
            return

        # Limit to maximum 5 tokens to prevent spam/abuse
        if len(token_list) > 5:
            embed = discord.Embed(
                title="⚠️ Too Many Tokens",
                description="```Maximum 5 tokens can be analyzed at once.```",
                color=0xffa502,
                timestamp=datetime.datetime.utcnow()
            )
            embed.set_footer(text="Token Info • Private Command", icon_url=self.client.user.avatar.url if self.client.user.avatar else None)
            await ctx.send(embed=embed, ephemeral=True)
            return

        embeds_to_send = []

        for i, token in enumerate(token_list, 1):
            # Basic token validation
            if not token or len(token) < 59:
                embed = discord.Embed(
                    title=f"❌ Invalid Token #{i}",
                    description="```The provided token appears to be invalid or too short.```",
                    color=0xff4757,
                    timestamp=datetime.datetime.utcnow()
                )
                embed.set_footer(text="Token Info • Private Command", icon_url=self.client.user.avatar.url if self.client.user.avatar else None)
                embeds_to_send.append(embed)
                continue

            try:
                # Headers for Discord API request
                headers = {
                    'Authorization': token,
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }

                # Get user information
                user_response = requests.get('https://discord.com/api/v9/users/@me', headers=headers)

                if user_response.status_code == 401:
                    embed = discord.Embed(
                        title=f"🔒 Authentication Failed - Token #{i}",
                        description="```The provided token is invalid or expired.```",
                        color=0xff4757,
                        timestamp=datetime.datetime.utcnow()
                    )
                    embed.add_field(
                        name="💡 Troubleshooting",
                        value="• Ensure the token is copied correctly\n• Check if the token hasn't expired\n• Verify the token format",
                        inline=False
                    )
                    embed.set_footer(text="Token Info • Private Command", icon_url=self.client.user.avatar.url if self.client.user.avatar else None)
                    embeds_to_send.append(embed)
                    continue
                elif user_response.status_code != 200:
                    embed = discord.Embed(
                        title=f"⚠️ API Error - Token #{i}",
                        description=f"```Failed to fetch user data.\nStatus Code: {user_response.status_code}```",
                        color=0xffa502,
                        timestamp=datetime.datetime.utcnow()
                    )
                    embed.set_footer(text="Token Info • Private Command", icon_url=self.client.user.avatar.url if self.client.user.avatar else None)
                    embeds_to_send.append(embed)
                    continue

                user_data = user_response.json()

                # Get billing information
                billing_response = requests.get('https://discord.com/api/v9/users/@me/billing/payment-sources', headers=headers)
                has_payment_methods = billing_response.status_code == 200 and len(billing_response.json()) > 0

                # Get nitro subscription info
                nitro_response = requests.get('https://discord.com/api/v9/users/@me/billing/subscriptions', headers=headers)
                has_nitro = nitro_response.status_code == 200 and len(nitro_response.json()) > 0

                # Get user guilds count
                guilds_response = requests.get('https://discord.com/api/v9/users/@me/guilds', headers=headers)
                guild_count = len(guilds_response.json()) if guilds_response.status_code == 200 else "Unknown"

                # Get user connections
                connections_response = requests.get('https://discord.com/api/v9/users/@me/connections', headers=headers)
                connections = connections_response.json() if connections_response.status_code == 200 else []

                # Parse user data
                username = user_data.get('username', 'Unknown')
                discriminator = user_data.get('discriminator', '0000')
                user_id = user_data.get('id', 'Unknown')
                email = user_data.get('email', 'Not disclosed')
                phone = user_data.get('phone', 'Not disclosed')
                verified = user_data.get('verified', False)
                mfa_enabled = user_data.get('mfa_enabled', False)
                avatar_hash = user_data.get('avatar')
                banner_hash = user_data.get('banner')
                accent_color = user_data.get('accent_color')
                locale = user_data.get('locale', 'Unknown')

                # Get creation date from user ID
                user_id_int = int(user_id)
                discord_epoch = 1420070400000
                timestamp = ((user_id_int >> 22) + discord_epoch) / 1000
                created_at = datetime.datetime.fromtimestamp(timestamp, tz=datetime.timezone.utc)

                # Format display name
                if discriminator == '0' or discriminator == '0000':
                    display_name = f"@{username}"
                else:
                    display_name = f"{username}#{discriminator}"

                # Create main embed with modern design
                embed = discord.Embed(
                    title=f"🔍 Discord Token Analysis #{i}",
                    description="```yaml\nPrivate token information retrieved successfully```",
                    color=0xffffff,
                    timestamp=datetime.datetime.utcnow()
                )

                # User Information Section
                user_info = f"**Username:** `{display_name}`\n"
                user_info += f"**User ID:** `{user_id}`\n"
                user_info += f"**Created:** <t:{int(created_at.timestamp())}:F>\n"
                user_info += f"**Locale:** `{locale}`"

                embed.add_field(
                    name="👤 User Information",
                    value=user_info,
                    inline=True
                )

                # Security & Privacy Section
                security_info = f"**Email:** ||{email}||\n"
                security_info += f"**Phone:** ||{phone}||\n"
                security_info += f"**Email Verified:** {'🟢 Yes' if verified else '🔴 No'}\n"
                security_info += f"**2FA Enabled:** {'🟢 Yes' if mfa_enabled else '🔴 No'}"

                embed.add_field(
                    name="🔐 Security & Privacy",
                    value=security_info,
                    inline=True
                )

                # Account Status Section
                nitro_status = "🟢 Active" if has_nitro else "🔴 None"
                payment_status = "🟢 Added" if has_payment_methods else "🔴 None"

                status_info = f"**Discord Nitro:** {nitro_status}\n"
                status_info += f"**Payment Methods:** {payment_status}\n"
                status_info += f"**Server Count:** `{guild_count}`"

                embed.add_field(
                    name="💎 Account Status",
                    value=status_info,
                    inline=True
                )

                # Connected Services
                if connections:
                    connection_types = [conn.get('type', 'unknown').title() for conn in connections]
                    connection_text = ', '.join(set(connection_types)) if connection_types else 'None'
                    embed.add_field(
                        name="🔗 Connected Services",
                        value=f"`{connection_text[:100]}{'...' if len(connection_text) > 100 else ''}`",
                        inline=False
                    )

                # Token Information
                token_parts = token.split('.')
                if len(token_parts) >= 2:
                    try:
                        import base64
                        user_id_from_token = base64.b64decode(token_parts[0] + '==').decode('utf-8')

                        token_info = f"**Token User ID:** `{user_id_from_token}`\n"
                        token_info += "**Token Status:** 🟢 Valid\n"
                        token_info += "**Token Type:** `User Token`\n"
                        token_info += f"**Analysis Time:** <t:{int(datetime.datetime.utcnow().timestamp())}:R>"

                        embed.add_field(
                            name="🎫 Token Details",
                            value=token_info,
                            inline=False
                        )
                    except:
                        pass

                # Set avatar if available
                if avatar_hash:
                    avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.png?size=256"
                    embed.set_thumbnail(url=avatar_url)

                # Set banner if available
                if banner_hash:
                    banner_url = f"https://cdn.discordapp.com/banners/{user_id}/{banner_hash}.png?size=512"
                    embed.set_image(url=banner_url)

                # Privacy warning footer
                embed.set_footer(
                    text="🔒 This information is private and secure • Token Info Command",
                    icon_url=self.client.user.avatar.url if self.client.user.avatar else None
                )

                # Add security warning for first token only
                if i == 1:
                    security_embed = discord.Embed(
                        title="⚠️ Security Notice",
                        description="```diff\n- Never share your Discord token with anyone\n- Tokens provide full access to your account\n- Keep your token private and secure\n+ This analysis was performed privately```",
                        color=0xffa502,
                        timestamp=datetime.datetime.utcnow()
                    )
                    security_embed.set_footer(text="Security is our priority")
                    embeds_to_send.append(security_embed)

                embeds_to_send.append(embed)

            except requests.exceptions.RequestException as e:
                embed = discord.Embed(
                    title=f"🌐 Network Error - Token #{i}",
                    description=f"```Failed to connect to Discord API\nError: {str(e)[:100]}```",
                    color=0xff4757,
                    timestamp=datetime.datetime.utcnow()
                )
                embed.add_field(
                    name="💡 Suggestions",
                    value="• Check your internet connection\n• Try again in a few moments\n• Verify Discord API status",
                    inline=False
                )
                embed.set_footer(text="Token Info • Private Command", icon_url=self.client.user.avatar.url if self.client.user.avatar else None)
                embeds_to_send.append(embed)
            except Exception as e:
                embed = discord.Embed(
                    title=f"❌ Unexpected Error - Token #{i}",
                    description=f"```An unexpected error occurred during analysis\nError: {str(e)[:100]}```",
                    color=0xffffff,
                    timestamp=datetime.datetime.utcnow()
                )
                embed.add_field(
                    name="🔧 What to do",
                    value="• Report this issue if it persists\n• Try with a different token\n• Contact support if needed",
                    inline=False
                )
                embed.set_footer(text="Token Info • Private Command", icon_url=self.client.user.avatar.url if self.client.user.avatar else None)
                embeds_to_send.append(embed)

        # Send all embeds (Discord allows up to 10 embeds per message)
        if embeds_to_send:
            # Split into chunks of 10 embeds if needed
            for chunk_start in range(0, len(embeds_to_send), 10):
                chunk = embeds_to_send[chunk_start:chunk_start + 10]
                await ctx.send(embeds=chunk, ephemeral=True)

async def setup(client):
    await client.add_cog(TokenInfo(client))
