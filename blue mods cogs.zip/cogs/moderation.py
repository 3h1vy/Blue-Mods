import discord
from discord import app_commands
from discord.ext import commands

import datetime
import typing
import bot_functions as bot
import checks as c
import format_time


class Moderation(commands.Cog):
  def __init__(self, client):
    self.client = client

  @commands.command(name="createrole", description="Creates a new role.", aliases=["crrole"], usage="createrole <name> [color]")
  @commands.has_permissions(manage_roles=True)
  @commands.guild_only()
  async def createrole(self, ctx, name: str, color: typing.Optional[discord.Color] = discord.Color.default()):
      try:
          role = await ctx.guild.create_role(name=name, color=color)
          await ctx.send(f"<:tick:1130455762867601469> Successfully created role `{role.name}`.")
      except discord.Forbidden:
          await ctx.send("<:cross:1130455801740406874> I don't have permission to create roles.")
      except discord.HTTPException as e:
          await ctx.send(f"<:cross:1130455801740406874> An error occurred while creating the role: {e}")
  @commands.command(name="deleterole", description="Deletes a specified role.", aliases=["delrole"],usage="deleterole <role>")
  @commands.has_permissions(manage_roles=True)
  @commands.guild_only()
  async def deleterole(self, ctx, role: discord.Role):
      try:
          await role.delete()
          await ctx.send(f"<:tick:1130455762867601469> Successfully deleted role `{role.name}`.")
      except discord.Forbidden:
          await ctx.send("<:cross:1130455801740406874> I don't have permission to delete roles.")
      except discord.HTTPException as e:
          await ctx.send(f"<:cross:1130455801740406874> An error occurred while deleting the role: {e}")


  @commands.command(name="createchannel", description="Creates a new channel within a category.", aliases=["addch", "crch"], usage="createchannel <text/voice> <name> <category>")
  @commands.has_permissions(manage_channels=True)
  @commands.guild_only()
  async def createchannel(self, ctx, channel_type: str, name: str, *, category_name: str):
      if channel_type.lower() not in ["text", "voice"]:
          await ctx.send("<:cross:1130455801740406874> Invalid channel type! Please use 'text' or 'voice'.")
          return
      category = discord.utils.get(ctx.guild.categories, name=category_name)
      if not category:
          await ctx.send(f"<:cross:1130455801740406874> Category '{category_name}' not found!")
          return
      if channel_type.lower() == "text":
          new_channel = await category.create_text_channel(name)
      else:
          new_channel = await category.create_voice_channel(name)
      await ctx.send(f"<:tick:1130455762867601469> Successfully created {channel_type} channel `{name}` in category `{category_name}`.")

  @commands.command(name="deletechannel", description="Deletes a channel.", aliases=["delch"], usage="deletechannel <channel>")
  @commands.has_permissions(manage_channels=True)
  @commands.guild_only()
  async def deletechannel(self, ctx, channel: typing.Union[discord.TextChannel, discord.VoiceChannel]):
      await channel.delete()
      await ctx.send(f"<:tick:1130455762867601469> Successfully deleted channel `{channel.name}`.")
    

  @commands.command(name="mute", description="Mutes a member.", aliases=["timeout"], usage="timeout <members/ids> [time] [reason]")
  @commands.guild_only()
  @commands.has_permissions(moderate_members=True)
  async def mute(self, ctx, members: commands.Greedy[discord.Member], time="1h",*, reason="No reason specified."):
    members = [*set(members)]
    if not members:
      await ctx.send("Provide atleast one @user/id.")
      return
    dtime = time
    time = format_time.format_time(time)
    if time.total_seconds() == 0:
      reason = f"{dtime} {reason}"
      time = format_time.format_time("1h")
    if time.total_seconds() > 60*60*24*28:
      em = discord.Embed(title="Error!", description="Timeout can't be more than 28days.", color = discord.Colour.red())
      await ctx.send(embed=em)
      return
    for member in members:
      if ctx.author.top_role.position <= member.top_role.position and ctx.author != ctx.guild.owner:
        await ctx.send(f"<:cross:1130455801740406874> You can't mute `{member}`.")
        continue
      try:
        await member.timeout(time, reason=f"{ctx.author}: {reason}")
        await ctx.send(f"<:tick:1130455762867601469> Successfully muted `{member}` for **{bot.clean_time(int(time.total_seconds()))}+**.")
      except:
        await ctx.send(f"<:cross:1130455801740406874> Unable to mute `{member}`.")


  @commands.command(name="unmute", description="Unmutes a member.", aliases=["untimeout"], usage="untimeout <members/ids> [reason]")
  @commands.has_permissions(moderate_members=True)
  @commands.guild_only()
  async def unmute(self, ctx, members: commands.Greedy[discord.Member],*, reason="No reason specified."):
    members = [*set(members)]
    if not members:
      await ctx.send("Provide atleast one @user/id.")
      return
    for member in members:
      if not member.is_timed_out():
        await ctx.send(f"<:cross:1130455801740406874> `{member}` is not muted.")
        continue
      await member.timeout(None, reason=f"{ctx.author}: {reason}")
      await ctx.send(f"<:tick:1130455762867601469> Successfully unmuted `{member}`.")


  @commands.command(name="kick", description="Kicks a member out.", usage="kick <members/ids> [reason]")
  @commands.has_permissions(kick_members = True)
  @commands.guild_only()
  async def kick(self, ctx, members: commands.Greedy[discord.Member], *, reason=""):
    members = [*set(members)]
    if not members:
      await ctx.send("Provide atleast one @user/id.")
      return
    for member in members:
      if ctx.author.top_role <= member.top_role and ctx.author != ctx.guild.owner:
        await ctx.send(f"<:cross:1130455801740406874> You don't have permission to kick `{member}`.")
        continue
      if member.top_role >= ctx.guild.me.top_role or ctx.guild.owner is member:
        await ctx.send(f"<:cross:1130455801740406874> I don't have permission to kick `{member}`.")
        continue

      try:
        await member.kick(reason=f"{ctx.author}: {reason}")
        await ctx.send(f"<:tick:1130455762867601469> Successfully kicked `{member}`.")
      except:
        await ctx.send(f"<:cross:1130455801740406874> I am unable to kick `{member}`.")


  @commands.command(name="ban", description="Bans a user.", aliases=["hackban"], usage="ban <users/ids> [days] [reason]")
  @commands.guild_only()
  @commands.has_permissions(ban_members=True)
  async def ban(self, ctx, users: commands.Greedy[discord.User], days: typing.Optional[int] = 1, *, reason="No reason specified."):
    users = [*set(users)]
    if not users:
      await ctx.send("Provide atleast one @user/id.")
      return
    for user in users:
      try:
        user = await commands.MemberConverter().convert(ctx, str(user.id))
        if ctx.author.top_role <= user.top_role and ctx.author != ctx.guild.owner:
          await ctx.send(f"<:cross:1130455801740406874> You don't have permission to ban `{user}`.")
          continue
        if user.top_role >= ctx.guild.me.top_role or ctx.guild.owner is user:
          await ctx.send(f"<:cross:1130455801740406874> I don't have permission to ban `{user}`.")
          continue
      except:
        pass

      if await c.is_banned(ctx, user):
        await ctx.send(f"<:cross:1130455801740406874> `{user}` is already banned.")
        continue

      try:
        await ctx.guild.ban(user, reason=f"{ctx.author}: {reason}", delete_message_days=days)
        await ctx.send(f"<:tick:1130455762867601469> Successfully banned `{user}`.")
      except:
        await ctx.send(f"<:tick:1130455762867601469> I am unable to ban `{user}`.")


  @commands.command(name="unban", description="Unbans a user.", usage="unban <users/ids> [reason]")
  @commands.guild_only()
  @commands.has_permissions(manage_guild=True)
  async def unban(self, ctx, users: commands.Greedy[discord.User], *, reason="No reason specified."):
    users = [*set(users)]
    if not users:
      await ctx.send("Provide atleast one @user/id.")
      return
    for user in users:
      if not await c.is_banned(ctx, user):
        await ctx.send(f"<:cross:1130455801740406874> `{user}` is not banned.")
        continue
      await ctx.guild.unban(user ,reason =f"{ctx.author}: {reason}")
      await ctx.send(f"<:tick:1130455762867601469> Successfully unbanned `{user}`.")


  @commands.hybrid_command(name="warn", description="Warns a user.", usage="warn <member/id> [reason]")
  @commands.has_permissions(manage_guild=True)
  @commands.guild_only()
  @app_commands.describe(member="Member you want to warn.", reason="A good reason for warning.")
  async def warn(self, ctx, member : discord.Member,*, reason="[No reason specified]"):
    if member.bot:
      await ctx.send("<:cross:1130455801740406874> You can't warn a bot!")
      return
    if member == ctx.author:
      await ctx.send("<:cross:1130455801740406874> You can't warn yourself!")
      return
    if ctx.author.top_role <= member.top_role and ctx.author != ctx.guild.owner:
      await ctx.send(f"<:cross:1130455801740406874> You can't warn `{member}`.")
      return
    if member == ctx.guild.owner:
      await ctx.send("<:cross:1130455801740406874> You can warn owner.")
      return

    embed = discord.Embed(color = discord.Colour.red())
    embed.set_author(name=f'{member} has been warned!',icon_url = member.display_avatar.url)
    embed.add_field(name="Reason", value=reason, inline=False)
    embed.add_field(name="Moderator", value=ctx.author.mention, inline=False)
    try :
      em = discord.Embed(title="Warning!", description=f"You have been warned in {ctx.guild.name}.", color=discord.Colour.red())
      em.add_field(name="Reason", value=f"{reason}", inline=False)
      em.add_field(name="Moderator", value=ctx.author.mention, inline=False)
      await member.send(embed=em)
    except:
      pass
    await ctx.send(member.mention, embed=embed)

  @commands.hybrid_command(name="dmuser", description="Reminds a user.", usage="dmuser <member/id> [reason]")
  @commands.has_permissions(manage_guild=True)
  @commands.guild_only()
  @app_commands.describe(member="Member you want to dm.", reason="A good reason to dm.")
  async def remind(self, ctx, member : discord.Member,*, reason="[No reason specified]"):
    await ctx.message.delete()
    if member.bot:
      await ctx.send("<:cross:1130455801740406874> You can't dm a bot!")
      return
    if member == ctx.author:
      await ctx.send("<:cross:1130455801740406874> You can't dm yourself!")
      return

    embed = discord.Embed(color = discord.Colour.blue())
    embed.set_author(name=f'{member} has been reminded!',icon_url = member.display_avatar.url)
    embed.add_field(name="Reason", value=reason, inline=False)
    embed.add_field(name="Moderator", value=ctx.author.mention, inline=False)
    try :
      em = discord.Embed(title="Reminder!", description=f"You are requested to come in {ctx.guild.name}.", color=discord.Colour.green())
      em.add_field(name="Channel", value=ctx.channel.mention, inline=False)
      em.add_field(name="Reason", value=f"{reason}", inline=False)
      await member.send(embed=em)
    except:
      pass
    await ctx.send(embed=embed)


  @commands.command(name="clear", description="Delete messages of a channel in a selected range.", aliases =['purge'], usage="clear [options] <range>")
  @commands.guild_only()
  @commands.has_permissions(manage_messages=True)
  async def clear(self, ctx, *, arguments):
    users, text = bot.filter(arguments)
    content_purge = False 
    simple = False
    limit = 100

    if users:
      try :
        limit = int(text.split(" ")[0])
      except :
        pass

    elif '"' in arguments:
      text_list = list(filter(None, arguments.split('"')))
      content = text_list[0]
      if f'"{content}"' in arguments:
        content_purge = True
      if len(text_list) > 1:
        try :
          limit = int(text_list[1].replace(" ", ""))
        except :
          pass
    else:
      simple = True
      arg = arguments.split(" ")
      if len(arg) > 1:
        try :
          limit = int(arg[1])
        except :
          pass
      try :
        limit = int(arg[0])
      except :
        simple = False

    if limit > 1000 :
      await ctx.send("<:cross:1130455801740406874> You can't delete more than **1000** messages at once.")
      return


    def is_human(message):
      return not message.author.bot and not message.pinned

    def is_bot(message):
      return message.author.bot and not message.pinned

    def is_user(message):
      return str(message.author.id) in users and not message.pinned

    def is_link(message):
      return any(link in message.content.lower().replace(" ", "") for link in ["https://", "http://", "discord.gg"]) and not message.pinned

    def is_invite(message):
      return "discord.gg/" in message.content.lower().replace(" ", "") and not message.pinned

    def has_content(message):
      return content.lower() in message.content.lower() and not message.pinned

    def is_media(message):
      return message.attachments and not message.pinned

    def is_embed(message):
      return message.embeds and not message.pinned

    def is_pin(message):
      return not message.pinned

    await ctx.message.delete()

    if simple:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.now()-datetime.timedelta(days=14),
      oldest_first = False,
      check = is_pin

      )

    elif content_purge:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.now()-datetime.timedelta(days=14),
      oldest_first = False,
      check = has_content

      )

    elif users:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.now()-datetime.timedelta(days=14),
      oldest_first = False,
      check = is_user

      )

    elif arg[0] in ["bot","bots","nonhuman"]:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.now()-datetime.timedelta(days=14),
      oldest_first = False,
      check = is_bot

      )

    elif arg[0] in ["human","humans"]:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.now()-datetime.timedelta(days=14),
      oldest_first = False,
      check = is_human

      )

    elif arg[0] in ["link","links"]:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.now()-datetime.timedelta(days=14),
      oldest_first = False,
      check = is_link

      )

    elif arg[0] in ["invite","invites"]:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.now()-datetime.timedelta(days=14),
      oldest_first = False,
      check = is_invite

      )

    elif arg[0] in ["media","attachment", "attachments", "image", "images"]:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.now()-datetime.timedelta(days=14),
      oldest_first = False,
      check = is_media

      )

    elif arg[0] in ["embed","embeds"]:
      purged = await ctx.channel.purge(

      limit = limit,
      after = datetime.datetime.utcnow()-datetime.timedelta(days=14),
      oldest_first = False,
      check = is_embed

      )

    else :
      await ctx.send(f"<:cross:1130455801740406874> Invalid command!, use `{ctx.prefix}help` for command info.")
      return

    if len(purged) == 0:
      message = await ctx.send("<:cross:1130455801740406874> No message found!")
    else:
      message = await ctx.send(f"<:tick:1130455762867601469> Successfully deleted **{len(purged)}** messages.")
    
    await discord.utils.sleep_until(discord.utils.utcnow() + datetime.timedelta(seconds=3))
    await message.delete()

async def setup(client):
  await client.add_cog(Moderation(client))