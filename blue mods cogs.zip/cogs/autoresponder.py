
import discord
from discord.ext import commands
import json
import datetime
import re

class Autoresponder(commands.Cog):
    def __init__(self, client):
        self.client = client
        try:
            with open('autoresponder.json', 'r') as f:
                self.autoresponses = json.load(f)
        except FileNotFoundError:
            self.autoresponses = {}
            self.save_responses()

    def save_responses(self):
        with open('autoresponder.json', 'w') as f:
            json.dump(self.autoresponses, f, indent=4)

    @commands.group(name="autoresponder", description="Manage autoresponses", aliases=["ar"], usage="autoresponder <subcommand>")
    @commands.has_permissions(manage_messages=True)
    @commands.guild_only()
    async def autoresponder(self, ctx):
        if ctx.invoked_subcommand is None:
            em = discord.Embed(
                title="Autoresponder Help",
                description="Available subcommands:",
                color=discord.Color.blue()
            )
            em.add_field(
                name="add <trigger> <response>", 
                value="Add a new autoresponse\nUse {user} for mentioning user\nUse {channel} for channel mention\nUse {server} for server name",
                inline=False
            )
            em.add_field(
                name="delete <trigger>",
                value="Delete an autoresponse",
                inline=False
            )
            em.add_field(
                name="list",
                value="List all autoresponses",
                inline=False
            )
            await ctx.send(embed=em)

    @autoresponder.command(name="add", aliases=["a"])
    async def add_response(self, ctx, trigger: str, *, response: str):
        guild_id = str(ctx.guild.id)
        
        if guild_id not in self.autoresponses:
            self.autoresponses[guild_id] = {}
            
        # Check for existing trigger
        if trigger.lower() in self.autoresponses[guild_id]:
            em = discord.Embed(
                title="Error",
                description="This trigger already exists!",
                color=discord.Color.red()
            )
            await ctx.send(embed=em)
            return

        # Add the autoresponse with metadata
        self.autoresponses[guild_id][trigger.lower()] = {
            "response": response,
            "created_by": ctx.author.id,
            "created_at": datetime.datetime.utcnow().isoformat(),
            "uses": 0
        }
        
        self.save_responses()
        
        em = discord.Embed(
            title="Success",
            description=f"Added new autoresponse!",
            color=discord.Color.green()
        )
        em.add_field(name="Trigger", value=trigger, inline=False)
        em.add_field(name="Response", value=response, inline=False)
        await ctx.send(embed=em)

    @autoresponder.command(name="delete", aliases=["d", "del", "remove"])
    async def delete_response(self, ctx, trigger: str):
        guild_id = str(ctx.guild.id)
        
        if guild_id not in self.autoresponses or trigger.lower() not in self.autoresponses[guild_id]:
            em = discord.Embed(
                title="Error",
                description="This trigger doesn't exist!",
                color=discord.Color.red()
            )
            await ctx.send(embed=em)
            return
            
        del self.autoresponses[guild_id][trigger.lower()]
        self.save_responses()
        
        em = discord.Embed(
            title="Success",
            description=f"Deleted autoresponse with trigger: {trigger}",
            color=discord.Color.green()
        )
        await ctx.send(embed=em)

    @autoresponder.command(name="list", aliases=["l", "show"])
    async def list_responses(self, ctx):
        guild_id = str(ctx.guild.id)
        
        if guild_id not in self.autoresponses or not self.autoresponses[guild_id]:
            em = discord.Embed(
                title="Autoresponses",
                description="No autoresponses set up!",
                color=discord.Color.blue()
            )
            await ctx.send(embed=em)
            return
            
        # Create paginated embeds
        responses_per_page = 5
        responses = list(self.autoresponses[guild_id].items())
        pages = []
        
        for i in range(0, len(responses), responses_per_page):
            em = discord.Embed(
                title=f"Autoresponses (Page {len(pages)+1})",
                color=discord.Color.blue()
            )
            
            for trigger, data in responses[i:i+responses_per_page]:
                creator = await self.client.fetch_user(data['created_by'])
                em.add_field(
                    name=f"Trigger: {trigger}",
                    value=f"Response: {data['response']}\n"
                          f"Created by: {creator}\n"
                          f"Uses: {data['uses']}\n"
                          f"Created: <t:{int(datetime.datetime.fromisoformat(data['created_at']).timestamp())}:R>",
                    inline=False
                )
            pages.append(em)
            
        if len(pages) == 1:
            await ctx.send(embed=pages[0])
            return
            
        # Add navigation buttons
        current_page = 0
        
        view = discord.ui.View()
        
        async def previous_callback(interaction):
            nonlocal current_page
            if interaction.user != ctx.author:
                return
            current_page = (current_page - 1) % len(pages)
            await interaction.response.edit_message(embed=pages[current_page])
            
        async def next_callback(interaction):
            nonlocal current_page
            if interaction.user != ctx.author:
                return
            current_page = (current_page + 1) % len(pages)
            await interaction.response.edit_message(embed=pages[current_page])
            
        prev_button = discord.ui.Button(label="Previous", style=discord.ButtonStyle.gray)
        next_button = discord.ui.Button(label="Next", style=discord.ButtonStyle.gray)
        
        prev_button.callback = previous_callback
        next_button.callback = next_callback
        
        view.add_item(prev_button)
        view.add_item(next_button)
        
        await ctx.send(embed=pages[0], view=view)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
            
        guild_id = str(message.guild.id)
        if guild_id not in self.autoresponses:
            return
            
        content = message.content.lower()
        for trigger, data in self.autoresponses[guild_id].items():
            if trigger in content:
                response = data["response"]
                # Handle placeholders
                response = response.replace("{user}", message.author.mention)
                response = response.replace("{channel}", message.channel.mention)
                response = response.replace("{server}", message.guild.name)
                
                # Update usage count
                self.autoresponses[guild_id][trigger]["uses"] += 1
                self.save_responses()
                
                # Send response
                await message.channel.send(response)
                break

async def setup(client):
    await client.add_cog(Autoresponder(client))
