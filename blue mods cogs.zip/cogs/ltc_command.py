
import discord
from discord.ext import commands
from discord import app_commands
import requests
import datetime

class LTCTransactionView(discord.ui.View):
    def __init__(self, address, ltc_price_usd):
        super().__init__(timeout=300)
        self.address = address
        self.ltc_price_usd = ltc_price_usd

    @discord.ui.button(label="View Transactions", style=discord.ButtonStyle.primary, emoji="📊")
    async def view_transactions(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()

        try:
            # Fetch transaction data from BlockCypher API
            tx_url = f"https://api.blockcypher.com/v1/ltc/main/addrs/{self.address}/full?limit=10"
            tx_response = requests.get(tx_url, timeout=15)

            if tx_response.status_code != 200:
                raise Exception("Failed to fetch transaction data")

            tx_data = tx_response.json()
            transactions = tx_data.get('txs', [])

            if not transactions:
                embed = discord.Embed(
                    title="No Transactions Found",
                    description="No recent transactions found for this address.",
                    color=0xff9900
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return

            # Create transaction history embed
            embed = discord.Embed(
                title="📊 Last 5 Transactions",
                description=f"Recent transactions for address: `{self.address}`",
                color=0xffffff,
                timestamp=datetime.datetime.utcnow()
            )

            transaction_list = []
            for i, tx in enumerate(transactions[:5], 1):
                # Calculate transaction amount for this address
                total_input = 0
                total_output = 0
                is_incoming = False

                # Check inputs
                for input_tx in tx.get('inputs', []):
                    for addr in input_tx.get('addresses', []):
                        if addr == self.address:
                            total_input += input_tx.get('output_value', 0)

                # Check outputs
                for output in tx.get('outputs', []):
                    for addr in output.get('addresses', []):
                        if addr == self.address:
                            total_output += output.get('value', 0)
                            is_incoming = True

                # Calculate net amount
                if is_incoming and total_input == 0:
                    # Pure incoming transaction
                    amount_satoshis = total_output
                    direction = "📥"
                elif total_input > 0:
                    # Outgoing transaction
                    amount_satoshis = total_input - total_output
                    direction = "📤"
                else:
                    amount_satoshis = 0
                    direction = "↔️"

                amount_ltc = amount_satoshis / 100000000
                amount_usd = amount_ltc * self.ltc_price_usd

                # Get transaction status
                confirmations = tx.get('confirmations', 0)
                if confirmations >= 6:
                    status = "✅ Confirmed"
                elif confirmations > 0:
                    status = f"🟡 {confirmations} confirmations"
                else:
                    status = "🔄 Pending"

                # Format transaction date
                tx_time = tx.get('received', tx.get('confirmed', ''))
                if tx_time:
                    try:
                        tx_datetime = datetime.datetime.fromisoformat(tx_time.replace('Z', '+00:00'))
                        formatted_time = tx_datetime.strftime('%m/%d/%y %H:%M')
                    except:
                        formatted_time = "Unknown"
                else:
                    formatted_time = "Unknown"

                # Get transaction hash (shortened)
                tx_hash = tx.get('hash', 'Unknown')
                short_hash = f"{tx_hash[:8]}...{tx_hash[-8:]}" if len(tx_hash) > 16 else tx_hash

                transaction_info = f"`{i}.` {direction} **{amount_ltc:.6f} LTC** (${amount_usd:.2f})\n"
                transaction_info += f"    📅 {formatted_time} | {status} | [link](https://live.blockcypher.com/ltc/tx/{tx_hash}/)\n"

                transaction_list.append(transaction_info)

            # Add transactions to embed
            if transaction_list:
                embed.add_field(
                    name="Recent Transactions",
                    value="\n".join(transaction_list),
                    inline=False
                )

            embed.set_footer(text="💡 Click 'View on Explorer' for full transaction details")

            # Create view with explorer button
            view = discord.ui.View()
            view.add_item(discord.ui.Button(
                label="View on Explorer", 
                url=f"https://live.blockcypher.com/ltc/address/{self.address}/",
                style=discord.ButtonStyle.url
            ))

            await interaction.followup.send(embed=embed, view=view, ephemeral=True)

        except Exception as e:
            error_embed = discord.Embed(
                title="Error",
                description=f"Failed to fetch transaction data: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=error_embed, ephemeral=True)

class LTCCommand(commands.Cog):
    def __init__(self, client):
        self.client = client

    @app_commands.command(name="ltc", description="Check Litecoin balance for the default address")
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    async def ltc_balance(self, interaction: discord.Interaction):
        """Check Litecoin balance for the default address"""
        await interaction.response.defer()

        # The specific Litecoin address
        address = "ltc1qw8pmz09wznw2230ufrk40pvc9qynlmkdmvx7yt"

        try:
            # Get current LTC price in USD from CoinGecko
            price_url = "https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd"
            price_response = requests.get(price_url, timeout=10)
            if price_response.status_code != 200:
                raise Exception("CoinGecko API is unavailable")
            price_data = price_response.json()
            ltc_price_usd = price_data['litecoin']['usd']

            # Using BlockCypher API to fetch address data
            api_url = f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}"
            response = requests.get(api_url, timeout=10)
            if response.status_code != 200:
                raise Exception("BlockCypher API is unavailable")
            data = response.json()

            # Calculate LTC amounts (from satoshis to LTC)
            balance_ltc = data.get('balance', 0) / 100000000
            unconfirmed_balance_ltc = data.get('unconfirmed_balance', 0) / 100000000
            total_received_ltc = data.get('total_received', 0) / 100000000

            # Calculate value in USD
            balance_usd = balance_ltc * ltc_price_usd
            unconfirmed_usd = unconfirmed_balance_ltc * ltc_price_usd
            total_received_usd = total_received_ltc * ltc_price_usd

            # Create embed matching the reference image style with white color
            em = discord.Embed(title="LiteCoin Balance", color=0xffffff)

            # Add wallet address section
            em.add_field(
                name="Wallet Address",
                value=f"{address}",
                inline=False
            )

            # Add current balance section with arrow emoji
            em.add_field(
                name="<:online:1130473071552245801> Current Balance",
                value=f"• LTC - {balance_ltc:.8f}\n• USD - {balance_usd:.2f}",
                inline=False
            )

            # Add unconfirmed balance section with arrow emoji
            em.add_field(
                name="<:idle:1130473039017017355> Unconfirmed Balance",
                value=f"• LTC - {unconfirmed_balance_ltc:.8f}\n• USD - {unconfirmed_usd:.2f}",
                inline=False
            )

            # Add total received section with arrow emoji
            em.add_field(
                name="<:invisible:1130474032840577094> Total Received",
                value=f"• LTC - {total_received_ltc:.8f}\n• USD - {total_received_usd:.2f}",
                inline=False
            )

            # Create view with both explorer and transaction buttons
            view = LTCTransactionView(address, ltc_price_usd)
            view.add_item(discord.ui.Button(
                label="View on Explorer", 
                url=f"https://live.blockcypher.com/ltc/address/{address}/",
                style=discord.ButtonStyle.url
            ))

            await interaction.followup.send(embed=em, view=view)

        except Exception as e:
            em = discord.Embed(
                title="Error",
                description=f"Failed to fetch Litecoin address data: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=em)

async def setup(client):
    await client.add_cog(LTCCommand(client))
