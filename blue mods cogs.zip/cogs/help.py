import discord
from discord.ext import commands
from discord.ui import View, Button, Select
from discord import app_commands
import typing

class CategorySelect(Select):
    def __init__(self, help_view):
        self.help_view = help_view
        options = [
            discord.SelectOption(label="Home", description="Main help page", emoji="<:home:1348177131800100958>"),
            discord.SelectOption(label="Moderation", description="Moderation commands", emoji="<:emote:1348174752002347110>"),
            discord.SelectOption(label="Tools", description="Tool commands", emoji="<:emote:1348174750177820794>"),
            discord.SelectOption(label="Misc", description="Miscellaneous commands", emoji="<:emote:1348175315477860382>"),
            discord.SelectOption(label="Role", description="Role management commands", emoji="<:emote:1348174478328205313>"),
            discord.SelectOption(label="Voice", description="Voice channel commands", emoji="<:voice:1130456158168162305>"),
            discord.SelectOption(label="Fun", description="Fun commands", emoji="<:emote:1348174341036052520>"),
            discord.SelectOption(label="Configs", description="Configuration commands", emoji="<:emote:1348175922779389963>")
        ]
        super().__init__(placeholder="Select a category...", options=options, custom_id="category_select")

    async def callback(self, interaction: discord.Interaction):
        category = self.values[0]
        await interaction.response.defer()
        await self.help_view.update_embed(interaction, category)

class HelpView(View):
    def __init__(self, ctx, timeout=60):
        super().__init__(timeout=timeout)
        self.ctx = ctx
        self.add_item(CategorySelect(self))

        # Mappings for category commands
        self.category_commands = {
            "Moderation": "```purge | warn | remind | mute | unmute | kick | ban | unban```",
            "Tools": "```announce | channelname | addchannel | delchannel | hide | unhide | lockdown | unlockdown | slowmode | deleterole | createrole | role | afk | nickname | emoji | steal | sticker | remind | reminders | delreminder```",
            "Misc": "```ping | invite | avatar | membercount | userinfo | roleinfo | serverinfo | firstmessage | banner | boosters```",
            "Role": "```role add | role remove | role reset | role everyone | role human | role bot | role target | role position | role icon | role rename```",
            "Voice": "```voice mute | voice unmute | voice kick | voice deafen | voice undeafen | voice move | voice hide | voice unhide | voice lock | voice unlock```",
            "Fun": "```coinflip | roll | enlarge | kiss | slap | cuddle | bite | kill | bully | thanos | truth | dare | joke | fact | typingrace | pat | poke | dance | choose | rps | highfive | cry | wink | blush | yawn | wave | punch```",
            "Configs": "```prefix set | prefix off | unbanall | setwelcome | testwelcome | sticky | autoresponder add | autoresponder delete | autoresponder list```"
        }

        # Emoji mappings
        self.category_emojis = {
            "Moderation": "<:emote:1348174752002347110>",
            "Tools": "<:emote:1348174750177820794>",
            "Misc": "<:emote:1348175315477860382>",
            "Role": "<:emote:1348174478328205313>",
            "Voice": "<:voice:1130456158168162305>",
            "Fun": "<:emote:1348174341036052520>",
            "Configs": "<:emote:1348175922779389963>"
        }

    async def update_embed(self, interaction, category):
        if category == "Home":
            em = discord.Embed(
                title="Bot Commands",
                description=f"Use `{self.ctx.prefix}help <command>` for more information on a command.",
                color=discord.Colour.blurple()
            )
            em.set_thumbnail(url=self.ctx.bot.user.display_avatar.url)
            em.set_author(name=self.ctx.bot.user.name, icon_url=self.ctx.bot.user.display_avatar.url)

            # Show only category names
            categories = []
            for cat_name in self.category_commands.keys():
                emoji = self.category_emojis.get(cat_name, "")
                categories.append(f"{emoji} **{cat_name}**")

            em.add_field(name="Categories", value="\n".join(categories), inline=False)

            em.set_footer(text=f'Requested by {self.ctx.author}', icon_url=self.ctx.bot.user.display_avatar.url)
        else:
            em = discord.Embed(
                title=f"{self.category_emojis.get(category, '')} {category} Commands", 
                description=self.category_commands.get(category, "No commands found."),
                color=discord.Colour.blue()
            )
            em.set_author(name=self.ctx.bot.user.name, icon_url=self.ctx.bot.user.display_avatar.url)
            em.set_footer(text=f'Requested by {self.ctx.author}', icon_url=self.ctx.bot.user.display_avatar.url)

        await interaction.message.edit(embed=em)

class Help(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.hybrid_command(name="help", description="Display commands list.", usage="help [command]")
    @app_commands.describe(command_name="Name of the command.")
    @app_commands.rename(command_name="command")
    async def help(self, ctx, *, command_name=None):
        if command_name:
            command = self.client.get_command(command_name.lower())
            if not command:
                await ctx.send(f"<:cross:1130455801740406874> No command called `{command_name}` found!", mention_author=False)
                return

            em = discord.Embed(color=discord.Colour.dark_theme())
            em.set_author(name=f"{command} command", icon_url=ctx.me.display_avatar.url)
            em.add_field(name="<:online:1130473071552245801> Instructions", value=">>> Required: `<>`\nOptional: `[]`\nDo not type this when using commands.", inline=False)
            em.add_field(name="<:idle:1130473039017017355> Usage", value=f"> `{ctx.prefix}{command.usage}`", inline=False)
            em.add_field(name="<:dnd:1130472983077601330> Aliases", value=f"> `{', '.join(a for a in command.aliases) or 'None'}`", inline=False)
            em.add_field(name="<:invisible:1130474032840577094> Description", value=f"> `{command.description}`", inline=False)

            if command.name == "clear":
                em.add_field(name="<:Emisc:970964829038854224> Options", value=">>> `clear <range>\nclear [@user1/id1 @user2/id2...] <range>\nclear [\"some text\"] <range>\nclear human <range>\nclear bot <range>\nclear embed <range>\nclear link <range>\nclear invite <range>\nclear media <range>`", inline=False)

            em.set_footer(text=f"Requested by {ctx.author}.")
            await ctx.send(embed=em)

        else:
            # Create the initial home page embed
            em = discord.Embed(
                title="Help Command",
                description=f"Use `{ctx.prefix}help <command>` for more information on a command.\nSelect a category from the dropdown to view its commands.", 
                color=discord.Colour.blue()
            )
            em.set_author(name=self.client.user.name, icon_url=self.client.user.display_avatar.url)

            view = HelpView(ctx)

            # Add only category names to home page
            categories_list = []
            for cat_name in view.category_commands.keys():
                emoji = view.category_emojis.get(cat_name, "")
                categories_list.append(f"{emoji} **{cat_name}**")

            em.add_field(name="Categories", value="\n".join(categories_list), inline=False)

            em.set_footer(text=f'Requested by {ctx.author}', icon_url=self.client.user.display_avatar.url)
            await ctx.send(embed=em, view=view)

    @commands.hybrid_command(name="invite", description="Display invite links.", usage="invite", aliases=["links"])
    async def invite(self, ctx):
        em = discord.Embed(
            title="Invite Links", 
            description=f"[Invite Link (Custom perms)](https://discord.com/api/oauth2/authorize?client_id=1130447733493350411&permissions=8&scope=bot)\n[Invite Link (Admin perms)](https://discord.com/api/oauth2/authorize?client_id=1130447733493350411&permissions=8&scope=bot)\n[Support Server](https://discord.gg/VGSY8FfgGU)", 
            color=discord.Colour.blue()
        )
        button = Button(label="Developed by .patchyy", disabled=True)
        view = View()
        view.add_item(button)
        await ctx.send(embed=em, view=view)

async def setup(client):
    await client.add_cog(Help(client))