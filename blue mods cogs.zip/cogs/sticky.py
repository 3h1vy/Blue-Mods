import discord
from discord.ext import commands
import datetime

class Sticky(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.sticky_messages = {}  # Store sticky message info
        self.last_sticky_message = {}  # Track last sticky message
        print("Sticky cog loaded!")

    @commands.command(name="sticky", description="Set a sticky message for the channel")
    @commands.has_permissions(manage_messages=True)
    async def sticky(self, ctx, mode: str = None, *, message=None):
        if message is None:
            if ctx.channel.id in self.sticky_messages:
                del self.sticky_messages[ctx.channel.id]
                if ctx.channel.id in self.last_sticky_message:
                    try:
                        old_msg = await ctx.channel.fetch_message(self.last_sticky_message[ctx.channel.id])
                        await old_msg.delete()
                        del self.last_sticky_message[ctx.channel.id]
                    except:
                        pass
                embed = discord.Embed(description="<:tick:1130455762867601469> Sticky message removed from this channel.", color=discord.Color.blue())
                await ctx.send(embed=embed)
                return
            else:
                embed = discord.Embed(description="<:cross:1130455801740406874> Please use `sticky <embed/normal> <message>`", color=discord.Color.blue())
                await ctx.send(embed=embed)
                return

        if mode.lower() not in ['embed', 'normal']:
            embed = discord.Embed(description="<:cross:1130455801740406874> Mode must be either `embed` or `normal`", color=discord.Color.blue())
            await ctx.send(embed=embed)
            return

        if mode.lower() == 'embed':
            embed = discord.Embed(description=message, color=0x1590FF, timestamp=datetime.datetime.utcnow())
            embed.set_footer(text=f"Set by {ctx.author}", icon_url=ctx.author.display_avatar.url)
            self.sticky_messages[ctx.channel.id] = {'mode': 'embed', 'content': embed}
            sticky_msg = await ctx.send(embed=embed)
        else:
            formatted_msg = f"{message}"
            self.sticky_messages[ctx.channel.id] = {'mode': 'normal', 'content': formatted_msg}
            sticky_msg = await ctx.send(formatted_msg)

        self.last_sticky_message[ctx.channel.id] = sticky_msg.id
        confirm_embed = discord.Embed(description="<:tick:1130455762867601469> Sticky message set for this channel!", color=discord.Color.green())
        await ctx.send(embed=confirm_embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        channel_id = message.channel.id
        if channel_id in self.sticky_messages:
            if channel_id in self.last_sticky_message:
                try:
                    old_message = await message.channel.fetch_message(self.last_sticky_message[channel_id])
                    await old_message.delete()
                except (discord.NotFound, discord.Forbidden, discord.HTTPException):
                    pass

            if self.sticky_messages[channel_id]['mode'] == 'embed':
                sticky_msg = await message.channel.send(embed=self.sticky_messages[channel_id]['content'])
            else:
                sticky_msg = await message.channel.send(self.sticky_messages[channel_id]['content'])
            self.last_sticky_message[channel_id] = sticky_msg.id

    @commands.command(name="liststicky", aliases=["stickylist"], description="List all sticky messages in the server")
    @commands.has_permissions(manage_messages=True)
    async def liststicky(self, ctx):
        sticky_channels = [ch for ch in ctx.guild.channels if ch.id in self.sticky_messages]
        if not sticky_channels:
            embed = discord.Embed(
                description="<:cross:1130455801740406874> No sticky messages found in this server.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        embed = discord.Embed(
            title="📌 Sticky Messages in Server",
            color=0x1590FF,
            timestamp=datetime.datetime.utcnow()
        )

        for channel in sticky_channels:
            sticky_info = self.sticky_messages[channel.id]
            content = sticky_info['content']
            if sticky_info['mode'] == 'embed':
                content = content.description if hasattr(content, 'description') else "Embed message"
            field_value = f"**Mode:** {sticky_info['mode']}\n**Content:** {content[:500]}..."
            embed.add_field(name=f"#{channel.name}", value=field_value, inline=False)

        await ctx.send(embed=embed)


async def setup(client):
    await client.add_cog(Sticky(client))