import discord
from discord.ext import commands
import json
import datetime

class Welcome(commands.Cog):
    def __init__(self, client):
        self.client = client
        try:
            with open('welcome_config.json', 'r') as f:
                self.config = json.load(f)
        except FileNotFoundError:
            self.config = {}
            self.save_config()

    def save_config(self):
        with open('welcome_config.json', 'w') as f:
            json.dump(self.config, f, indent=4)

    @commands.command(name="setwelcome", aliases=["greet"], description="Set up welcome message configuration")
    @commands.has_permissions(administrator=True)
    async def setwelcome(self, ctx):
        try:
            embed = discord.Embed(title="Welcome Message Setup", color=0xFF0000)
            embed.description = "Please answer the following questions to set up the welcome message.\nType 'cancel' at any time to cancel setup."
            await ctx.send(embed=embed)

            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel

            # Message content
            await ctx.send("Enter the welcome embed message (use {user} for mention, {server} for server name, {count} for member count):")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            embed_msg = msg.content

            # Embed title
            await ctx.send("Enter the embed title (or 'skip' to skip):")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            title = None if msg.content.lower() == 'skip' else msg.content

            # Embed color
            await ctx.send("Enter the embed color in hex format (e.g., #FF0000) or 'skip' for default:")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            color = 0xFF0000 if msg.content.lower() == 'skip' else int(msg.content.strip('#'), 16)

            # Image
            await ctx.send("Enter the welcome image URL (or 'skip' to skip):")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            image = None if msg.content.lower() == 'skip' else msg.content

            # Thumbnail
            await ctx.send("Enter the thumbnail URL (or 'skip' to skip):")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            thumbnail = None if msg.content.lower() == 'skip' else msg.content

            # Footer
            await ctx.send("Enter the footer text (or 'skip' to skip):")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            footer = None if msg.content.lower() == 'skip' else msg.content

            # Additional message
            await ctx.send("Enter the non-embed welcome message (or 'skip' to skip):")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            plain_msg = None if msg.content.lower() == 'skip' else msg.content

            # Welcome channel
            await ctx.send("Enter the welcome channel ID:")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            channel_id = msg.content

            # Auto role
            await ctx.send("Enter the role ID to automatically assign to new members (or 'skip' to skip):")
            msg = await self.client.wait_for('message', check=check, timeout=300)
            if msg.content.lower() == 'cancel':
                return await ctx.send("<:cross:1130455801740406874> Setup cancelled.")
            auto_role = None if msg.content.lower() == 'skip' else msg.content

            self.config[str(ctx.guild.id)] = {
                'embed_msg': embed_msg,
                'title': title,
                'color': color,
                'image': image,
                'thumbnail': thumbnail,
                'footer': footer,
                'plain_msg': plain_msg,
                'channel_id': channel_id,
                'auto_role': auto_role
            }
            self.save_config()

            await ctx.send("<:tick:1130455762867601469> Welcome message configuration saved!")

        except TimeoutError:
            await ctx.send("<:cross:1130455801740406874> Setup timed out. Please try again.")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if str(member.guild.id) not in self.config:
            return

        config = self.config[str(member.guild.id)]
        channel = self.client.get_channel(int(config['channel_id'])) if config.get('channel_id') else member.guild.system_channel

        if not channel:
            return

        # Replace placeholders
        description = config['embed_msg'].replace('{user}', member.mention)
        description = description.replace('{server}', member.guild.name)
        description = description.replace('{count}', str(member.guild.member_count))

        embed = discord.Embed(
            title=config.get('title'),
            description=description,
            color=config.get('color', 0xFF0000),
            timestamp=datetime.datetime.utcnow()
        )

        if config.get('image'):
            embed.set_image(url=config['image'])

        if config.get('thumbnail'):
            embed.set_thumbnail(url=config['thumbnail'])

        if config.get('footer'):
            embed.set_footer(text=f"{config['footer']} • {datetime.datetime.utcnow().strftime('%I:%M %p')}")

        content = None
        if config.get('plain_msg'):
            content = config['plain_msg'].replace('{user}', member.mention)
            content = content.replace('{server}', member.guild.name)
            content = content.replace('{count}', str(member.guild.member_count))

        await channel.send(content=content, embed=embed)

        # Auto role assignment
        if config.get('auto_role'):
            try:
                role = member.guild.get_role(int(config['auto_role']))
                if role:
                    await member.add_roles(role)
            except Exception as e:
                print(f"Failed to assign role: {e}")

    @commands.command(name="testwelcome", aliases=["testgreet"], description="Test the welcome message")
    @commands.has_permissions(administrator=True)
    async def testwelcome(self, ctx):
        if str(ctx.guild.id) not in self.config:
            return await ctx.send("<:cross:1130455801740406874> Welcome message not configured! Use `setwelcome` first.")


    @commands.command(name="listwelcome", aliases=["licommandsstgreet"], description="List all configured welcomemessages")
    @commands.has_permissions(administrator=True)
    async def listwelcomes(self, ctx):
        if not self.config:
            return await ctx.send("<:cross:1130455801740406874> No welcome messages configured in any server.")
        
        embed = discord.Embed(title="Welcome Message Configurations", color=0x438EFF)
        
        for guild_id, config in self.config.items():
            try:
                guild = self.client.get_guild(int(guild_id))
                guild_name = guild.name if guild else f"Unknown Server ({guild_id})"
                
                channel = self.client.get_channel(int(config['channel_id'])) if config.get('channel_id') else None
                channel_mention = channel.mention if channel else "Channel not found"
                
                field_value = f"Channel: {channel_mention}\n"
                if config.get('embed_msg'):
                    field_value += f"Embed Message: ```{config['embed_msg'][:500]}```\n"
                if config.get('plain_msg'):
                    field_value += f"Plain Message: ```{config['plain_msg'][:200]}```\n"
                if config.get('auto_role'):
                    role = guild.get_role(int(config['auto_role'])) if guild else None
                    field_value += f"Auto Role: {role.mention if role else 'Role not found'}\n"
                
                embed.add_field(name=guild_name, value=field_value, inline=False)
            except Exception as e:
                embed.add_field(name=f"Error in server {guild_id}", value=str(e), inline=False)
        
        await ctx.send(embed=embed)

        config = self.config[str(ctx.guild.id)]
        channel = self.client.get_channel(int(config['channel_id']))

        if not channel:
            return await ctx.send("<:cross:1130455801740406874> Welcome channel not found! Please reconfigure using `setwelcome`")

        description = config['embed_msg'].replace('{user}', ctx.author.mention)
        description = description.replace('{server}', ctx.guild.name)
        description = description.replace('{count}', str(ctx.guild.member_count))

        embed = discord.Embed(
            title=config.get('title'),
            description=description,
            color=config.get('color', 0x438EFF),
            timestamp=datetime.datetime.utcnow()
        )

        if config.get('image'):
            embed.set_image(url=config['image'])

        if config.get('thumbnail'):
            embed.set_thumbnail(url=config['thumbnail'])

        if config.get('footer'):
            embed.set_footer(text=f"{config['footer']} • {datetime.datetime.utcnow().strftime('%I:%M %p')}")

        content = None
        if config.get('plain_msg'):
            content = config['plain_msg'].replace('{user}', ctx.author.mention)
            content = content.replace('{server}', ctx.guild.name)
            content = content.replace('{count}', str(ctx.guild.member_count))

        await channel.send(content=content, embed=embed)
        await ctx.send("<:tick:1130455762867601469> Test welcome message sent!")

async def setup(client):
    await client.add_cog(Welcome(client))
    

