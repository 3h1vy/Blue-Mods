import discord
from discord import app_commands
from discord.ext import commands

import datetime
import random
import asyncio

import requests

import bot_functions as bot


class Fun(commands.Cog):
  def __init__(self, client):
    self.client = client

  @commands.hybrid_command(name="roll", description="Rolls a dice.", aliases=["dice"], usage="roll [limit]")
  @commands.guild_only()
  @app_commands.describe(limit="Range of the dice.")
  async def roll(self, ctx, limit = 6):
    value = random.randint(1, limit)
    await ctx.send(f'{ctx.author.mention} rolled: **{value}** ||(1-{limit})||')

  @commands.hybrid_command(name="coinflip", description="Flips a coin.", aliases=["cf"], usage="coinflip")
  @commands.guild_only()
  async def coinflip(self, ctx):
    possibilities = ["Head!","Tail!"]
    result = random.choice(possibilities)
    await ctx.send(f'{ctx.author.mention} flipped a coin: **{result}**')

  @commands.hybrid_command(name="kiss", description="Kisses a user.", usage="kiss <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to kiss.")
  async def kiss(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime kiss")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} kissed {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}",embed=em)

  @commands.hybrid_command(name="cuddle", description="Cuddles a user.", usage="cuddle <member>", aliases=["hug"])
  @commands.guild_only()
  @app_commands.describe(user="User you want to cuddle.")
  async def cuddle(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime hug")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} cuddled {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}",embed=em)

  @commands.hybrid_command(name="slap", description="Slaps a user.", usage="slap <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to slap.")
  async def slap(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime slap")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} slapped {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}",embed=em)

  @commands.hybrid_command(name="kill", description="Kills a user.", usage="kill <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to kill.")
  async def kill(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime wasted", 20)
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} killed {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}",embed=em)

  @commands.hybrid_command(name="bully", description="Bullies a user.", usage="bully <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to bully.")
  async def bully(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime bully")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} bullied {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}",embed=em)

  @commands.hybrid_command(name="bite", description="bitess a user.", usage="kill <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to bite.")
  async def bite(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime bite", 20)
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} bitten {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}",embed=em)

  @commands.hybrid_command(name="thanos", description="Sends a Thanos quote.", usage="thanos")
  @commands.guild_only()
  async def thanos(self, ctx):
    await ctx.defer()
    gif = bot.get_gif("thanos quote", 20)
    em = discord.Embed(color=discord.Colour.blue())
    em.set_image(url=gif)
    await ctx.send(f"{ctx.author.mention}",embed=em)


  @commands.hybrid_command(name="enlarge", description="Enlarge a emoji.", usage="enlarge <emoji>")
  @commands.guild_only()
  @app_commands.describe(emoji="Emoji you want to enlarge.")
  async def enlarge(self, ctx, emoji: discord.PartialEmoji):
    em = discord.Embed(title="Enlarged emoji", color=discord.Colour.blue())
    em.set_image(url=emoji.url)
    em.set_footer(text=f"Request by {ctx.author}.")
    await ctx.send(embed=em)





  @commands.hybrid_command(name="truth", description="Gives a truth question.", usage="truth")
  @commands.guild_only()
  async def truth(self, ctx):
    question = requests.get("https://api.truthordarebot.xyz/v1/truth").json()["question"]
    await ctx.message.reply(f"Truth: `{question}`.", mention_author=False)


  @commands.hybrid_command(name="dare", description="Gives a dare question.", usage="dare")
  @commands.guild_only()
  async def dare(self, ctx):
    question = requests.get("https://api.truthordarebot.xyz/v1/dare").json()["question"]
    await ctx.message.reply(f"Dare: `{question}`.", mention_author=False)

  @commands.hybrid_command(name="pat", description="Pats a user.", usage="pat <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to pat.")
  async def pat(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime pat")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} patted {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}", embed=em)

  @commands.hybrid_command(name="poke", description="Pokes a user.", usage="poke <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to poke.")
  async def poke(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime poke")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} poked {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}", embed=em)

  @commands.hybrid_command(name="dance", description="Shows a dance gif.", usage="dance")
  @commands.guild_only()
  async def dance(self, ctx):
    await ctx.defer()
    gif = bot.get_gif("anime dance", 20)
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} is dancing", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(embed=em)


  @commands.hybrid_command(name="choose", description="Makes a random choice.", usage="choose <choice1> <choice2> [choices...]")
  @commands.guild_only()
  @app_commands.describe(choices="Choices separated by spaces.")
  async def choose(self, ctx, *, choices: str):
    choice_list = choices.split()
    if len(choice_list) < 2:
      await ctx.send("Please provide at least 2 choices!")
      return
    em = discord.Embed(color=discord.Colour.blue())
    em.add_field(name="Choices", value=" | ".join(choice_list), inline=False)
    em.add_field(name="Result", value=f"I choose: **{random.choice(choice_list)}**", inline=False)
    await ctx.send(embed=em)

  @commands.hybrid_command(name="rps", description="Play rock paper scissors.", usage="rps <choice>")
  @commands.guild_only()
  @app_commands.describe(choice="Your choice (rock/paper/scissors)")
  async def rps(self, ctx, choice: str):
    choice = choice.lower()
    if choice not in ["rock", "paper", "scissors"]:
      await ctx.send("Please choose rock, paper, or scissors!")
      return

    bot_choice = random.choice(["rock", "paper", "scissors"])

    em = discord.Embed(color=discord.Colour.blue())
    em.add_field(name="Your Choice", value=choice.capitalize(), inline=True)
    em.add_field(name="My Choice", value=bot_choice.capitalize(), inline=True)

    if choice == bot_choice:
      result = "It's a tie!"
    elif (choice == "rock" and bot_choice == "scissors") or \
         (choice == "paper" and bot_choice == "rock") or \
         (choice == "scissors" and bot_choice == "paper"):
      result = "You win!"
    else:
      result = "I win!"

    em.add_field(name="Result", value=result, inline=False)
    await ctx.send(embed=em)

  @commands.hybrid_command(name="highfive", description="Highfive a user.", usage="highfive <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to highfive.")
  async def highfive(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime highfive")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} highfived {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}", embed=em)

  @commands.hybrid_command(name="cry", description="Shows a crying gif.", usage="cry")
  @commands.guild_only()
  async def cry(self, ctx):
    await ctx.defer()
    gif = bot.get_gif("anime cry")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} is crying", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(embed=em)

  @commands.hybrid_command(name="wink", description="Wink at a user.", usage="wink <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to wink at.")
  async def wink(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime wink")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} winked at {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}", embed=em)

  @commands.hybrid_command(name="blush", description="Shows a blushing gif.", usage="blush")
  @commands.guild_only()
  async def blush(self, ctx):
    await ctx.defer()
    gif = bot.get_gif("anime blush")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} is blushing", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(embed=em)

  @commands.hybrid_command(name="yawn", description="Shows a yawning gif.", usage="yawn")
  @commands.guild_only()
  async def yawn(self, ctx):
    await ctx.defer()
    gif = bot.get_gif("anime yawn")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} is yawning", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(embed=em)

  @commands.hybrid_command(name="wave", description="Wave at a user.", usage="wave <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to wave at.")
  async def wave(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime wave")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} waved at {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}", embed=em)

  @commands.hybrid_command(name="punch", description="Punch a user.", usage="punch <member>")
  @commands.guild_only()
  @app_commands.describe(user="User you want to punch.")
  async def punch(self, ctx, user: discord.Member):
    await ctx.defer()
    gif = bot.get_gif("anime punch")
    em = discord.Embed(color=discord.Colour.blue())
    em.set_author(name=f"{ctx.author.name} punched {user.name}", icon_url=ctx.author.display_avatar.url)
    em.set_image(url=gif)
    await ctx.send(f"{user.mention}", embed=em)

  @commands.hybrid_command(name="joke", description="Tells a random joke", usage="joke")
  @commands.guild_only()
  async def joke(self, ctx):
    response = requests.get("https://v2.jokeapi.dev/joke/Any?safe-mode")
    joke_data = response.json()

    em = discord.Embed(color=discord.Colour.blue())
    if joke_data["type"] == "single":
      em.description = joke_data["joke"]
    else:
      em.description = f"{joke_data['setup']}\n\n{joke_data['delivery']}"
    await ctx.send(embed=em)

  @commands.hybrid_command(name="typingrace", description="Start a multiplayer typing speed game", usage="typingrace", aliases=["tr", "typeracer"])
  @commands.guild_only()
  async def typingrace(self, ctx):
    sentences = [
      "The quick brown fox jumps over the lazy dog while the cat watches from a distance.",
      "Programming is the art of telling a computer what to do through carefully written instructions.",
      "In a world full of technology, learning to code has become an essential skill for many careers.",
      "Discord bots help automate tasks and make server management much easier for administrators.",
      "The best way to learn programming is by practicing regularly and building real projects.",
      "A journey of a thousand miles begins with a single step, especially in learning new skills.",
      "Artificial intelligence is rapidly changing the world, shaping the future of technology.",
      "Reading and writing boosts language proficiency and expands the mind's horizon.",
      "Every accomplishment starts with the decision to try and the courage to continue.",
      "Collaboration in open-source projects can lead to significant advancements and innovations.",
      "Antidisestablishment is often cited as one of the longest words in the English language.",
      "Supercal docious is a whimsical word popularized by a Disney movie.",
      "Pneumonoul coniosis is a lung disease caused by inhaling very fine silicate or quartz dust.",
      "Floccinauc pilification is the estimation of something as worthless.",
      "The pedalian tendency of using long-winded vocabulary is often unnecessary."
    ]

    # Select a random sentence
    sentence = random.choice(sentences)

    # Create image with sentence
    from PIL import Image, ImageDraw, ImageFont
    import io

    # Create larger image with enough height for wrapped text
    img = Image.new('RGB', (1000, 400), color='white')
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 36)
    except:
        font = ImageFont.load_default()

    # Calculate wrapped text
    max_width = 900
    words = sentence.split()
    lines = []
    current_line = []
    current_width = 0

    for word in words:
        word_width = d.textlength(word + " ", font=font)
        if current_width + word_width <= max_width:
            current_line.append(word)
            current_width += word_width
        else:
            lines.append(" ".join(current_line))
            current_line = [word]
            current_width = word_width
    
    if current_line:
        lines.append(" ".join(current_line))

    # Draw wrapped text
    y = 50
    for line in lines:
        text_width = d.textlength(line, font=font)
        text_x = (1000 - text_width) / 2
        d.text((text_x, y), line, font=font, fill='black')
        y += 50

    # Convert to bytes
    img_bytes = io.BytesIO()
    img.save(img_bytes, format='PNG')
    img_bytes.seek(0)

    em = discord.Embed(title="Typing Race!", color=discord.Colour.blue())
    em.description = "Type the text shown in the image as fast as you can!\nThe race will end in 30 seconds."
    file = discord.File(img_bytes, filename="typing_text.png")
    em.set_image(url="attachment://typing_text.png")
    await ctx.send(embed=em, file=file)

    participants = {}
    start_time = datetime.datetime.now()
    end_time = start_time + datetime.timedelta(seconds=20)

    def check(m):
      return m.channel == ctx.channel and not m.author.bot

    while len(participants) < 3 and datetime.datetime.now() < end_time:
        try:
            msg = await self.client.wait_for('message', timeout=(end_time - datetime.datetime.now()).total_seconds(), check=check)
        except asyncio.TimeoutError:
            break
        
        if msg.author not in participants:
            accuracy = 100 if msg.content.lower() == sentence.lower() else \
                      int((sum(a == b for a, b in zip(msg.content.lower(), sentence.lower())) / len(sentence)) * 100)

            time_taken = (datetime.datetime.now() - start_time).total_seconds()
            wpm = (len(sentence.split()) / time_taken) * 60

            participants[msg.author] = {
                "time": time_taken,
                "accuracy": accuracy,
                "wpm": wpm
            }
            if accuracy >= 50:
                await msg.add_reaction("<:tick:1130455762867601469>")

    if participants:
      result = discord.Embed(title="Typing Race Results!", color=discord.Colour.blue())

      # Sort participants by time first, then by accuracy
      sorted_participants = sorted(participants.items(), key=lambda x: (-x[1]["accuracy"], x[1]["time"]))

      for i, (user, stats) in enumerate(sorted_participants, 1):
          medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "🎯"
          result.add_field(
              name=f"{medal} #{i} - {user.name}",
              value=f"Time: {stats['time']:.2f}s | Accuracy: {stats['accuracy']}% | WPM: {stats['wpm']:.2f}",
              inline=False
          )
      await ctx.send(embed=result)
    else:
      await ctx.send("No one participated in the typing race!")

  @commands.hybrid_command(name="fact", description="Tells a random fact", usage="fact")
  @commands.guild_only()
  async def fact(self, ctx):
    response = requests.get("https://uselessfacts.jsph.pl/random.json?language=en")
    fact = response.json()["text"]

    em = discord.Embed(color=discord.Colour.blue())
    em.description = fact
    await ctx.send(embed=em)

async def setup(client):
  await client.add_cog(Fun(client))