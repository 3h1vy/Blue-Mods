
import discord
from discord.ext import commands
from discord import app_commands
import json
import datetime

class AddTextModal(discord.ui.Modal, title="📝 Add New Quick Text"):
    def __init__(self, quicktext_cog):
        super().__init__()
        self.quicktext_cog = quicktext_cog

    trigger = discord.ui.TextInput(
        label="Trigger Name",
        placeholder="Enter a trigger name (e.g., 'greeting', 'rules')",
        max_length=50,
        style=discord.TextStyle.short
    )

    text = discord.ui.TextInput(
        label="Text Content",
        placeholder="Enter the text you want to save...",
        max_length=2000,
        style=discord.TextStyle.long
    )

    category = discord.ui.TextInput(
        label="Category (Optional)",
        placeholder="e.g., work, personal, templates",
        max_length=30,
        required=False,
        style=discord.TextStyle.short
    )

    async def on_submit(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)

        if user_id not in self.quicktext_cog.quicktexts:
            self.quicktext_cog.quicktexts[user_id] = {}

        self.quicktext_cog.quicktexts[user_id][self.trigger.value.lower()] = {
            "text": self.text.value,
            "created_at": datetime.datetime.utcnow().isoformat(),
            "uses": 0,
            "category": self.category.value or "general"
        }

        self.quicktext_cog.save_quicktexts()

        embed = discord.Embed(
            title="✅ Quick Text Saved Successfully",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="🏷️ Trigger", value=f"`{self.trigger.value}`", inline=True)
        embed.add_field(name="📁 Category", value=f"`{self.category.value or 'general'}`", inline=True)
        embed.add_field(name="📏 Length", value=f"{len(self.text.value)} characters", inline=True)

        preview = self.text.value[:150] + "..." if len(self.text.value) > 150 else self.text.value
        embed.add_field(name="📄 Preview", value=f"```\n{preview}\n```", inline=False)

        embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class DeleteTextModal(discord.ui.Modal, title="🗑️ Delete Quick Text"):
    def __init__(self, quicktext_cog, user_id):
        super().__init__()
        self.quicktext_cog = quicktext_cog
        self.user_id = user_id

    trigger = discord.ui.TextInput(
        label="Trigger Name to Delete",
        placeholder="Enter the exact trigger name you want to delete",
        max_length=50,
        style=discord.TextStyle.short
    )

    async def on_submit(self, interaction: discord.Interaction):
        if self.trigger.value.lower() not in self.quicktext_cog.quicktexts.get(self.user_id, {}):
            embed = discord.Embed(
                title="❌ Text Not Found",
                description=f"No quick text found with trigger: `{self.trigger.value}`",
                color=0xffffff
            )

            # Suggest similar triggers
            user_texts = self.quicktext_cog.quicktexts.get(self.user_id, {})
            similar = [t for t in user_texts.keys() if self.trigger.value.lower() in t.lower()]
            if similar:
                embed.add_field(
                    name="💡 Did you mean?",
                    value=", ".join([f"`{t}`" for t in similar[:5]]),
                    inline=False
                )

            embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        del self.quicktext_cog.quicktexts[self.user_id][self.trigger.value.lower()]
        self.quicktext_cog.save_quicktexts()

        embed = discord.Embed(
            title="🗑️ Quick Text Deleted",
            description=f"Successfully deleted trigger: `{self.trigger.value}`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class GetTextModal(discord.ui.Modal, title="📖 Get Quick Text"):
    def __init__(self, quicktext_cog, user_id):
        super().__init__()
        self.quicktext_cog = quicktext_cog
        self.user_id = user_id

    trigger = discord.ui.TextInput(
        label="Trigger Name",
        placeholder="Enter the trigger name to retrieve",
        max_length=50,
        style=discord.TextStyle.short
    )

    async def on_submit(self, interaction: discord.Interaction):
        user_texts = self.quicktext_cog.quicktexts.get(self.user_id, {})

        if self.trigger.value.lower() not in user_texts:
            embed = discord.Embed(
                title="❌ Text Not Found",
                description=f"No quick text found with trigger: `{self.trigger.value}`",
                color=0xffffff
            )

            # Suggest similar triggers
            similar = [t for t in user_texts.keys() if self.trigger.value.lower() in t.lower()]
            if similar:
                embed.add_field(
                    name="💡 Did you mean?",
                    value=", ".join([f"`{t}`" for t in similar[:5]]),
                    inline=False
                )

            embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        # Update usage count
        self.quicktext_cog.quicktexts[self.user_id][self.trigger.value.lower()]["uses"] += 1
        self.quicktext_cog.save_quicktexts()

        text_data = user_texts[self.trigger.value.lower()]

        embed = discord.Embed(
            title="📖 Quick Text Retrieved",
            description=f"Trigger: `{self.trigger.value}` | Uses: {text_data['uses']}",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.set_footer(text="Choose how you want to send this text", icon_url=interaction.user.display_avatar.url)

        view = QuickTextView(self.quicktext_cog, self.user_id, self.trigger.value, text_data)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class QuickTextView(discord.ui.View):
    def __init__(self, quicktext_cog, user_id, trigger=None, text_data=None):
        super().__init__(timeout=300)
        self.quicktext_cog = quicktext_cog
        self.user_id = user_id
        self.trigger = trigger
        self.text_data = text_data

    @discord.ui.button(label="Send as Embed", style=discord.ButtonStyle.primary, emoji="📝")
    async def send_embed(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.text_data:
            await interaction.response.send_message("❌ No text data available!", ephemeral=True)
            return

        embed = discord.Embed(
            title=f"📄 {self.trigger}",
            description=self.text_data["text"],
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="📊 Statistics",
            value=f"**Uses:** {self.text_data['uses']}\n**Created:** <t:{int(datetime.datetime.fromisoformat(self.text_data['created_at']).timestamp())}:R>",
            inline=True
        )
        embed.set_footer(text=f"Trigger: {self.trigger} | QuickText System", icon_url=interaction.user.display_avatar.url)

        await interaction.response.send_message(embed=embed)

    @discord.ui.button(label="Send as Text", style=discord.ButtonStyle.secondary, emoji="📄")
    async def send_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.text_data:
            await interaction.response.send_message("❌ No text data available!", ephemeral=True)
            return

        text_content = self.text_data["text"]
        await interaction.response.send_message(text_content)

    @discord.ui.button(label="Copy Raw", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_raw(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.text_data:
            await interaction.response.send_message("❌ No text data available!", ephemeral=True)
            return

        await interaction.response.send_message(f"```\n{self.text_data['text']}\n```", ephemeral=True)

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def delete_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.trigger:
            await interaction.response.send_message("❌ No trigger specified!", ephemeral=True)
            return

        if self.trigger.lower() in self.quicktext_cog.quicktexts[self.user_id]:
            del self.quicktext_cog.quicktexts[self.user_id][self.trigger.lower()]
            self.quicktext_cog.save_quicktexts()

            embed = discord.Embed(
                title="🗑️ Quick Text Deleted",
                description=f"Successfully deleted trigger: `{self.trigger}`",
                color=0xffffff,
                timestamp=datetime.datetime.utcnow()
            )
            embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)

            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ Text not found!", ephemeral=True)

class MainQuickTextView(discord.ui.View):
    def __init__(self, quicktext_cog):
        super().__init__(timeout=300)
        self.quicktext_cog = quicktext_cog

    @discord.ui.button(label="Add Text", style=discord.ButtonStyle.success, emoji="➕")
    async def add_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = AddTextModal(self.quicktext_cog)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Get Text", style=discord.ButtonStyle.primary, emoji="📖")
    async def get_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        user_id = str(interaction.user.id)
        if user_id not in self.quicktext_cog.quicktexts or not self.quicktext_cog.quicktexts[user_id]:
            embed = discord.Embed(
                title="📚 No Quick Texts Found",
                description="You don't have any saved quick texts yet! Use the **Add Text** button to create your first one.",
                color=0xffffff,
                timestamp=datetime.datetime.utcnow()
            )
            embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        modal = GetTextModal(self.quicktext_cog, user_id)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Delete Text", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def delete_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        user_id = str(interaction.user.id)
        if user_id not in self.quicktext_cog.quicktexts or not self.quicktext_cog.quicktexts[user_id]:
            embed = discord.Embed(
                title="📚 No Quick Texts Found",
                description="You don't have any saved quick texts to delete.",
                color=0xffffff,
                timestamp=datetime.datetime.utcnow()
            )
            embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        modal = DeleteTextModal(self.quicktext_cog, user_id)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="List All", style=discord.ButtonStyle.secondary, emoji="📚")
    async def list_texts(self, interaction: discord.Interaction, button: discord.ui.Button):
        user_id = str(interaction.user.id)
        if user_id not in self.quicktext_cog.quicktexts or not self.quicktext_cog.quicktexts[user_id]:
            embed = discord.Embed(
                title="📚 Your Quick Text Library",
                description="You don't have any saved quick texts yet!",
                color=0xffffff,
                timestamp=datetime.datetime.utcnow()
            )
            embed.add_field(
                name="💡 Get Started",
                value="Use the **Add Text** button to create your first quick text!",
                inline=False
            )
            embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        view = PaginatedListView(self.quicktext_cog, user_id, self.quicktext_cog.quicktexts[user_id])
        embed = view.get_embed()
        view.update_buttons()

        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @discord.ui.button(label="Statistics", style=discord.ButtonStyle.secondary, emoji="📊")
    async def show_stats(self, interaction: discord.Interaction, button: discord.ui.Button):
        user_id = str(interaction.user.id)
        if user_id not in self.quicktext_cog.quicktexts or not self.quicktext_cog.quicktexts[user_id]:
            embed = discord.Embed(
                title="📊 QuickText Statistics",
                description="No statistics available - you haven't saved any texts yet!",
                color=0xffffff
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        user_texts = self.quicktext_cog.quicktexts[user_id]
        total_texts = len(user_texts)
        total_uses = sum(data['uses'] for data in user_texts.values())
        total_chars = sum(len(data['text']) for data in user_texts.values())
        avg_length = total_chars // total_texts if total_texts > 0 else 0
        most_used = max(user_texts.items(), key=lambda x: x[1]['uses']) if user_texts else None

        embed = discord.Embed(
            title="📊 Your QuickText Statistics",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )

        embed.add_field(name="📝 Total Texts", value=f"**{total_texts}**", inline=True)
        embed.add_field(name="🔄 Total Uses", value=f"**{total_uses}**", inline=True)
        embed.add_field(name="📏 Average Length", value=f"**{avg_length}** chars", inline=True)
        embed.add_field(name="💾 Total Characters", value=f"**{total_chars:,}**", inline=True)
        embed.add_field(name="📈 Avg Uses per Text", value=f"**{total_uses/total_texts:.1f}**", inline=True)
        embed.add_field(name="⚡ Storage Efficiency", value=f"**{total_chars/2000*100:.1f}%**", inline=True)

        if most_used:
            embed.add_field(
                name="🏆 Most Popular Text",
                value=f"`{most_used[0]}` (**{most_used[1]['uses']}** uses)",
                inline=False
            )

        # Category breakdown
        categories = {}
        for data in user_texts.values():
            cat = data.get('category', 'general')
            categories[cat] = categories.get(cat, 0) + 1

        if len(categories) > 1:
            cat_text = ", ".join([f"{cat}: {count}" for cat, count in categories.items()])
            embed.add_field(name="📁 Categories", value=cat_text, inline=False)

        embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class PaginatedListView(discord.ui.View):
    def __init__(self, quicktext_cog, user_id, quicktexts):
        super().__init__(timeout=300)
        self.quicktext_cog = quicktext_cog
        self.user_id = user_id
        self.quicktexts = list(quicktexts.items())
        self.page = 0
        self.per_page = 5

    def get_embed(self):
        start = self.page * self.per_page
        end = start + self.per_page
        page_items = self.quicktexts[start:end]

        embed = discord.Embed(
            title="📚 Your Quick Text Library",
            description=f"Showing {start + 1}-{min(end, len(self.quicktexts))} of {len(self.quicktexts)} saved texts",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )

        for trigger, data in page_items:
            preview = data["text"][:80] + "..." if len(data["text"]) > 80 else data["text"]
            char_count = len(data["text"])

            embed.add_field(
                name=f"🔸 {trigger}",
                value=f"**Preview:** {preview}\n**Length:** {char_count} chars | **Uses:** {data['uses']} | **Created:** <t:{int(datetime.datetime.fromisoformat(data['created_at']).timestamp())}:R>",
                inline=False
            )

        embed.set_footer(
            text=f"Page {self.page + 1}/{(len(self.quicktexts) - 1) // self.per_page + 1} | QuickText System",
            icon_url=None
        )

        return embed

    @discord.ui.button(label="Previous", style=discord.ButtonStyle.secondary, emoji="⬅️", disabled=True)
    async def previous_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page -= 1
        self.update_buttons()
        await interaction.response.edit_message(embed=self.get_embed(), view=self)

    @discord.ui.button(label="Next", style=discord.ButtonStyle.secondary, emoji="➡️")
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page += 1
        self.update_buttons()
        await interaction.response.edit_message(embed=self.get_embed(), view=self)

    @discord.ui.button(label="Search", style=discord.ButtonStyle.primary, emoji="🔍")
    async def search(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = SearchModal(self.quicktext_cog, self.user_id)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Back to Menu", style=discord.ButtonStyle.success, emoji="🏠")
    async def back_to_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="📝 QuickText Manager",
            description="**Save and retrieve text snippets instantly!**\n\nChoose an action from the buttons below:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="🎯 Features",
            value="• **Add Text** - Save new text snippets\n• **Get Text** - Retrieve saved texts\n• **Delete Text** - Remove unwanted texts\n• **List All** - Browse your library\n• **Statistics** - View usage stats",
            inline=False
        )
        embed.set_footer(text="QuickText System | Click a button to get started", icon_url=interaction.user.display_avatar.url)

        view = MainQuickTextView(self.quicktext_cog)
        await interaction.response.edit_message(embed=embed, view=view)

    def update_buttons(self):
        self.previous_page.disabled = self.page == 0
        self.next_page.disabled = (self.page + 1) * self.per_page >= len(self.quicktexts)

class SearchModal(discord.ui.Modal, title="🔍 Search QuickTexts"):
    def __init__(self, quicktext_cog, user_id):
        super().__init__()
        self.quicktext_cog = quicktext_cog
        self.user_id = user_id

    search_term = discord.ui.TextInput(
        label="Search Term",
        placeholder="Enter trigger name or text content to search...",
        max_length=100,
        style=discord.TextStyle.short
    )

    async def on_submit(self, interaction: discord.Interaction):
        search_term = self.search_term.value.lower()
        user_texts = self.quicktext_cog.quicktexts.get(self.user_id, {})

        matches = {
            trigger: data for trigger, data in user_texts.items()
            if search_term in trigger.lower() or search_term in data['text'].lower()
        }

        if not matches:
            embed = discord.Embed(
                title="🔍 Search Results",
                description=f"No results found for: `{self.search_term.value}`",
                color=0xffffff
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        embed = discord.Embed(
            title="🔍 Search Results",
            description=f"Found {len(matches)} result(s) for: `{self.search_term.value}`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )

        for trigger, data in list(matches.items())[:10]:  # Limit to 10 results
            preview = data["text"][:60] + "..." if len(data["text"]) > 60 else data["text"]
            embed.add_field(
                name=f"🔸 {trigger}",
                value=f"**Preview:** {preview}\n**Uses:** {data['uses']}",
                inline=False
            )

        if len(matches) > 10:
            embed.set_footer(text=f"Showing first 10 of {len(matches)} results | QuickText System")
        else:
            embed.set_footer(text="QuickText System")

        await interaction.response.send_message(embed=embed, ephemeral=True)

class QuickText(commands.Cog):
    def __init__(self, client):
        self.client = client
        try:
            with open('quicktext.json', 'r') as f:
                self.quicktexts = json.load(f)
        except FileNotFoundError:
            self.quicktexts = {}
            self.save_quicktexts()

    def save_quicktexts(self):
        with open('quicktext.json', 'w') as f:
            json.dump(self.quicktexts, f, indent=4)

    @app_commands.command(name="quicktext", description="Open the QuickText manager with button interface")
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    async def quicktext(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📝 QuickText Manager",
            description="**Save and retrieve text snippets instantly!**\n\nChoose an action from the buttons below:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="🎯 Features",
            value="• **Add Text** - Save new text snippets\n• **Get Text** - Retrieve saved texts\n• **Delete Text** - Remove unwanted texts\n• **List All** - Browse your library\n• **Statistics** - View usage stats",
            inline=False
        )
        embed.add_field(
            name="💡 Pro Tips",
            value="• Use descriptive trigger names\n• Organize with categories\n• Multi-line text is supported\n• All your data is private",
            inline=False
        )
        embed.set_footer(text="QuickText System | Click a button to get started", icon_url=interaction.user.display_avatar.url)

        view = MainQuickTextView(self)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="get_text", description="Quickly retrieve a saved text by trigger name")
    @app_commands.describe(trigger="The trigger name of the text you want to retrieve")
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    async def get_text(self, interaction: discord.Interaction, trigger: str):
        user_id = str(interaction.user.id)

        # Check if user has any saved texts
        if user_id not in self.quicktexts or not self.quicktexts[user_id]:
            embed = discord.Embed(
                title="📚 No Quick Texts Found",
                description="You don't have any saved quick texts yet! Use `/quicktext` to create your first one.",
                color=0xffffff,
                timestamp=datetime.datetime.utcnow()
            )
            embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        user_texts = self.quicktexts[user_id]
        trigger_lower = trigger.lower()

        # Check if trigger exists
        if trigger_lower not in user_texts:
            embed = discord.Embed(
                title="❌ Text Not Found",
                description=f"No quick text found with trigger: `{trigger}`",
                color=0xffffff
            )

            # Suggest similar triggers
            similar = [t for t in user_texts.keys() if trigger_lower in t.lower()]
            if similar:
                embed.add_field(
                    name="💡 Did you mean?",
                    value=", ".join([f"`{t}`" for t in similar[:5]]),
                    inline=False
                )

            embed.set_footer(text="QuickText System", icon_url=interaction.user.display_avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        # Update usage count
        self.quicktexts[user_id][trigger_lower]["uses"] += 1
        self.save_quicktexts()

        text_data = user_texts[trigger_lower]

        embed = discord.Embed(
            title="📖 Quick Text Retrieved",
            description=f"Trigger: `{trigger}` | Uses: {text_data['uses']}",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.set_footer(text="Choose how you want to send this text", icon_url=interaction.user.display_avatar.url)

        view = QuickTextView(self, user_id, trigger, text_data)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

async def setup(client):
    await client.add_cog(QuickText(client))
