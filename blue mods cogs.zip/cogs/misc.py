import discord
from discord import app_commands
from discord.ext import commands

from discord.ui import Button, View

import datetime
import typing

import bot_functions as bot
import checks as c


class Misc(commands.Cog):
  def __init__(self, client):
    self.client = client

  @commands.hybrid_command(name= "ping",description="Shows bot latency.", usage="ping")
  @commands.guild_only()
  async def ping(self, ctx):
    latency = round(self.client.latency * 1000)
    embed = discord.Embed(title="Pong!", description=f"{latency}ms", color=discord.Colour.blue())
    await ctx.send(embed=embed)

  @commands.hybrid_command(name="avatar", description="Shows user/server avatar.", aliases=["av", "pfp"], usage="avatar [member/id]")
  @commands.guild_only()
  @app_commands.describe(member="Select member whose avatar you want to see.")
  async def avatar(self, ctx,*, member: typing.Union[discord.Member, discord.User] = commands.Author):
    embed = discord.Embed(title="Avatar", color=member.color)
    embed.set_author(name=member, icon_url=member.display_avatar.url)
    embed.set_image(url=member.display_avatar.with_size(4096).url)
    embed.set_footer(text=f"Requested by: {ctx.author.name}", icon_url=ctx.author.display_avatar.url)

    view = discord.ui.View()

    async def user_callback(interaction: discord.Interaction):
      if interaction.user != ctx.author:
        return
      embed.set_image(url=member.display_avatar.replace(format='jpg', size=4096).url)
      await interaction.response.edit_message(embed=embed)

    async def server_callback(interaction: discord.Interaction):
      if interaction.user != ctx.author:
        return
      if isinstance(member, discord.Member) and member.guild_avatar:
        embed.set_image(url=member.guild_avatar.replace(format='jpg', size=4096).url)
        await interaction.response.edit_message(embed=embed)

    user_btn = discord.ui.Button(label="User Avatar", style=discord.ButtonStyle.primary)
    user_btn.callback = user_callback
    view.add_item(user_btn)

    if isinstance(member, discord.Member) and member.guild_avatar:
        server_btn = discord.ui.Button(label="Server Avatar", style=discord.ButtonStyle.secondary)
        server_btn.callback = server_callback
        view.add_item(server_btn)

    download_btn = discord.ui.Button(label="Download JPG", url=member.display_avatar.replace(format='jpg', size=4096).url, style=discord.ButtonStyle.url)
    view.add_item(download_btn)

    await ctx.send(embed=embed, view=view)

  @commands.hybrid_command(name="banner", description="Shows user banner in different formats.", aliases=["br"], usage="banner [member/id]")
  @commands.guild_only()
  @app_commands.describe(user="Select user whose banner you want to see.")
  async def banner(self, ctx, user: discord.User=commands.Author):
    await ctx.defer()
    user = await self.client.fetch_user(user.id)

    if not user.banner:
      em = discord.Embed(title="Failed", description="No banner found.", color=discord.Colour.red())
      await ctx.send(embed=em)
      return

    formats = ["png", "jpg", "webp"]
    embed = discord.Embed(title="Banner", color=user.color)
    embed.set_author(name=user, icon_url=user.display_avatar.url)
    embed.set_image(url=user.banner.url)
    embed.description = "\n".join([f"[{fmt.upper()}]({user.banner.replace(format=fmt, size=4096).url})" for fmt in formats])
    embed.set_footer(text=f"Requested by: {ctx.author.name}", icon_url=ctx.author.display_avatar.url)

    view = discord.ui.View()
    for fmt in formats:
      url = user.banner.replace(format=fmt, size=4096).url
      button = discord.ui.Button(label=f"Download {fmt.upper()}", url=url, style=discord.ButtonStyle.url)
      view.add_item(button)

    await ctx.send(embed=embed, view=view)

  @commands.hybrid_command(name="membercount", description="Shows the server member count." ,aliases=["mc", "members", "memberscount"], usage="membercount")
  @commands.guild_only()
  async def membercount(self, ctx):
    em = discord.Embed(title="Members", description = f"{ctx.guild.member_count}", color = ctx.author.color, timestamp = datetime.datetime.utcnow())
    await ctx.send(embed=em)


  async def server_userinfo(self, ctx, member: discord.Member):
    created = member.created_at.strftime("%a, %b %d, %Y | %H:%M %p")
    joined = member.joined_at.strftime("%a, %b %d, %Y | %H:%M %p") 
    creation_gap = (discord.utils.utcnow() - member.created_at).days 
    join_gap = (discord.utils.utcnow() - member.joined_at).days
    created_timestamp = int(member.created_at.timestamp())
    joined_timestamp = int(member.joined_at.timestamp())

    # Get member's top role and role count
    roles = member.roles[1:] # Exclude @everyone
    roles.reverse() # Sort from highest to lowest
    top_role = roles[0] if roles else None

    # Get member's top hoisted role
    hoisted_role = None
    for role in roles:
      if role.hoist:
        hoisted_role = role
        break

    # Check user status
    status = "Offline"
    if member.status == discord.Status.online:
      status = "<:online:1130473071552245801> Online"
    elif member.status == discord.Status.idle:
      status = "<:idle:1130473039017017355> Idle"
    elif member.status == discord.Status.dnd:
      status = "<:dnd:1130474084921155684> Do Not Disturb"
    elif member.status == discord.Status.offline:
      status = "<:invisible:1130474032840577094> Offline"

    # Determine user acknowledgements/badges
    perms = member.guild_permissions
    acknowledgements = []
    if member == ctx.guild.owner:
      acknowledgements.append("Server Owner")
    if member.premium_since:
      acknowledgements.append("Server Booster")
    if perms.administrator:
      acknowledgements.append("Administrator")
    elif perms.kick_members or perms.ban_members:
      acknowledgements.append("Moderator")
    elif perms.manage_guild or perms.manage_roles or perms.manage_channels or perms.manage_messages:
      acknowledgements.append("Manager")

    if not acknowledgements:
      acknowledgements.append("Member")

    # Determine if user has mobile, desktop, or web status
    platform = []
    if member.mobile_status != discord.Status.offline:
      platform.append("Mobile")
    if member.desktop_status != discord.Status.offline:
      platform.append("Desktop")
    if member.web_status != discord.Status.offline:
      platform.append("Web")

    # Current activity
    activity = "None"
    if member.activity:
      if member.activity.type == discord.ActivityType.playing:
        activity = f"Playing **{member.activity.name}**"
      elif member.activity.type == discord.ActivityType.streaming:
        activity = f"Streaming **{member.activity.name}**"
      elif member.activity.type == discord.ActivityType.listening:
        activity = f"Listening to **{member.activity.name}**"
      elif member.activity.type == discord.ActivityType.watching:
        activity = f"Watching **{member.activity.name}**"
      elif member.activity.type == discord.ActivityType.custom:
        activity = f"{member.activity.name}"

    # Create embed
    em = discord.Embed(color=member.color, timestamp=datetime.datetime.now())
    em.set_author(name=f"{member} ({member.id})", icon_url=member.display_avatar.url)
    em.set_thumbnail(url=member.display_avatar.url)

    # Main info section
    em.add_field(
      name="__User Information__",
      value=f"**Username:** {member.name}\n"
            f"**ID:** {member.id}\n"
            f"**Bot:** {member.bot}\n"
            f"**Created:** <t:{created_timestamp}:F>\n"
            f"**Status:** {status}\n"
            f"**Platform:** {', '.join(platform) if platform else 'None'}\n"
            f"**Activity:** {activity}",
      inline=False
    )

    # Server specific information
    em.add_field(
      name="__Server Information__",
      value=f"**Joined:** <t:{joined_timestamp}:F>\n"
            f"**Nickname:** {member.nick if member.nick else 'None'}\n"
            f"**Top Role:** {top_role.mention if top_role else 'None'}\n"
            f"**Hoisted Role:** {hoisted_role.mention if hoisted_role else 'None'}\n"
            f"**Roles [{len(roles)}]:** {', '.join([r.mention for r in roles[:10]]) if roles else 'None'}{' ...' if len(roles) > 10 else ''}\n"
            f"**Boosting Since:** {member.premium_since.strftime('%B %d, %Y') if member.premium_since else 'Not Boosting'}",
      inline=False
    )

    # Server permissions if they have significant ones
    if perms.administrator or perms.kick_members or perms.ban_members or perms.manage_guild or perms.manage_channels or perms.manage_messages:
      key_perms = []
      if perms.administrator:
        key_perms.append("Administrator")
      if perms.kick_members:
        key_perms.append("Kick Members")
      if perms.ban_members:
        key_perms.append("Ban Members")
      if perms.manage_guild:
        key_perms.append("Manage Server")
      if perms.manage_channels:
        key_perms.append("Manage Channels")
      if perms.manage_messages:
        key_perms.append("Manage Messages")
      if perms.manage_roles:
        key_perms.append("Manage Roles")

      em.add_field(
        name="__Key Permissions__",
        value=", ".join(key_perms),
        inline=False
      )

    # Acknowledgements
    em.add_field(
      name="__Acknowledgements__",
      value=", ".join(acknowledgements),
      inline=False
    )

    # Fetch user to get banner if available
    user = await self.client.fetch_user(member.id)
    if user.banner:
      em.set_image(url=user.banner.url)

    # Add footer with ID and custom badge if any
    badges = []
    if user.public_flags.staff:
      badges.append("Discord Staff")
    if user.public_flags.partner:
      badges.append("Partner")
    if user.public_flags.hypesquad:
      badges.append("HypeSquad Events")
    if user.public_flags.bug_hunter:
      badges.append("Bug Hunter")
    if user.public_flags.bug_hunter_level_2:
      badges.append("Bug Hunter Level 2")
    if user.public_flags.early_supporter:
      badges.append("Early Supporter")
    if user.public_flags.verified_bot_developer:
      badges.append("Verified Bot Developer")

    em.set_footer(text=f"User Badges: {', '.join(badges) if badges else 'None'}")

    # Create view with buttons
    view = discord.ui.View()

    # Add profile button
    profile_btn = discord.ui.Button(
      label="Profile", 
      url=f"https://discordapp.com/users/{member.id}", 
      style=discord.ButtonStyle.url,
      emoji="👤"
    )
    view.add_item(profile_btn)

    # Add avatar button
    avatar_btn = discord.ui.Button(
      label="Avatar", 
      url=member.display_avatar.url, 
      style=discord.ButtonStyle.url,
      emoji="🖼️"
    )
    view.add_item(avatar_btn)

    # Add banner button if available
    if user.banner:
      banner_btn = discord.ui.Button(
        label="Banner", 
        url=user.banner.url, 
        style=discord.ButtonStyle.url,
        emoji="🎨"
      )
      view.add_item(banner_btn)

    await ctx.send(embed=em, view=view)

  async def discord_userinfo(self, ctx, id: int):
    try:
      user = await self.client.fetch_user(id)
      created = user.created_at.strftime("%a, %b %d, %Y | %H:%M %p")
      creation_gap = (discord.utils.utcnow() - user.created_at).days
      created_timestamp = int(user.created_at.timestamp())

      # Create embed
      em = discord.Embed(color=user.color if hasattr(user, 'color') else discord.Color.blue(), timestamp=datetime.datetime.now())
      em.set_author(name=f"{user} ({user.id})", icon_url=user.display_avatar.url)
      em.set_thumbnail(url=user.display_avatar.url)

      # User badges
      badges = []
      if user.public_flags.staff:
        badges.append("Discord Staff")
      if user.public_flags.partner:
        badges.append("Partner")
      if user.public_flags.hypesquad:
        badges.append("HypeSquad Events")
      if user.public_flags.bug_hunter:
        badges.append("Bug Hunter")
      if user.public_flags.bug_hunter_level_2:
        badges.append("Bug Hunter Level 2")
      if user.public_flags.early_supporter:
        badges.append("Early Supporter")
      if user.public_flags.verified_bot_developer:
        badges.append("Verified Bot Developer")

      # Main info section
      em.add_field(
        name="__User Information__",
        value=f"**Discriminator:** {user.discriminator}\n"
              f"**ID:** {user.id}\n"
              f"**Bot:** {user.bot}\n"
              f"**Created:** <t:{created_timestamp}:F>\n"
              f"**Banned:** {await c.is_banned(ctx, user)}\n"
              f"**Badges:** {', '.join(badges) if badges else 'None'}",
        inline=False
      )

      # Add footer with ID
      em.set_footer(text=f"External user - Not a member of this server")

      # Set banner if available
      if user.banner:
        em.set_image(url=user.banner.url)

      # Create view with buttons
      view = discord.ui.View()

      # Add profile button
      profile_btn = discord.ui.Button(
        label="Profile", 
        url=f"https://discordapp.com/users/{user.id}", 
        style=discord.ButtonStyle.url,
        emoji="👤"
      )
      view.add_item(profile_btn)

      # Add avatar button
      avatar_btn = discord.ui.Button(
        label="Avatar", 
        url=user.display_avatar.url, 
        style=discord.ButtonStyle.url,
        emoji="🖼️"
      )
      view.add_item(avatar_btn)

      # Add banner button if available
      if user.banner:
        banner_btn = discord.ui.Button(
          label="Banner", 
          url=user.banner.url, 
          style=discord.ButtonStyle.url,
          emoji="🎨"
        )
        view.add_item(banner_btn)

      await ctx.send(embed=em, view=view)
    except Exception as e:
      em = discord.Embed(title="Error", description=f"Failed to fetch user information: {str(e)}", color=discord.Color.red())
      await ctx.send(embed=em)

  @commands.hybrid_command(name="userinfo", description="Shows detailed information about a user or member.", aliases=["ui", "whois"], usage="userinfo [user/id]")
  @commands.guild_only()
  @app_commands.describe(member="Select a member or user to get information about.")
  async def userinfo(self, ctx, member: discord.User=commands.Author):
    try:
      member = await commands.MemberConverter().convert(ctx, str(member.id))
      await self.server_userinfo(ctx, member)
    except:
      await self.discord_userinfo(ctx, member.id)


  @commands.hybrid_command(name="roleinfo", description="Displays detailed role information.", aliases=["ri"], usage="roleinfo <role>")
  @commands.guild_only()
  @app_commands.describe(role="Name of the role.")
  async def roleinfo(self, ctx, *, role: str):
    target = bot.find_role(ctx, role)
    if not target:
      await ctx.send(f"<:cross:1130455801740406874> Role `{role}` not found!")
      return

    # Calculate role creation date and time since creation
    created_at_timestamp = int(target.created_at.timestamp())
    days_ago = (ctx.message.created_at - target.created_at).days
    
    # Get hex color code for display
    hex_color = f"#{target.color.value:0>6x}"
    
    # Calculate role position from bottom and top
    bottom_position = target.position + 1
    top_position = len(ctx.guild.roles) - target.position
    
    # Create embed with role color
    em = discord.Embed(color=target.color)
    em.title = f"Role Information: {target.name}"
    
    # Add description with role mention
    em.description = f"Details about {target.mention}"

    # General Information Section
    general_info = [
        f"**ID:** `{target.id}`",
        f"**Name:** {target.name}",
        f"**Created:** <t:{created_at_timestamp}:F> (<t:{created_at_timestamp}:R>)",
        f"**Color:** `{hex_color}` {' ' if target.color.value else '(No color)'}"
    ]
    em.add_field(name="__General Information__", value="\n".join(general_info), inline=False)

    # Display Properties Section
    display_info = [
        f"**Position:** `{bottom_position}` from bottom, `{top_position}` from top",
        f"**Hoisted:** `{'Yes' if target.hoist else 'No'}` {'(Displays members separately)' if target.hoist else ''}",
        f"**Mentionable:** `{'Yes' if target.mentionable else 'No'}`",
        f"**Managed by Integration:** `{'Yes' if target.managed else 'No'}`"
    ]
    
    # Add information about role icon if available
    if target.icon:
        display_info.append(f"**Icon:** [View Icon]({target.icon.url})")
        
    em.add_field(name="__Display Properties__", value="\n".join(display_info), inline=False)

    # Member Statistics Section
    total_members = len(ctx.guild.members)
    role_members = len(target.members)
    percentage = (role_members / total_members * 100) if total_members > 0 else 0
    
    member_stats = [
        f"**Members with role:** `{role_members}` out of `{total_members}` ({percentage:.1f}%)",
        f"**Bots with role:** `{sum(1 for m in target.members if m.bot)}`",
        f"**Humans with role:** `{sum(1 for m in target.members if not m.bot)}`"
    ]
    em.add_field(name="__Member Statistics__", value="\n".join(member_stats), inline=False)

    # Permissions Section
    # Create formatted permissions list for better readability
    permission_groups = {
        "General Server Permissions": [
            ("Administrator", target.permissions.administrator),
            ("View Audit Log", target.permissions.view_audit_log),
            ("Manage Server", target.permissions.manage_guild),
            ("Manage Roles", target.permissions.manage_roles),
            ("Manage Channels", target.permissions.manage_channels),
            ("Manage Webhooks", target.permissions.manage_webhooks),
            ("Manage Emojis & Stickers", target.permissions.manage_emojis_and_stickers),
            ("View Server Insights", target.permissions.view_guild_insights)
        ],
        "Membership Permissions": [
            ("Create Invite", target.permissions.create_instant_invite),
            ("Change Nickname", target.permissions.change_nickname),
            ("Manage Nicknames", target.permissions.manage_nicknames),
            ("Kick Members", target.permissions.kick_members),
            ("Ban Members", target.permissions.ban_members),
            ("Timeout Members", target.permissions.moderate_members)
        ],
        "Channel Permissions": [
            ("View Channels", target.permissions.view_channel),
            ("Manage Threads", target.permissions.manage_threads),
            ("Create Public Threads", target.permissions.create_public_threads),
            ("Create Private Threads", target.permissions.create_private_threads),
            ("Send Messages", target.permissions.send_messages),
            ("Send Messages in Threads", target.permissions.send_messages_in_threads),
            ("Embed Links", target.permissions.embed_links),
            ("Attach Files", target.permissions.attach_files),
            ("Add Reactions", target.permissions.add_reactions),
            ("Use External Emojis", target.permissions.use_external_emojis),
            ("Use External Stickers", target.permissions.use_external_stickers),
            ("Mention Everyone", target.permissions.mention_everyone),
            ("Manage Messages", target.permissions.manage_messages),
            ("Read Message History", target.permissions.read_message_history),
            ("Use Application Commands", target.permissions.use_application_commands)
        ],
        "Voice Permissions": [
            ("Connect", target.permissions.connect),
            ("Speak", target.permissions.speak),
            ("Video", target.permissions.stream),
            ("Use Voice Activity", target.permissions.use_voice_activation),
            ("Priority Speaker", target.permissions.priority_speaker),
            ("Mute Members", target.permissions.mute_members),
            ("Deafen Members", target.permissions.deafen_members),
            ("Move Members", target.permissions.move_members),
            ("Request to Speak", target.permissions.request_to_speak)
        ]
    }
    
    # If role has Administrator, just show that
    if target.permissions.administrator:
        em.add_field(name="__Permissions__", value="**Administrator** — Has all permissions", inline=False)
    else:
        # Build permission fields for each section with enabled permissions
        for group_name, perms in permission_groups.items():
            enabled_perms = [name for name, enabled in perms if enabled]
            if enabled_perms:
                em.add_field(
                    name=f"__{group_name}__", 
                    value="• " + "\n• ".join(enabled_perms) if enabled_perms else "None", 
                    inline=True
                )
    
    # Set thumbnail to role icon or server icon
    if target.icon:
        em.set_thumbnail(url=target.icon.url)
    elif ctx.guild.icon:
        em.set_thumbnail(url=ctx.guild.icon.url)

    # Create view with buttons
    view = discord.ui.View(timeout=120)
    
    # Button to view members with this role
    members_button = discord.ui.Button(
        label=f"View Members ({len(target.members)})", 
        style=discord.ButtonStyle.primary,
        emoji="👥",
        custom_id=f"view_members_{target.id}"
    )

    async def members_button_callback(interaction):
        if interaction.user != ctx.author:
            return await interaction.response.send_message("You cannot use this button.", ephemeral=True)

        await interaction.response.defer()
        
        # Create pages of members for pagination
        members_per_page = 20
        member_chunks = [target.members[i:i+members_per_page] for i in range(0, len(target.members), members_per_page)]
        
        if not member_chunks:
            return await interaction.followup.send(f"No members have the {target.mention} role.")
        
        embeds = []
        for i, chunk in enumerate(member_chunks):
            em = discord.Embed(
                title=f"Members with {target.name}",
                color=target.color
            )
            
            member_list = "\n".join([f"• {member.mention} (`{member.id}`)" for member in chunk])
            em.description = member_list
            
            em.set_footer(text=f"Page {i+1}/{len(member_chunks)} • Total members: {len(target.members)}")
            embeds.append(em)
        
        # If only one page, just send it
        if len(embeds) == 1:
            await interaction.followup.send(embed=embeds[0])
            return
        
        # Create pagination view for multiple pages
        class PaginationView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=60)
                self.current_page = 0
            
            @discord.ui.button(label="◀️ Previous", style=discord.ButtonStyle.gray)
            async def previous(self, inner_interaction: discord.Interaction, button: discord.ui.Button):
                if inner_interaction.user != interaction.user:
                    return await inner_interaction.response.send_message("You cannot use these controls.", ephemeral=True)
                
                self.current_page = max(0, self.current_page - 1)
                await inner_interaction.response.edit_message(embed=embeds[self.current_page])
            
            @discord.ui.button(label="Next ▶️", style=discord.ButtonStyle.gray)
            async def next(self, inner_interaction: discord.Interaction, button: discord.ui.Button):
                if inner_interaction.user != interaction.user:
                    return await inner_interaction.response.send_message("You cannot use these controls.", ephemeral=True)
                
                self.current_page = min(len(embeds) - 1, self.current_page + 1)
                await inner_interaction.response.edit_message(embed=embeds[self.current_page])
        
        pagination_view = PaginationView()
        await interaction.followup.send(embed=embeds[0], view=pagination_view)

    members_button.callback = members_button_callback
    view.add_item(members_button)
    
    # Add button to copy Role ID
    copy_id_button = discord.ui.Button(
        label="Copy ID", 
        style=discord.ButtonStyle.secondary,
        emoji="📋",
        custom_id=f"copy_id_{target.id}"
    )

    async def copy_id_callback(interaction):
        if interaction.user != ctx.author:
            return await interaction.response.send_message("You cannot use this button.", ephemeral=True)
        await interaction.response.send_message(f"```\n{target.id}\n```", ephemeral=True)

    copy_id_button.callback = copy_id_callback
    view.add_item(copy_id_button)

    # Footer with creation info
    em.set_footer(text=f"Role created {days_ago} days ago")

    await ctx.send(embed=em, view=view)

  # Removed duplicate rolein command - now using the improved version in cogs/roles.py



  @commands.hybrid_command(name="serverinfo", description="Shows information about the server.", aliases=["si"], usage="serverinfo")
  @commands.guild_only()
  async def serverinfo(self, ctx):
    # Calculate creation date and time since creation
    created_at = ctx.guild.created_at
    created_timestamp = int(created_at.timestamp())
    creation_days = (discord.utils.utcnow() - created_at).days

    # Set up the embed with server icon
    if ctx.guild.icon:
      em = discord.Embed(
        description=f"[Server icon]({ctx.guild.icon.url})",
        color=ctx.author.color,
        timestamp=datetime.datetime.utcnow()
      )
      em.set_author(name=ctx.guild.name, icon_url=ctx.guild.icon.url) 
      em.set_thumbnail(url=ctx.guild.icon.url)
    else:
      em = discord.Embed(
        color=ctx.author.color,
        timestamp=datetime.datetime.utcnow()
      )
      em.set_author(name=ctx.guild.name, icon_url=self.client.user.display_avatar.url) 
      em.set_thumbnail(url=self.client.user.display_avatar.url)

    # Server information section
    owner_text = "None"
    if ctx.guild.owner:
      owner_text = f"{ctx.guild.owner.mention} ({ctx.guild.owner})"

    em.add_field(name="**__Basic Information__**", value=(
      f"**Name:** {ctx.guild.name}\n"
      f"**Owner:** {owner_text}\n"
      f"**Created:** <t:{created_timestamp}:F> ({creation_days} days ago)\n"
      f"**Region:** {ctx.guild.preferred_locale}"
    ), inline=False)

    # Member statistics
    bots = sum(member.bot for member in ctx.guild.members)
    humans = ctx.guild.member_count - bots
    online = sum(member.status != discord.Status.offline for member in ctx.guild.members if not member.bot)
    em.add_field(name="__Members__", value=(
      f"**Total:** {ctx.guild.member_count}\n"
      f"**Humans:** {humans}\n"
      f"**Bots:** {bots}"
    ), inline=True)

    # Channel statistics
    text_channels = len(ctx.guild.text_channels)
    voice_channels = len(ctx.guild.voice_channels)
    categories = len(ctx.guild.categories)
    threads = len(ctx.guild.threads)

    em.add_field(name="__Channels__", value=(
      f"**Categories:** {categories}\n"
      f"**Text:** {text_channels}\n"
      f"**Voice:** {voice_channels}\n"
      f"**Threads:** {threads}"
    ), inline=True)

    # Emoji and server boost information
    emoji_limit = ctx.guild.emoji_limit
    sticker_limit = ctx.guild.sticker_limit
    normal_emojis = sum(not emoji.animated for emoji in ctx.guild.emojis)
    animated_emojis = sum(emoji.animated for emoji in ctx.guild.emojis)

    boost_level = ctx.guild.premium_tier
    boost_count = ctx.guild.premium_subscription_count

    em.add_field(name="__Emojis & Boosts__", value=(
      f"**Emojis:** {len(ctx.guild.emojis)}/{emoji_limit} "
      f"({normal_emojis} normal, {animated_emojis} animated)\n"
      f"**Stickers:** {len(ctx.guild.stickers)}/{sticker_limit}\n"
      f"**Boost Level:** {boost_level}\n"
      f"**Boosts:** {boost_count}"
    ), inline=False)


    # Security and verification
    verification_level = str(ctx.guild.verification_level).title()
    explicit_content_filter = str(ctx.guild.explicit_content_filter).replace("_", " ").title()

    em.add_field(name="__Security__", value=(
      f"**Verification Level:** {verification_level}\n"
      f"**Content Filter:** {explicit_content_filter}"
    ), inline=False)

    # Roles information
    roles = len(ctx.guild.roles) - 1  # Subtract @everyone
    em.add_field(name=f" __Roles__ ({roles})", value=(
      f"Highest: {ctx.guild.roles[-1].mention if len(ctx.guild.roles) > 1 else 'None'}"
    ), inline=False)

    # Set footer with server ID
    em.set_footer(text=f"Server ID: {ctx.guild.id}")

    # Set server banner if available
    if ctx.guild.banner:
      em.set_image(url=ctx.guild.banner.url)

    # Create view with buttons
    view = discord.ui.View()

    # Icon button
    if ctx.guild.icon:
      icon_button = discord.ui.Button(label="Server Icon", url=ctx.guild.icon.url, style=discord.ButtonStyle.url)
      view.add_item(icon_button)

    # Banner button
    if ctx.guild.banner:
      banner_button = discord.ui.Button(label="Server Banner", url=ctx.guild.banner.url, style=discord.ButtonStyle.url)
      view.add_item(banner_button)

    # Splash button
    if ctx.guild.splash:
      splash_button = discord.ui.Button(label="Invite Splash", url=ctx.guild.splash.url, style=discord.ButtonStyle.url)
      view.add_item(splash_button)

    # Only send view if there are buttons
    if len(view.children) > 0:
      await ctx.send(embed=em, view=view)
    else:
      await ctx.send(embed=em)


  @app_commands.command(name="channelid", description="Returns channel ID of a voice channel.")
  @app_commands.guild_only()
  @app_commands.describe(channel="Select a voice channel.")
  async def channelid(self, interaction, channel: discord.VoiceChannel):
    em = discord.Embed(
        title="Channel Information",
        description=f"**Channel:** {channel.mention}\n**ID:** `{channel.id}`",
        color=discord.Colour.green()
    )
    em.set_footer(text=f"Requested by {interaction.user}", icon_url=interaction.user.display_avatar.url)
    await interaction.response.send_message(embed=em, ephemeral=True)

  @commands.hybrid_command(name="firstmessage", description="Returns first message of a channel.", aliases=["fm"], usage="firstmessage [channel/id]")
  @app_commands.describe(channel="Select a channel.")
  @commands.guild_only()
  async def firstmessage(self, ctx, channel: discord.TextChannel=None):
    if channel is None:
      channel = ctx.channel
    async for message in channel.history(limit=1, oldest_first=True): pass

    em = discord.Embed(description=message.content, color=discord.Colour.blue())
    em.set_author(name=message.author.name, icon_url=message.author.display_avatar.url)
    button = Button(label="View message", url=message.jump_url)
    view = View()
    view.add_item(button)
    await ctx.send(f"`{channel}`'s first message:", embed=em, view=view)

  @commands.hybrid_command(name="banner", description="Returns banner of a user.", aliases=["br"], usage="banner [member/id]")
  @commands.guild_only()
  @app_commands.describe(user="Select a user.")
  async def banner(self, ctx, user: discord.User=commands.Author):
    await ctx.defer()
    user = await self.client.fetch_user(user.id)
    if not user.banner:
      em = discord.Embed(title="Failed", description="No banner found.", color=discord.Colour.red())
      await ctx.send(embed=em)
      return

    embed = discord.Embed(title="Banner", color=user.color)
    embed.set_author(name=user, icon_url=user.display_avatar.url)
    embed.set_image(url=user.banner.with_size(4096).url)
    embed.set_footer(text=f"Requested by: {ctx.author.name}", icon_url=ctx.author.display_avatar.url)

    view = discord.ui.View()

    async def user_callback(interaction: discord.Interaction):
      if interaction.user != ctx.author:
        return
      embed.set_image(url=user.banner.replace(format='jpg', size=4096).url)
      await interaction.response.edit_message(embed=embed)

    async def server_callback(interaction: discord.Interaction):
      if interaction.user != ctx.author:
        return
      if isinstance(user, discord.Member) and user.guild_banner:
        embed.set_image(url=user.guild_banner.replace(format='jpg', size=4096).url)
        await interaction.response.edit_message(embed=embed)

    user_btn = discord.ui.Button(label="User Banner", style=discord.ButtonStyle.primary)
    user_btn.callback = user_callback
    view.add_item(user_btn)

    if isinstance(user, discord.Member) and user.guild_banner:
        server_btn = discord.ui.Button(label="Server Banner", style=discord.ButtonStyle.secondary)
        server_btn.callback = server_callback
        view.add_item(server_btn)

    download_btn = discord.ui.Button(label="Download JPG", url=user.banner.replace(format='jpg', size=4096).url, style=discord.ButtonStyle.url)
    view.add_item(download_btn)

    await ctx.send(embed=embed, view=view)

  @commands.hybrid_command(name="boosters", description="Find all server boosters.", usage="boosters")
  @commands.guild_only()
  async def boosters(self, ctx):
    await ctx.defer()
    members = ctx.guild.premium_subscribers
    if not members:
      em = discord.Embed(title="Failed", description="No boosters found.", color=discord.Colour.red())
      await ctx.send(embed=em)
      return

    message = ", "
    message = message.join([f"`{member}` (Boosting since {member.premium_since.strftime('%Y-%m-%d') if member.premium_since else 'Unknown'})" for member in members[:30]])
    em = discord.Embed(title="Server Boosters", description=f"{len(members)}", color=discord.Colour.blue())
    em.add_field(name="Members", value=message)

    await ctx.send(embed=em)

async def setup(client):
  await client.add_cog(Misc(client))