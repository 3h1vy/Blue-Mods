
import discord
import sqlite3
import logging

import bot_functions as bot
from discord.ext import commands

class Configs(commands.Cog):
    """Handles server configurations and settings."""
    
    def __init__(self, client):
        self.client = client
        self.path = "database/Configs.db"
        self._init_database()

    def _init_database(self) -> None:
        """Initialize the database with required tables."""
        try:
            with sqlite3.connect(self.path) as db:
                c = db.cursor()
                c.execute("""CREATE TABLE IF NOT EXISTS Configs(
                    Guild INTEGER PRIMARY KEY,
                    Prefix TEXT NOT NULL,
                    'No prefix' INTEGER DEFAULT 0,
                    AI INTEGER DEFAULT 0,
                    Voice INTEGER DEFAULT 0,
                    LoopSong INTEGER DEFAULT 0,
                    LoopPlaylist INTEGER DEFAULT 0
                )""")
                db.commit()
        except sqlite3.Error as e:
            logging.error(f"Database initialization error: {e}")
            raise

    @commands.Cog.listener("on_ready")
    async def setup_config(self):
        """Set up configurations for all guilds when bot starts."""
        try:
            with sqlite3.connect(self.path) as db:
                c = db.cursor()
                c.execute("SELECT Guild FROM Configs")
                existing_guilds = {row[0] for row in c.fetchall()}
                
                for guild in self.client.guilds:
                    if guild.id not in existing_guilds:
                        c.execute(
                            "INSERT INTO Configs VALUES(?, ?, ?, ?, ?, ?, ?)",
                            (guild.id, bot.dprefix, 0, 0, 0, 0, 0)
                        )
                db.commit()
        except sqlite3.Error as e:
            logging.error(f"Config setup error: {e}")

    @commands.Cog.listener("on_guild_join")
    async def create_new_config(self, guild):
        """Create configuration for new guilds when bot joins."""
        try:
            with sqlite3.connect(self.path) as db:
                c = db.cursor()
                c.execute(
                    "INSERT OR IGNORE INTO Configs VALUES(?, ?, ?, ?, ?, ?, ?)",
                    (guild.id, bot.dprefix, 0, 0, 0, 0, 0)
                )
                db.commit()
        except sqlite3.Error as e:
            logging.error(f"New config creation error: {e}")

    @commands.hybrid_group(name="prefix", description="Configure prefix for your server.")
    async def prefix(self, ctx):
        if ctx.invoked_subcommand is None:
            try:
                with sqlite3.connect(self.path) as db:
                    c = db.cursor()
                    c.execute("SELECT Prefix, 'No prefix' FROM Configs WHERE Guild = ?", (ctx.guild.id,))
                    current = c.fetchone()
                    if current[1]:  # No prefix mode
                        await ctx.send("🔧 Current setting: No prefix mode\nAvailable subcommands: `set`, `off`")
                    else:
                        await ctx.send(f"🔧 Current prefix: `{current[0]}`\nAvailable subcommands: `set`, `off`")
            except sqlite3.Error as e:
                logging.error(f"Prefix query error: {e}")
                await ctx.send("Please specify a subcommand (`set`/`off`)")

    @prefix.command(name="set", description="Sets a custom prefix for your server.")
    @commands.has_permissions(manage_guild=True)
    async def set(self, ctx, prefix: str):
        """Set a custom prefix for the server (max 5 characters)."""
        if len(prefix) > 5:
            await ctx.send("<:cross:1130455801740406874> Prefix cannot be longer than 5 characters!")
            return
            
        if " " in prefix:
            await ctx.send("<:cross:1130455801740406874> Prefix cannot contain spaces!")
            return

        try:
            with sqlite3.connect(self.path) as db:
                c = db.cursor()
                c.execute(
                    "UPDATE Configs SET Prefix = ?, 'No prefix' = ? WHERE Guild = ?",
                    (prefix, 0, ctx.guild.id)
                )
                db.commit()
            embed = discord.Embed(
                title="Prefix Updated",
                description=f"Server prefix has been set to `{prefix}`",
                color=discord.Color.green()
            )
            embed.add_field(name="Example", value=f"Use commands like: `{prefix}help`")
            await ctx.send(embed=embed)
        except sqlite3.Error as e:
            logging.error(f"Prefix update error: {e}")
            await ctx.send("<:cross:1130455801740406874> Failed to update prefix.")

    @prefix.command(name="off", description="Sets no prefix for your server.")
    @commands.has_permissions(manage_guild=True)
    async def off(self, ctx):
        """Disable prefix requirement for the server."""
        try:
            with sqlite3.connect(self.path) as db:
                c = db.cursor()
                c.execute(
                    "UPDATE Configs SET 'No prefix' = 1 WHERE Guild = ?",
                    (ctx.guild.id,)
                )
                db.commit()
            embed = discord.Embed(
                title="Prefix Mode: None",
                description="Prefix requirement has been disabled for this server.",
                color=discord.Color.green()
            )
            embed.add_field(name="Usage", value="You can now use commands without any prefix!")
            await ctx.send(embed=embed)
        except sqlite3.Error as e:
            logging.error(f"Prefix disable error: {e}")
            await ctx.send("<:cross:1130455801740406874> Failed to disable prefix.")

    @commands.command(name="unbanall", description="Unbans all banned users.")
    async def unbanall(self, ctx):
        """Unban all banned users from the server."""
        if ctx.guild.owner != ctx.author:
            await ctx.send("<:cross:1130455801740406874> Only server owner can use this command!")
            return
            
        try:
            banned_users = [ban.user async for ban in ctx.guild.bans(limit=None)]
            message = await ctx.send(f"<:tick:1130455762867601469> Removing bans from **{len(banned_users)}** Users, please be patient.")
            
            for user in banned_users:
                await ctx.guild.unban(user, reason=f"{ctx.author} used unbanall command.")
                
            await message.edit(content=f"<:tick:1130455762867601469> Successfully unbanned **{len(banned_users)}** users.")
        except discord.Forbidden:
            await ctx.send("<:cross:1130455801740406874> I don't have permission to unban users.")
        except Exception as e:
            logging.error(f"Unban all error: {e}")
            await ctx.send("<:cross:1130455801740406874> An error occurred while unbanning users.")

async def setup(client):
    await client.add_cog(Configs(client))
