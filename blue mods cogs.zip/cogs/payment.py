import discord
from discord.ext import commands
from discord import app_commands
import datetime



class PatchyPaymentView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="CashApp", style=discord.ButtonStyle.secondary, emoji="<:cashapp:1391321667795685506>")
    async def cashapp_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💳 CashApp Payment - Patchy",
            description="**Step-by-step payment process**",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="📋 Payment Details",
            value="**CashApp Tag:** `$mrbianco619`\n**Name:** Derek White\n**Link:** https://cash.app/$mrbianco619",
            inline=False
        )
        embed.add_field(
            name="📝 Instructions",
            value="` 1 ` Open CashApp\n` 2 ` Send to: `$mrbianco619`\n` 3 ` Add 5% processing fee\n` 4 ` Include Discord username in note\n` 5 ` Submit payment confirmation",
            inline=False
        )
        embed.add_field(name="💰 Processing Fee", value="**5%** - Use calculator below", inline=True)
        embed.add_field(name="⏱️ Processing Time", value="**Instant**", inline=True)
        embed.add_field(name="🔒 Security", value="**High**", inline=True)
        embed.set_image(url="https://media.discordapp.net/attachments/1391646511187755029/1392341821555867738/Screenshot_2025-07-09-08-38-04-318_com.Discord.png?ex=686f2ede&is=686ddd5e&hm=2dfd34162773f16605d27bcdc3218d3d25e82c3478b319e37bc5e55ff7bdc786&=&format=webp&quality=lossless&width=491&height=592")
        embed.set_footer(text="💡 Tip: Use the calculator to determine exact amount with fees")

        # Add back button to return to main payment view
        view = PaymentDetailsView("$mrbianco619", "CashApp", True, 5)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="PayPal", style=discord.ButtonStyle.secondary, emoji="<:Paypal:1391321608144293988>")
    async def paypal_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="PayPal Details - Patchy",
            description="**Link**: https://www.paypal.me/mrbianco69\n**Name:** Derek White",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="Instructions", value="Send as Friends & Family to avoid fees or scan the QR code", inline=False)
        embed.add_field(name="⚠️ Fee Notice", value="**Important:** Please add 5% to your total amount as a processing fee before sending", inline=False)
        embed.set_image(url="https://media.discordapp.net/attachments/1391646511187755029/1392341803969019965/Screenshot_2025-07-09-08-38-35-974_com.Discord.png?ex=686f2eda&is=686ddd5a&hm=031af0026389804160d181a96512aac7f6d3571c163531d335d9e8ec6e22b2de&=&format=webp&quality=lossless&width=589&height=592")
        embed.set_footer(text="Send Screenshot of successful payment")

        view = PaymentDetailsView("https://www.paypal.me/mrbianco69", "PayPal", True, 5)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Crypto", style=discord.ButtonStyle.secondary, emoji="<:crypto:1391321729694961836>")
    async def crypto_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Cryptocurrency Options - Patchy",
            description="Select your preferred cryptocurrency:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="Available Cryptocurrencies",
            value="• Bitcoin (BTC)\n• Ethereum (ETH)\n• Litecoin (LTC)\n• Solana (SOL)\n• Tether (USDT)",
            inline=False
        )
        embed.set_footer(text="Click a cryptocurrency button below")
        view = CryptoView()
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Zelle", style=discord.ButtonStyle.secondary, emoji="<:Zelle:1391321915607617598>")
    async def zelle_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Zelle Details - Patchy",
            description="**Name:** Derek White\n**Phone:** `(619)602-1896`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="Instructions", value="Send payment using the phone number above via Zelle", inline=False)
        embed.add_field(name="⚠️ Fee Notice", value="**Important:** Please add 5% to your total amount as a processing fee before sending", inline=False)

        view = PaymentDetailsView("(619)602-1896", "Zelle", True, 5)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Remitly", style=discord.ButtonStyle.secondary, emoji="<:remitly:1391321829691625492>")
    async def remitly_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Remitly Details - Patchy",
            description="**Send Money to:** INDIA 🇮🇳\n**UPI/VPA:** `3hv@upi`\n**Name:** Apoorv Mishra",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="📋 Step-by-Step Instructions",
            value="` 1 ` Choose currency: **INR (India)**\n` 2 ` Delivery speed: **EXPRESS**\n` 3 ` Choose **UPI** option\n` 4 ` **SKIP** the recipient number!\n` 5 ` Reason for sending: **Family Support**",
            inline=False
        )

        view = PaymentDetailsView("3hv@upi", "Remitly", False)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Binance", style=discord.ButtonStyle.secondary, emoji="<:Binance:1391322016229097493>")
    async def binance_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Binance Details - Patchy",
            description="**Binance ID:** `187114991`\n**Email:** `apdotmishra@gmail.com`\n**Nickname:** Patchy",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="Instructions", value="Use Binance Pay with the ID above or scan the QR code", inline=False)
        embed.add_field(name="⚠️ Fee Notice", value="**Important:** If sending crypto other than USDT, please add 2% to your total amount as a processing fee before sending", inline=False)
        embed.set_image(url="https://media.discordapp.net/attachments/1391646511187755029/1392344452944892006/Screenshot_2025-07-09-08-49-37-650_com.Discord.png?ex=686f3152&is=686ddfd2&hm=af9f60f75a5bf4b7150c192171505bb314df027bdc8ee687956a27ea9ed7eba7&=&format=webp&quality=lossless&width=561&height=592")

        view = PaymentDetailsView("187114991", "Binance", True, 2)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="UPI", style=discord.ButtonStyle.secondary, emoji="<:upi:1391324368034074745>")
    async def upi_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="UPI Details - Patchy",
            description="**UPI ID:** `apdotmishra@fam`\n**Name:** Apoorv Mishra",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="Instructions", value="Send payment using the UPI ID above or scan the QR code", inline=False)
        embed.set_image(url="https://media.discordapp.net/attachments/1123886709340393472/1405104939163717693/image0.png?ex=689d9d73&is=689c4bf3&hm=3363b67b868672070b5056b91c7665847f9a93263ebce634f838af4b556d1304&=&format=webp&quality=lossless&width=457&height=586")
        embed.set_footer(text="Available for Indian users only")

        view = UPIDetailsView("apdotmishra@fam")
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Venmo", style=discord.ButtonStyle.secondary, emoji="<:venmo:1392342632344190998>")
    async def venmo_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💳 Venmo Payment - Patchy",
            description="**Step-by-step payment process**",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="📋 Payment Details",
            value="**Username:** `Derek-Bianco`\n**Name:** Derek White",
            inline=False
        )
        embed.add_field(
            name="📝 Instructions",
            value="` 1 ` Open Venmo app\n` 2 ` Search: `Derek-Bianco`\n` 3 ` Add 5% processing fee\n` 4 ` Include Discord username in note\n` 5 ` Submit payment confirmation",
            inline=False
        )
        embed.add_field(name="💰 Processing Fee", value="**5%** - Use calculator below", inline=True)
        embed.add_field(name="⏱️ Processing Time", value="**Instant**", inline=True)
        embed.add_field(name="🔒 Security", value="**High**", inline=True)
        embed.set_image(url="https://media.discordapp.net/attachments/1391646511187755029/1392341812768804934/Screenshot_2025-07-09-08-38-23-095_com.Discord.png?ex=686f2edc&is=686ddd5c&hm=e60d9894962cc9c0bdd3cef1fceabce02ac1f24c9e71b144811a5ccd1fc5bab9&=&format=webp&quality=lossless&width=600&height=592")
        embed.set_footer(text="💡 Tip: Use the calculator to determine exact amount with fees")

        view = PaymentDetailsView("Derek-Bianco", "Venmo", True, 5)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Bybit", style=discord.ButtonStyle.secondary, emoji="<:bybit:1405109293149192223>")
    async def bybit_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Bybit Details - Patchy",
            description="**Bybit ID:** `491798928`\n**Email:** `apdotmishra@gmail.com`\n**Nickname:** Patchy",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="Instructions", value="Use Bybit Pay with the ID above", inline=False)
        embed.add_field(name="✅ No Additional Fee", value="**Great News:** No processing fee required for Bybit transactions", inline=False)

        view = PaymentDetailsView("491798928", "Bybit", False)
        await interaction.response.edit_message(embed=embed, view=view)



class CryptoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Bitcoin (BTC)", style=discord.ButtonStyle.secondary, emoji="<:btc:1391321501680013312>")
    async def btc_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Bitcoin (BTC) Address - Patchy",
            description="**Network:** Bitcoin\n**Address:** `1BWSWhHJW4CfMNTYn4fD3WmD9smrTu8v27`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="⚠️ Important", value="• Double-check the address before sending\n• Only send Bitcoin (BTC) to this address\n• Minimum amount: 0.001 BTC", inline=False)
        embed.add_field(name="💰 Fee Notice", value="**Processing Fee:** Please add 2% to your total amount before sending", inline=False)
        embed.add_field(name="📋 Copy Address", value="`1BWSWhHJW4CfMNTYn4fD3WmD9smrTu8v27`", inline=False)
        embed.set_footer(text="Transaction confirmations: 3 required")
        view = PaymentDetailsView("1BWSWhHJW4CfMNTYn4fD3WmD9smrTu8v27", "Bitcoin", True, 2)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Ethereum (ETH)", style=discord.ButtonStyle.secondary, emoji="<:eth:1391322068682932224>")
    async def eth_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Ethereum (ETH) Address - Patchy",
            description="**Network:** Ethereum (ERC-20)\n**Address:** `0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="⚠️ Important", value="• Double-check the address before sending\n• Only send Ethereum (ETH) or ERC-20 tokens\n• Minimum amount: 0.01 ETH", inline=False)
        embed.add_field(name="💰 Fee Notice", value="**Processing Fee:** Please add 2% to your total amount before sending", inline=False)
        embed.add_field(name="📋 Copy Address", value="`0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f`", inline=False)
        embed.set_footer(text="Gas fees apply - Check network congestion")
        view = PaymentDetailsView("0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f", "Ethereum", True, 2)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Litecoin (LTC)", style=discord.ButtonStyle.secondary, emoji="<:ltc:1391321552095809567>")
    async def ltc_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Litecoin (LTC) Address - Patchy",
            description="**Network:** Litecoin\n**Address:** `ltc1qw8pmz09wznw2230ufrk40pvc9qynlmkdmvx7yt`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="⚠️ Important", value="• Double-check the address before sending\n• Only send Litecoin (LTC) to this address\n• Minimum amount: 0.1 LTC", inline=False)
        embed.add_field(name="✅ No Additional Fee", value="**Great News:** No processing fee required for Litecoin transactions", inline=False)
        embed.add_field(name="📋 Copy Address", value="`ltc1qw8pmz09wznw2230ufrk40pvc9qynlmkdmvx7yt`", inline=False)
        embed.set_footer(text="Fast confirmations - Usually 2.5 minutes")
        view = LTCDetailsView("ltc1qw8pmz09wznw2230ufrk40pvc9qynlmkdmvx7yt", "Litecoin", False)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Solana (SOL)", style=discord.ButtonStyle.secondary, emoji="<:Solana:1391322237176643614>")
    async def sol_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Solana (SOL) Address - Patchy",
            description="**Network:** Solana\n**Address:** `7S8VMDUAxhGYbbbP1taZAyugBEvMFbC4a2CdoJzPw8hg`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="⚠️ Important", value="• Double-check the address before sending\n• Only send Solana (SOL) or SPL tokens\n• Minimum amount: 0.1 SOL", inline=False)
        embed.add_field(name="💰 Fee Notice", value="**Processing Fee:** Please add 2% to your total amount before sending", inline=False)
        embed.add_field(name="📋 Copy Address", value="`7S8VMDUAxhGYbbbP1taZAyugBEvMFbC4a2CdoJzPw8hg`", inline=False)
        embed.set_footer(text="Very low fees - Fast transactions")
        view = PaymentDetailsView("7S8VMDUAxhGYbbbP1taZAyugBEvMFbC4a2CdoJzPw8hg", "Solana", True, 2)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Tether (USDT)", style=discord.ButtonStyle.secondary, emoji="<:USDT:1391322155316154388>")
    async def usdt_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Tether (USDT) Address - Patchy",
            description="**Network:** Ethereum (ERC-20)\n**Address:** `0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f`\n\n**Network:** Tron (TRC-20)\n**Address:** `TR8rrNQZWvZfy7Qd4XAW5QXyB5YqSHynLR`\n\n**Network:** Binance Smart Chain (BEP-20)\n**Address:** `0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="⚠️ Important", value="• Choose the correct network (ERC-20, TRC-20, or BEP-20)\n• ERC-20: Higher fees, more secure\n• TRC-20: Lower fees, faster\n• BEP-20: Very low fees, fast\n• Minimum: 10 USDT", inline=False)
        embed.add_field(name="✅ No Additional Fee", value="**Great News:** No processing fee required for USDT transactions", inline=False)
        embed.add_field(name="📋 ERC-20 Address", value="`0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f`", inline=False)
        embed.add_field(name="📋 BEP-20 Address", value="`0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f`", inline=False)
        embed.add_field(name="📋 TRC-20 Address", value="`TR8rrNQZWvZfy7Qd4XAW5QXyB5YqSHynLR`", inline=False)
        embed.set_footer(text="Make sure to select the correct network!")
        view = USDTDetailsView()
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Back to Payment Methods", emoji="<:ArrowLeft:1391333239502671913>", style=discord.ButtonStyle.danger, row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💳 Patchy's Payment Methods",
            description="Select your preferred payment method below:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="Available Methods",
            value="• CashApp\n• PayPal\n• Crypto\n• Zelle\n• Remitly\n• Binance\n• UPI\n• Venmo",
            inline=False
        )
        embed.set_footer(text="Click a button below to get payment details")
        await interaction.response.edit_message(embed=embed, view=PatchyPaymentView())

class UPIView(discord.ui.View):
    def __init__(self, copy_text):
        super().__init__(timeout=None)
        self.copy_text = copy_text

    @discord.ui.button(label="Copy Details", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"{self.copy_text}", ephemeral=True)

    @discord.ui.button(label="Alternate UPI", style=discord.ButtonStyle.secondary, emoji="<:upi:1391324368034074745>")
    async def alternate_upi_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Alternate UPI Details - Patchy",
            description="**UPI ID:** `3hv@upi`\n**Name:** Apoorv Mishra",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="Instructions", value="Send payment using the UPI ID above or scan the QR code", inline=False)
        embed.set_image(url="https://media.discordapp.net/attachments/1270615063601872991/1352494852339925033/QR_1742530171.png?ex=67de387c&is=67dce6fc&hm=2a81c73a0a300bcdeefe723dc489ccaa3bdc7b802039fc11b0ae0ad703b41ec0&")
        embed.set_footer(text="Available for Indian users only")
        view = CopyView("3hv@upi", "UPI", False)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class PaymentDetailsView(discord.ui.View):
    def __init__(self, copy_text, payment_method="Payment", has_fee=True, fee_percentage=5):
        super().__init__(timeout=None)
        self.copy_text = copy_text
        self.payment_method = payment_method
        self.has_fee = has_fee
        self.fee_percentage = fee_percentage

        # Only add fee calculator button if there's a fee
        if self.has_fee:
            self.add_item(FeeCalculatorButton(self.fee_percentage))

    @discord.ui.button(label="Copy Details", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"{self.copy_text}", ephemeral=True)

    @discord.ui.button(label="Back to Payment Methods", emoji="<:ArrowLeft:1391333239502671913>", style=discord.ButtonStyle.danger)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💳 Payment Methods - Patchy",
            description="Select your preferred payment method below:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="Available Methods",
            value="• CashApp\n• PayPal\n• Crypto\n• Zelle\n• Remitly\n• Binance\n• UPI\n• Venmo\n• Bybit",
            inline=False
        )
        embed.set_footer(text="Click a payment method to view details and copy information")

        await interaction.response.edit_message(embed=embed, view=PatchyPaymentView())

class LTCDetailsView(discord.ui.View):
    def __init__(self, copy_text, payment_method="Payment", has_fee=False):
        super().__init__(timeout=None)
        self.copy_text = copy_text
        self.payment_method = payment_method
        self.has_fee = has_fee

    @discord.ui.button(label="Copy Details", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"{self.copy_text}", ephemeral=True)

    @discord.ui.button(label="Alternate LTC", style=discord.ButtonStyle.secondary, emoji="<:ltc:1391321552095809567>")
    async def alternate_ltc_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Alternate Litecoin (LTC) Address - Patchy",
            description="**Network:** Litecoin\n**Address:** `LRDbzqAxbwZW46gUfoSVBemh53qjQz7HZX`",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="⚠️ Important", value="• Double-check the address before sending\n• Only send Litecoin (LTC) to this address\n• Minimum amount: 0.1 LTC", inline=False)
        embed.add_field(name="✅ No Additional Fee", value="**Great News:** No processing fee required for Litecoin transactions", inline=False)
        embed.add_field(name="📋 Copy Address", value="`LRDbzqAxbwZW46gUfoSVBemh53qjQz7HZX`", inline=False)
        embed.set_footer(text="Fast confirmations - Usually 2.5 minutes")

        view = PaymentDetailsView("LRDbzqAxbwZW46gUfoSVBemh53qjQz7HZX", "Litecoin", False)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Back to Payment Methods", emoji="<:ArrowLeft:1391333239502671913>", style=discord.ButtonStyle.danger)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💳 Payment Methods - Patchy",
            description="Select your preferred payment method below:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="Available Methods",
            value="• CashApp\n• PayPal\n• Crypto\n• Zelle\n• Remitly\n• Binance\n• UPI\n• Venmo\n• Bybit",
            inline=False
        )
        embed.set_footer(text="Click a payment method to view details and copy information")

        await interaction.response.edit_message(embed=embed, view=PatchyPaymentView())

class UPIDetailsView(discord.ui.View):
    def __init__(self, copy_text):
        super().__init__(timeout=None)
        self.copy_text = copy_text

    @discord.ui.button(label="Copy Details", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"{self.copy_text}", ephemeral=True)

    @discord.ui.button(label="Alternate UPI", style=discord.ButtonStyle.secondary, emoji="<:upi:1391324368034074745>")
    async def alternate_upi_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="Alternate UPI Details - Patchy",
            description="**UPI ID:** `3hv@upi`\n**Name:** Apoorv Mishra",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(name="Instructions", value="Send payment using the UPI ID above or scan the QR code", inline=False)
        embed.set_image(url="https://media.discordapp.net/attachments/1270615063601872991/1352494852339925033/QR_1742530171.png?ex=67de387c&is=67dce6fc&hm=2a81c73a0a300bcdeefe723dc489ccaa3bdc7b802039fc11b0ae0ad703b41ec0&")
        embed.set_footer(text="Available for Indian users only")

        view = PaymentDetailsView("3hv@upi", "UPI", False)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Back to Payment Methods", emoji="<:ArrowLeft:1391333239502671913>", style=discord.ButtonStyle.danger)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💳 Payment Methods - Patchy",
            description="Select your preferred payment method below:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="Available Methods",
            value="• CashApp\n• PayPal\n• Crypto\n• Zelle\n• Remitly\n• Binance\n• UPI\n• Venmo\n• Bybit",
            inline=False
        )
        embed.set_footer(text="Click a payment method to view details and copy information")

        await interaction.response.edit_message(embed=embed, view=PatchyPaymentView())

class CopyView(discord.ui.View):
    def __init__(self, copy_text, payment_method="Payment", has_fee=True, fee_percentage=5):
        super().__init__(timeout=None)
        self.copy_text = copy_text
        self.payment_method = payment_method
        self.has_fee = has_fee
        self.fee_percentage = fee_percentage

        # Only add fee calculator button if there's a fee
        if self.has_fee:
            self.add_item(FeeCalculatorButton(self.fee_percentage))

    @discord.ui.button(label="Copy Details", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"{self.copy_text}", ephemeral=True)

class FeeCalculatorButton(discord.ui.Button):
    def __init__(self, fee_percentage):
        super().__init__(label="Calculate Fee", style=discord.ButtonStyle.secondary, emoji="🧮")
        self.fee_percentage = fee_percentage

    async def callback(self, interaction: discord.Interaction):
        modal = FeeCalculatorModal(self.fee_percentage)
        await interaction.response.send_modal(modal)

class FeeCalculatorModal(discord.ui.Modal, title="💰 Fee Calculator"):
    def __init__(self, fee_percentage=5):
        super().__init__()
        self.fee_percentage = fee_percentage

    amount = discord.ui.TextInput(
        label="Enter Amount ($)",
        placeholder="e.g., 100.00",
        max_length=20,
        style=discord.TextStyle.short
    )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            base_amount = float(self.amount.value)
            fee = base_amount * (self.fee_percentage / 100)
            total_amount = base_amount + fee

            embed = discord.Embed(
                title="💰 Fee Calculation",
                color=0xffffff,
                timestamp=datetime.datetime.utcnow()
            )
            embed.add_field(name="Base Amount", value=f"${base_amount:.2f}", inline=True)
            embed.add_field(name="Processing Fee ({self.fee_percentage}%)", value=f"${fee:.2f}", inline=True)
            embed.add_field(name="Total to Send", value=f"**${total_amount:.2f}**", inline=True)
            embed.set_footer(text="Send the total amount shown above")

            await interaction.response.send_message(embed=embed, ephemeral=True)
        except ValueError:
            await interaction.response.send_message("❌ Please enter a valid number!", ephemeral=True)



class USDTDetailsView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Copy ERC-20", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_erc20_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f", ephemeral=True)

    @discord.ui.button(label="Copy BEP-20", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_bep20_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f", ephemeral=True)

    @discord.ui.button(label="Copy TRC-20", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_trc20_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("TR8rrNQZWvZfy7Qd4XAW5QXyB5YqSHynLR", ephemeral=True)

    @discord.ui.button(label="Back to Payment Methods", emoji="<:ArrowLeft:1391333239502671913>", style=discord.ButtonStyle.danger)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💳 Payment Methods - Patchy",
            description="Select your preferred payment method below:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )
        embed.add_field(
            name="Available Methods",
            value="• CashApp\n• PayPal\n• Crypto\n• Zelle\n• Remitly\n• Binance\n• UPI\n• Venmo\n• Bybit",
            inline=False
        )
        embed.set_footer(text="Click a payment method to view details and copy information")

        await interaction.response.edit_message(embed=embed, view=PatchyPaymentView())

class USDTCopyView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Copy ERC-20", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_erc20_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f", ephemeral=True)

    @discord.ui.button(label="Copy BEP-20", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_bep20_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("0x3adbdd0abd3af547fedd517a7b6915b1b8955e7f", ephemeral=True)

    @discord.ui.button(label="Copy TRC-20", style=discord.ButtonStyle.success, emoji="📋")
    async def copy_trc20_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("TR8rrNQZWvZfy7Qd4XAW5QXyB5YqSHynLR", ephemeral=True)

class Payment(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.hybrid_command(name="payment", description="View payment methods for Patchy", aliases=["pm"])
    @app_commands.allowed_installs(guilds=True, users=True)
    @app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
    async def payment(self, ctx):
        """Simple and clean payment command interface"""

        embed = discord.Embed(
            title="💳 Payment Methods - Patchy",
            description="Select your preferred payment method below:",
            color=0xffffff,
            timestamp=datetime.datetime.utcnow()
        )

        embed.add_field(
            name="Available Methods",
            value="• CashApp\n• PayPal\n• Crypto\n• Zelle\n• Remitly\n• Binance\n• UPI\n• Venmo\n• Bybit",
            inline=False
        )

        embed.set_footer(text="Click a payment method to view details and copy information")

        view = PatchyPaymentView()
        message = await ctx.send(embed=embed, view=view)
        view.message = message

        # Auto-delete the command message
        try:
            await ctx.message.delete()
        except:
            pass

async def setup(client):
    await client.add_cog(Payment(client))